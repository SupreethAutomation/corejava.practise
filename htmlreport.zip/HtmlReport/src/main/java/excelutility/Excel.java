package excelutility;

import jFreeUtility.JFreeUtility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.sl.usermodel.ColorStyle;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Chart;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.Color;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.usermodel.charts.ChartData;
import org.apache.poi.ss.usermodel.charts.ChartDataFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFClientAnchor;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFPicture;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

public class Excel 
{
	static File objFile = null;
	static FileOutputStream objFileOutputStream = null;
	static XSSFWorkbook objWorkbook = null;
	static XSSFSheet objXssfSheet = null;
	static XSSFRow objXssfRow = null;
	static XSSFCell objXssfCell = null;
	static FileInputStream objFileInputStream = null;
	static CellStyle objCellStyle = null;
	static String filePath = System.getProperty("user.dir")+"/src/main/resources/appln/";
	static String testExecutionReportPath = null;
	static Date objDate = null;
	static SimpleDateFormat objSimpleDateFormat = null;
	static XSSFDrawing objXssfDrawing = null;
	static XSSFClientAnchor objXssfClientAnchor = null; 
	static File jpegFile = null;
	public Excel() 
	{
		objDate = new Date();
		objSimpleDateFormat = new SimpleDateFormat("dd_MMM_yyyy");
		objFile = new File(filePath+"TestExecutionReport"+objSimpleDateFormat.format(objDate)+".xlsx");
		jpegFile = new File(filePath+"TestExecutionReport"+objSimpleDateFormat.format(objDate)+".jpeg");
		testExecutionReportPath = objFile.getAbsolutePath();
	}
	
	public  static File createExcelFile()
	{
		 try {
			 objWorkbook = new XSSFWorkbook();
			objFileOutputStream = new FileOutputStream(objFile);
			
			objWorkbook.createSheet(objSimpleDateFormat.format(objDate));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 try {
			objWorkbook.write(objFileOutputStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 System.out.println("Excel file is created.....");
		 try {
			objWorkbook.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 objFile = createTestTemplate(objFile);
		 return objFile;
	}
	
	public  static File createTestTemplate(File file)
	{
		try {
			objFileInputStream = new FileInputStream(objFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			objWorkbook = new XSSFWorkbook(objFileInputStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		objXssfSheet = objWorkbook.getSheetAt(0);
		objXssfRow = objWorkbook.getSheetAt(0).createRow(0);
		objXssfCell = objXssfRow.createCell(0);
		objXssfCell = objXssfRow.getCell(0);
		objXssfCell.setCellValue("Test Result Summary");
		objCellStyle = objWorkbook.createCellStyle();
		objCellStyle.setWrapText(true);
		objCellStyle.setAlignment(HorizontalAlignment.CENTER);
		objCellStyle.setFillForegroundColor(IndexedColors.CORNFLOWER_BLUE.index);
		objCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		objXssfCell.setCellStyle(objCellStyle);
		CellRangeAddress objCellRangeAddress = new CellRangeAddress(0, 0, 0, 1);
		objXssfSheet.addMergedRegion(objCellRangeAddress);
		
		objXssfRow = objWorkbook.getSheetAt(0).createRow(1);
		objXssfCell = objXssfRow.createCell(0);
		objXssfCell.setCellType(CellType.STRING);
		objXssfCell.setCellValue("Total Test Cases");
		objCellStyle = objWorkbook.createCellStyle();
		objCellStyle.setAlignment(HorizontalAlignment.CENTER);
		objCellStyle.setFillForegroundColor(IndexedColors.ORANGE.index);
		objCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		objXssfCell.setCellStyle(objCellStyle);
		objXssfRow.createCell(1).setAsActiveCell();
		
		objXssfRow = objWorkbook.getSheetAt(0).createRow(2);
		objXssfCell = objXssfRow.createCell(0);
		objXssfCell.setCellType(CellType.STRING);
		objXssfCell.setCellValue("Total Test Cases Passed");
		objCellStyle = objWorkbook.createCellStyle();
		objCellStyle.setAlignment(HorizontalAlignment.CENTER);
		objCellStyle.setFillForegroundColor(IndexedColors.LIGHT_GREEN.index);
		objCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		objXssfCell.setCellStyle(objCellStyle);
		objXssfRow.createCell(1).setAsActiveCell();
		
		objXssfRow = objWorkbook.getSheetAt(0).createRow(3);
		objXssfCell = objXssfRow.createCell(0);
		objXssfCell.setCellType(CellType.STRING);
		objXssfCell.setCellValue("Total Test Cases Failed");
		objCellStyle = objWorkbook.createCellStyle();
		objCellStyle.setAlignment(HorizontalAlignment.CENTER);
		objCellStyle.setFillForegroundColor(IndexedColors.LIGHT_ORANGE.index);
		objCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		objXssfCell.setCellStyle(objCellStyle);
		
		objXssfRow.createCell(1).setAsActiveCell();
		objXssfRow = objWorkbook.getSheetAt(0).createRow(4);
		objXssfCell = objXssfRow.createCell(0);
		objXssfCell.setCellType(CellType.STRING);
		objXssfCell.setCellValue("Total Test Cases Skipped");
		objCellStyle = objWorkbook.createCellStyle();
		objCellStyle.setAlignment(HorizontalAlignment.CENTER);
		objCellStyle.setFillForegroundColor(IndexedColors.YELLOW.index);
		objCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		objXssfCell.setCellStyle(objCellStyle);
		objXssfRow.createCell(1).setAsActiveCell();
		objXssfRow = objWorkbook.getSheetAt(0).createRow(5);
		objXssfCell = objXssfRow.createCell(0);
		objXssfCell.setCellType(CellType.STRING);
		objXssfCell.setCellValue("Pass Percentage");
		objCellStyle = objWorkbook.createCellStyle();
		objCellStyle.setAlignment(HorizontalAlignment.CENTER);
		objCellStyle.setFillForegroundColor(IndexedColors.GREEN.index);
		objCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		objXssfCell.setCellStyle(objCellStyle);
		objXssfRow.createCell(1).setAsActiveCell();
		objXssfRow = objWorkbook.getSheetAt(0).createRow(6);
		objXssfCell = objXssfRow.createCell(0);
		objXssfCell.setCellType(CellType.STRING);
		objXssfCell.setCellValue("Fail Percentage");
		objCellStyle = objWorkbook.createCellStyle();
		objCellStyle.setAlignment(HorizontalAlignment.CENTER);
		objCellStyle.setFillForegroundColor(IndexedColors.RED.index);
		objCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		objXssfCell.setCellStyle(objCellStyle);
		objXssfRow.createCell(1).setAsActiveCell();
		try {
			objFileOutputStream = new FileOutputStream(objFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			objWorkbook.write(objFileOutputStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try
		{
		objFileOutputStream.close();
		objWorkbook.close();
		objFileInputStream.close();
		}
		catch(IOException exp)
		{
			
		}
		System.out.println("Report Template is updated.....");
		objFile = resetValueBeforeTestExecution(objFile);
		return objFile;
	}
	public  static File resetValueBeforeTestExecution(File objFile)
	{
		try {
			objFileInputStream = new FileInputStream(objFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			objWorkbook = new XSSFWorkbook(objFileInputStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		objXssfSheet = objWorkbook.getSheetAt(0);
		objCellStyle = objWorkbook.createCellStyle();
		objCellStyle.setWrapText(true);
		objCellStyle.setAlignment(HorizontalAlignment.CENTER);
		objXssfCell = objXssfSheet.getRow(1).getCell(1);
		objXssfCell.setCellStyle(objCellStyle);
		objXssfCell.setCellValue("0");
		objCellStyle.setWrapText(true);
		objCellStyle.setAlignment(HorizontalAlignment.CENTER);
		objXssfCell = objXssfSheet.getRow(2).getCell(1);
		objXssfCell.setCellStyle(objCellStyle);
		objXssfCell.setCellValue("0");
		objCellStyle.setWrapText(true);
		objCellStyle.setAlignment(HorizontalAlignment.CENTER);
		objXssfCell = objXssfSheet.getRow(3).getCell(1);
		objXssfCell.setCellStyle(objCellStyle);
		objXssfCell.setCellValue("0");
		objCellStyle.setWrapText(true);
		objCellStyle.setAlignment(HorizontalAlignment.CENTER);
		objXssfCell = objXssfSheet.getRow(4).getCell(1);
		objXssfCell.setCellStyle(objCellStyle);
		objXssfCell.setCellValue("0");
		objCellStyle.setWrapText(true);
		objCellStyle.setAlignment(HorizontalAlignment.CENTER);
		objXssfCell = objXssfSheet.getRow(5).getCell(1);
		objXssfCell.setCellStyle(objCellStyle);
		objXssfCell.setCellValue("0");
		objCellStyle.setWrapText(true);
		objCellStyle.setAlignment(HorizontalAlignment.CENTER);
		objXssfCell = objXssfSheet.getRow(6).getCell(1);
		objXssfCell.setCellStyle(objCellStyle);
		objXssfCell.setCellValue("0");
		try {
			objFileOutputStream = new FileOutputStream(objFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			objWorkbook.write(objFileOutputStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try
		{
		objFileOutputStream.close();
		objWorkbook.close();
		objFileInputStream.close();
		}
		catch(IOException exp)
		{
			
		}
		System.out.println("Data is Reset.. Ready for Test Execution");
		return objFile;
	}
	public  static void setValueAfterTestExecution(File objFile,int rowno)
	{
		try {
			objFileInputStream = new FileInputStream(objFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			objWorkbook = new XSSFWorkbook(objFileInputStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		objXssfSheet = objWorkbook.getSheetAt(0);
		String val = objXssfSheet.getRow(rowno).getCell(1).getStringCellValue();
		System.out.println(val);
		int actualVal = Integer.parseInt(val)+1;
		System.out.println(actualVal);
		objXssfSheet.getRow(rowno).getCell(1).setCellValue(String.valueOf(actualVal));
		try {
			objFileOutputStream = new FileOutputStream(objFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			objWorkbook.write(objFileOutputStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try
		{
		objFileOutputStream.close();
		objWorkbook.close();
		objFileInputStream.close();
		}
		catch(IOException exp)
		{
			
		}
		System.out.println("Value is set after Test Execution.....");
	}
	
	public  static File getTestExecutionReportFile(String filePath)
	{
		File objFile = new File(filePath);
		return objFile;
	}
	
	/*public static File insertChartintoExcel()
	{
		System.out.println(testExecutionReportPath);
		jpegFile = new JFreeUtility().createPieChart();
		objFile = new File(testExecutionReportPath);
		byte[] bytes = null;
		try {
			objFileInputStream = new FileInputStream(jpegFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			objWorkbook = new XSSFWorkbook(objFile);
		} catch (InvalidFormatException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		objXssfSheet = objWorkbook.getSheetAt(0);
		try {
			bytes = IOUtils.toByteArray(objFileInputStream);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		   //Adds a picture to the workbook
		   int pictureIdx = objWorkbook.addPicture(bytes, XSSFWorkbook.PICTURE_TYPE_JPEG);
		   //close the input stream
		   try {
			objFileInputStream.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 //Returns an object that handles instantiating concrete classes
		   CreationHelper helper = objWorkbook.getCreationHelper();
		   //Creates the top-level drawing patriarch.
		   XSSFDrawing drawing = objXssfSheet.createDrawingPatriarch();
		
		 //Create an anchor that is attached to the worksheet
		   ClientAnchor anchor = helper.createClientAnchor();

		   //create an anchor with upper left cell _and_ bottom right cell
		   anchor.setCol1(5); //Column B
		   anchor.setRow1(1); //Row 3
		   anchor.setCol2(6); //Column C
		   anchor.setRow2(6); //Row 4
		
		 //Creates a picture
		   XSSFPicture pict = drawing.createPicture(anchor, pictureIdx);

		   //Reset the image to the original size
		   //pict.resize(); //don't do that. Let the anchor resize the image!

		   //Create the Cell B3
		   XSSFCell cell = objXssfSheet.createRow(15).createCell(1);
		
	        try {
				objFileOutputStream = new FileOutputStream(objFile);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				System.out.println("WorkBook:"+objWorkbook);
				objWorkbook.write(objFileOutputStream);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try
			{
			objFileOutputStream.close();
			objWorkbook.close();
			objFileInputStream.close();
			}
			catch(IOException exp)
			{
				
			}
	        System.out.println("Chart is created");	
	        return objFile;
	}*/
	
	
/*	
	public static void main(String[] args) 
	{
		Excel objExcel = new Excel();
		File objFile = Excel.createExcelFile();
		Excel.getTestExecutionReportFile(testExecutionReportPath);
		Excel.setValueAfterTestExecution(objFile, 3);
		
	}*/
}
