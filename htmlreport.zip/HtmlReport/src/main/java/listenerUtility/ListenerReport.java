package listenerUtility;

import htmlUtility.JCanvasReport;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.testng.ITestClass;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import excelutility.Excel;

public class ListenerReport implements ITestListener
{
	File objFile = null;
	Excel objExcel = null;
	public static int passedTests = 0;
	public static int failedTests = 0;
	public static int skippedTests = 0;
	public static int allTests = 0;
	public static double passedPercentageTests = 0;
	public static double failedPercentageTests = 0;
	static long start;
	static long stop;
	public static Collection<ITestNGMethod> objCollection = null; 
	public static Map<String,Double> objMapTestTime_pass = new HashMap<String,Double>(); 
	public static Map<String,Double> objMapTestTime_fail = new HashMap<String,Double>(); 
	public static Map<String,Double> objMapTestTime_skip = new HashMap<String,Double>(); 

	public static ArrayList<ITestNGMethod> lstOfPassedMethods = new ArrayList<ITestNGMethod>();
	public static ArrayList<ITestNGMethod> lstOfFailedMethods = new ArrayList<ITestNGMethod>();
	public static ArrayList<ITestNGMethod> lstOfSkippedMethods = new ArrayList<ITestNGMethod>();
	
	
	public void onTestStart(ITestResult result) 
	{
		start = result.getStartMillis();
		String dirPath = System.getProperty("user.dir")+"/src/main/resources"+"/appln";
		File[] lstFiles = new File(dirPath).listFiles();
		for(File objFile : lstFiles)
		{
			objFile.delete();
		}
		System.out.println("All test results are cleared....");
	}
	public void onTestSuccess(ITestResult result) 
	{
		/*		if(result.isSuccess())
		{
			String passedTestName =  result.getMethod().getMethodName();
			System.out.println("------"+passedTestName +" is Passed" ); 
		}*/
		System.out.println("------"+result.getMethod().getMethodName() +" is passed" );
		stop = result.getEndMillis();
		getTestName_TimePass(result.getMethod().getMethodName(), getTestExecutionTime(ListenerReport.start, stop));
		System.out.println(getTestName_TimePass(result.getMethod().getMethodName(), getTestExecutionTime(ListenerReport.start, stop)));
		lstOfPassedMethods.add(result.getMethod());
	}

	public void onTestFailure(ITestResult result) 
	{
		System.out.println("------"+result.getMethod().getMethodName() +" is failed" );
		stop = result.getEndMillis();
		lstOfFailedMethods.add(result.getMethod());
	}

	public void onTestSkipped(ITestResult result) 
	{
		System.out.println("------"+result.getMethod().getMethodName() +" is skippped" ); 
		stop = result.getEndMillis();
		lstOfSkippedMethods.add(result.getMethod());
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) 
	{

	}

	public void onStart(ITestContext context) 
	{
		/*String name = context.getName();
		System.out.println("Executing------"+name +" Context" );*/
	}

	public double getTestExecutionTime(long starttime,long endtime)
	{
		double  totalduration =(((endtime-starttime) / (double)1000));
		System.out.println("duration: "+totalduration);
		return totalduration;
	}

	public static HashMap<String,Double> getTestName_TimePass(String testName,double time)
	{
		objMapTestTime_pass.put(testName, time);
		return (HashMap<String, Double>) objMapTestTime_pass;
	}
	public void onFinish(ITestContext context) 
	{
		/*
		passedTests = context.getPassedTests().size();
		failedTests = context.getFailedTests().size();
		skippedTests = context.getSkippedTests().size();*/
		
		passedTests = lstOfPassedMethods.size();
		failedTests = lstOfFailedMethods.size();
		skippedTests = lstOfSkippedMethods.size();
		
		allTests = context.getSuite().getAllMethods().size();
		objCollection = new ArrayList<ITestNGMethod>();
		//objCollection.addAll(context.getPassedTests().getAllMethods());
		objCollection.addAll(lstOfPassedMethods);
		passedPercentageTests = Math.round(((double)ListenerReport.passedTests/(double)ListenerReport.allTests)*100);
		failedPercentageTests = Math.round(((double)(ListenerReport.failedTests+ListenerReport.skippedTests)/(double)ListenerReport.allTests)*100);
		Collection<ITestNGMethod> objCollectionReport = null; 
		HashMap<String, Double> objMap = null;
		objCollectionReport = ListenerReport.objCollection;
		objMap = (HashMap<String, Double>) ListenerReport.objMapTestTime_pass;
		Iterator< ITestNGMethod> objIterator = objCollectionReport.iterator();
		String name = null;

		while(objIterator.hasNext())
		{
			name = objIterator.next().getMethodName();
			if(objMap.containsKey(name))
			{
				objCollectionReport.remove(name);
			}
		}

		Set<String> objTestMethods = objMap.keySet();

		TreeSet<String> objSet =  new TreeSet<String>();
		objSet.addAll(objTestMethods);
		System.out.println(objSet);

		for(int i = 0; i <=objSet.size()-1;i++)
			System.out.println((String)objSet.toArray()[i]+" :"+ objMap.get(objSet.toArray()[i]));

		JCanvasReport objCanvasReport = new JCanvasReport(allTests,passedTests,failedTests,skippedTests);
		objCanvasReport.createHtmlReport();
		objCanvasReport.createJQueryPieReport();
		objCanvasReport.createJQueryDoughNutReport(passedPercentageTests,failedPercentageTests);
		objCanvasReport.createPassedBarChart(objSet,objMap);
	}
}
