package htmlUtility;

import jFreeUtility.JFreeUtility;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.jfree.data.general.DefaultPieDataset;

public class HtmlReport 
{
	static Date objDate = null;
	static SimpleDateFormat objSimpleDateFormat = null;
	static String filePath = System.getProperty("user.dir")+"/src/main/resources/appln/";
	static File objFile = null;
	static String testExecutionReportPath = null;
	static File jpegFileFullReport = null;
	static File jpegFilePassPercentageReport = null;
	static File jpegFilePassReport = null;
	static String reportName_Execution = null;
	static String reportName_Summary = null;
	static String passedReportName = null;
	static Writer objWriter = null;
	static DefaultPieDataset objPieDataset = null;
	public HtmlReport() 
	{
		objDate = new Date();
		objSimpleDateFormat = new SimpleDateFormat("dd_MMM_yyyy");
		objFile = new File(filePath+"TestExecutionReport"+objSimpleDateFormat.format(objDate)+".html");
		jpegFileFullReport = new File(filePath+"TestExecutionReport"+objSimpleDateFormat.format(objDate)+".jpeg");
		jpegFilePassPercentageReport = new File(filePath+"TestSummaryReport"+objSimpleDateFormat.format(objDate)+".jpeg");
		jpegFilePassReport = new File(filePath+"PassedBarChartReport"+objSimpleDateFormat.format(objDate)+".jpeg");
		testExecutionReportPath = objFile.getAbsolutePath();
		reportName_Execution = jpegFileFullReport.getName();
		reportName_Summary = jpegFilePassPercentageReport.getName();
		passedReportName = jpegFilePassReport.getName();
		objPieDataset = (DefaultPieDataset) JFreeUtility.createPieTestExecutionDataSet();
	}

	public static void createHtmlReport(int allTests,int passedTests,int failedtests,int skippedTests)
	{
		try {
			objWriter = new FileWriter(testExecutionReportPath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		StringBuilder objStringBuilder = new StringBuilder();
		objStringBuilder.append("<!DOCTYPE html>");
		objStringBuilder.append("<html>");
		objStringBuilder.append("<title>Test Execution report</title>");
		objStringBuilder.append("<style type=\"text/CSS\">");
		objStringBuilder.append("table, thead,tr, td {border: 1px solid black;} tfoot {color:red;}</style>");
		objStringBuilder.append("<style>a:link {color: black;background-color: transparent;text-decoration: none;}a:hover {color: red;background-color: transparent;text-decoration: underline;}</style>");
		objStringBuilder.append("<body>");
		objStringBuilder.append("<h2 style=\"color: #2e6c80;\" align=\"center\" id=\"report\">Test Execution report:</h2>");
		objStringBuilder.append("<table class=\"editorDemoTable\" align=\"center\" bgcolor=\"#ddefae\">");
		objStringBuilder.append("<thead>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td><center><span><strong style=\"font-size: 17px; color: BLACK;\">Serial No</strong></span></center></td>");
		objStringBuilder.append("<td><center><span><strong style=\"font-size: 17px; color: BLACK;\">Summary</strong></span></center></td>");
		objStringBuilder.append("<td><center><span><strong style=\"font-size: 17px; color: BLACK;\">Count</strong></span></center></td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("</thead>");
		objStringBuilder.append("<tbody>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td><center>1</center></td>");
		objStringBuilder.append("<td><center><span><strong style=\"font-size: 17px; color: Grey;\"><bold>Total No of Test Cases Executed</bold></strong></span></center></td>");
		objStringBuilder.append("<td><center><strong style=\"font-size: 17px; color: Grey;\">");
		objStringBuilder.append(""+allTests+"");
		//	objStringBuilder.append("</a>");
		objStringBuilder.append("</strong></center></td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td><center>2</center></td>");
		objStringBuilder.append("<td><center><span><strong style=\"font-size: 17px; color: Green;\"><bold>Total No of Test Cases Passed</bold></strong></span></center></td>");
		objStringBuilder.append("<td><center><strong style=\"font-size: 17px; color: Green;\">");
		//		objStringBuilder.append("<a href=\"url\">");
		objStringBuilder.append(""+passedTests+"");
		//		objStringBuilder.append("</a>");
		objStringBuilder.append("</strong></center></td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td><center>3</center></td>");
		objStringBuilder.append("<td><center><span><strong style=\"font-size: 17px; color: Red;\"><bold>Total No of Test Cases Failed</bold></strong></span></center></td>");
		objStringBuilder.append("<td><center><strong style=\"font-size: 17px; color: Red;\">");
		//		objStringBuilder.append("<a href=\"url\">");
		objStringBuilder.append(""+failedtests+"");
		//		objStringBuilder.append("</a>");
		objStringBuilder.append("</strong></center></td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td><center>4</center></td>");
		objStringBuilder.append("<td><center><span><strong style=\"font-size: 17px; color: #d1c710;\"><bold>Total No of Test Cases Skipped</bold></strong></span></center></td>");
		objStringBuilder.append("<td><center><strong style=\"font-size: 17px; color: #d1c710;\">");
		//		objStringBuilder.append("<a href=\"url\">");
		objStringBuilder.append(""+skippedTests+"");
		//		objStringBuilder.append("</a>");
		objStringBuilder.append("<tfoot>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td colspan=\"3\"><center>");
		objStringBuilder.append("<a id=\"a1\" href=\""+reportName_Execution+"\">VIEW EXECUTION REPORT");
		objStringBuilder.append("</center></a>");
		objStringBuilder.append("</td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td colspan=\"3\"><center>");
		objStringBuilder.append("<a id=\"a2\" href=\""+reportName_Summary+"\">VIEW SUMMARY REPORT");
		objStringBuilder.append("</center></a>");
		objStringBuilder.append("</td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td colspan=\"3\"><center>");
		objStringBuilder.append("<a id=\"a2\" href=\""+passedReportName+"\">VIEW PASSED TEST EXECUTION REPORT");
		objStringBuilder.append("</center></a>");
		objStringBuilder.append("</td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td colspan=\"3\"><center>");
		objStringBuilder.append("<a id=\"a3\" href=\""+reportName_Summary+"\">VIEW FAILED TEST EXECUTION REPORT");
		objStringBuilder.append("</center></a>");
		objStringBuilder.append("</td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td colspan=\"3\"><center>");
		objStringBuilder.append("<a id=\"a4\" href=\""+reportName_Execution+"\">VIEW SKIPPED TEST EXECUTION REPORT");
		objStringBuilder.append("</center></a>");
		objStringBuilder.append("</td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("</tfoot>");
		objStringBuilder.append("</strong></center></td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("</tbody>");
		objStringBuilder.append("</table>");
		/*objStringBuilder.append("<br>");
		objStringBuilder.append("<br>");
		objStringBuilder.append("<div>");
		objStringBuilder.append("<center>");
		objStringBuilder.append("<span>");
		objStringBuilder.append("<button id=\"btnpieChart\" onclick=\"getPieChart()\">Pie Chart</button>");
		objStringBuilder.append("</span></center>");
		objStringBuilder.append("<br>");*/
		objStringBuilder.append("<script>");
		objStringBuilder.append("function getPieChart() {");
		objStringBuilder.append("document.getElementById(\"img1\").src=\"");
		objStringBuilder.append(reportName_Execution+"\"");
		objStringBuilder.append("}");
		objStringBuilder.append("</script>");
		objStringBuilder.append("<script>");
		objStringBuilder.append("var today = new Date();");
		objStringBuilder.append("document.getElementById(\'report\').innerHTML=\"Test Execution report:\"+today;");
		objStringBuilder.append("</script>");
		/*objStringBuilder.append("<center><span>");
		objStringBuilder.append("<button id=\"btnbarChart\" onclick=\"getBarChart()\">Bar Chart</button>");
		objStringBuilder.append("</span></center>");
		objStringBuilder.append("<br>");*/
		objStringBuilder.append("<script>");
		objStringBuilder.append("function getBarChart() {");
		objStringBuilder.append("document.getElementById(\"img2\").src=\"");
		objStringBuilder.append(reportName_Execution+"\"");
		objStringBuilder.append("}");
		objStringBuilder.append("</script>");
		objStringBuilder.append("</div>");
		/*objStringBuilder.append("<div>");
		objStringBuilder.append("<div>");
		objStringBuilder.append("<div>");
		objStringBuilder.append("<div align=\"center\" >");
		objStringBuilder.append("<img id =\"img1\" src=\"\"></img>");
		objStringBuilder.append("</div>");
		objStringBuilder.append("</div>");
		objStringBuilder.append("</div>");
		objStringBuilder.append("</div>");
		objStringBuilder.append("<div>");
		objStringBuilder.append("<div>");
		objStringBuilder.append("<div>");
		objStringBuilder.append("<div align=\"center\" >");
		objStringBuilder.append("<img id =\"img2\" src=\"\"></img>");
		objStringBuilder.append("</div>");
		objStringBuilder.append("</div>");
		objStringBuilder.append("</div>");
		objStringBuilder.append("</div>");*/
		objStringBuilder.append("</body>");
		objStringBuilder.append("</html>");
		String str = new String(objStringBuilder);
		try {
			objWriter.write(str);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			objWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Html Report is created...");
	}

	public void createJQueryDoughNutReport(int allTests,int passedTests,int failedtests,int skippedTests)
	{
		try {
			objWriter = new FileWriter(testExecutionReportPath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		StringBuilder objStringBuilder = new StringBuilder();
		objStringBuilder.append("<!DOCTYPE HTML>");
		objStringBuilder.append("<html>");
		objStringBuilder.append("<head>");
		objStringBuilder.append("<script>");
		objStringBuilder.append(" window.onload = function () {");
		objStringBuilder.append(" var options = {");
		objStringBuilder.append(" animationEnabled: true,");
		objStringBuilder.append(" title: {");
		objStringBuilder.append(" text: \"Test Execution Report\"");             
		objStringBuilder.append(" },");
		objStringBuilder.append(" data: [{");              
		objStringBuilder.append(" type: \"doughnut\",");
		objStringBuilder.append(" innerRadius: \"40%\",");
		objStringBuilder.append(" showInLegend: true,");
		objStringBuilder.append(" legendText: \"{label}\",");
		objStringBuilder.append(" dataPoints: [");
		objStringBuilder.append(" { label: "+"\"Total Test Cases\""+", y: "+allTests+", color: \"rgb(119, 52, 52)\"}, ");
		objStringBuilder.append(" { label: "+"\"Total Test Cases Passed\""+",  y: "+passedTests+", color: \"Green\" }, ");
		objStringBuilder.append(" { label: "+"\"Total Test Cases Failed\""+",  y: "+failedtests+",  color: \"Red\"}, ");
		objStringBuilder.append(" { label: "+"\"Total Test Cases Skipped\""+",  y: "+skippedTests+",  color: \"Yellow\"}]");
		objStringBuilder.append("}]");
		objStringBuilder.append("};");
		objStringBuilder.append("$(\"#chartContainer\").CanvasJSChart(options);");
		objStringBuilder.append("}");
		objStringBuilder.append("</script>");
		objStringBuilder.append("</head>");
		objStringBuilder.append("<body>");
		objStringBuilder.append("<div id=\"chartContainer\" style=\"height: 370px; width: 100%;\"></div>");
		objStringBuilder.append("<script  src=\"https://canvasjs.com/assets/script/jquery-1.11.1.min.js\"></script>"); 
		objStringBuilder.append("<script  src=\"https://canvasjs.com/assets/script/jquery.canvasjs.min.js\"></script>");
		objStringBuilder.append("</body>");
		objStringBuilder.append("</html>");
		String str = new String(objStringBuilder);
		try {
			objWriter.write(str);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			objWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("JQuery Report is created...");
	}

	public void createJQueryPieReport(int allTests,int passedTests,int failedtests,int skippedTests)
	{
		try {
			objWriter = new FileWriter(testExecutionReportPath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		StringBuilder objStringBuilder = new StringBuilder();
		objStringBuilder.append("<!DOCTYPE html>");
		objStringBuilder.append("<html>");
		objStringBuilder.append("<head>");
		objStringBuilder.append("<meta charset=\"UTF-8\">");
		objStringBuilder.append("<script type=\"text/javascript\">");
		objStringBuilder.append(" window.onload = function () {");
		objStringBuilder.append(" var options = {");
		objStringBuilder.append(" exportEnabled: true,");
		objStringBuilder.append(" animationEnabled: true,");
		objStringBuilder.append(" title: {");
		objStringBuilder.append(" text: \"Test Execution Report\"");             
		objStringBuilder.append("},");
		objStringBuilder.append(" legend:{");
		objStringBuilder.append(" horizontalAlign: \"center\",");
		objStringBuilder.append(" verticalAlign: \"bottom\"");
		objStringBuilder.append("},");
		objStringBuilder.append(" data: [{");              
		objStringBuilder.append(" type: \"pie\",");
		objStringBuilder.append(" showInLegend: true,");
		objStringBuilder.append(" indexLabel: \"{y}\",");
		objStringBuilder.append(" legendText: \"{name}\",");
		objStringBuilder.append(" indexLabelPlacement: \"inside\",");
		objStringBuilder.append(" dataPoints: [");
		objStringBuilder.append("{ y: "+allTests+" ,name: \"Total Test Cases\",  color: \"rgb(119, 52, 52)\"},");
		objStringBuilder.append("{ y: "+passedTests+",  name: \"Total Test Cases Passed\", color: \"Green\" },");
		objStringBuilder.append("{ y: "+failedtests+",  name: \"Total Test Cases Failed\",  color: \"Red\"},");
		objStringBuilder.append("{ y: "+skippedTests+",name: \"Total Test Cases Skipped\",  color: \"Yellow\"  }");
		objStringBuilder.append("]");
		objStringBuilder.append("}");
		objStringBuilder.append("]");
		objStringBuilder.append("};");
		objStringBuilder.append(" $(\"#chartContainer\").CanvasJSChart(options);");
		objStringBuilder.append("}");
		objStringBuilder.append("</script>");
		objStringBuilder.append("</head>");
		objStringBuilder.append("<body>");
		objStringBuilder.append("<div id=\"chartContainer\" style=\"height: 370px; width: 100%;\"></div>");
		objStringBuilder.append("<script type=\"text/javascript\" src=\"https://canvasjs.com/assets/script/jquery-1.11.1.min.js\"></script>"); 
		objStringBuilder.append("<script type=\"text/javascript\" src=\"https://canvasjs.com/assets/script/jquery.canvasjs.min.js\"></script>");
		objStringBuilder.append("</body>");
		objStringBuilder.append("</html>");
		String str = new String(objStringBuilder);
		try {
			objWriter.write(str);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			objWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("JQuery Report is created...");
	}
	
	

	public static void main(String[] args) 
	{
		System.out.println(System.getProperty("user.dir"));
	}
}
