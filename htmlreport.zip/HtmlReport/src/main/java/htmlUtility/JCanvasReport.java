package htmlUtility;

import jFreeUtility.JFreeUtility;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.TreeSet;




import org.jfree.data.general.DefaultPieDataset;
import org.testng.ITestNGMethod;

public class JCanvasReport 
{
	static Date objDate = null;
	static SimpleDateFormat objSimpleDateFormat = null;
	static String filePath = System.getProperty("user.dir")+"/src/main/resources/appln/";
	static File objFile = null;
	static String testExecutionReportPath = null;
	static String testExecutiondoughNutReportPath = null;
	static String testExecutiondoughNutPassPercentageReportPath = null;
	static String testExecutionjpegFilePassBarChartReportPath = null;
	static File doughNutReport = null;
	static File doughNutPassPercentageReport = null;
	static File passBarChartReport = null;
	static String reportName_Execution = null;
	static String reportName_Summary = null;
	static String passedReportName = null;
	static Writer objWriter = null;
	static DefaultPieDataset objPieDataset = null;
	int allTests;
	int passedTests;
	int failedtests;
	int skippedTests;
	static Collection<ITestNGMethod> objCollectionReport = null; 
	static HashMap<String, Double> objMap = null;
	public JCanvasReport(int allTests,int passedTests,int failedtests,int skippedTests) 
	{
		objDate = new Date();
		objSimpleDateFormat = new SimpleDateFormat("dd_MMM_yyyy");
		objFile = new File(filePath+"TestExecutionReport"+objSimpleDateFormat.format(objDate)+".html");
		doughNutReport = new File(filePath+"TestExecutionDoughNutReport"+objSimpleDateFormat.format(objDate)+".html");
		doughNutPassPercentageReport = new File(filePath+"TestDoughnutSummaryReport"+objSimpleDateFormat.format(objDate)+".html");
		passBarChartReport = new File(filePath+"PassedBarChartReport"+objSimpleDateFormat.format(objDate)+".html");
		testExecutionReportPath = objFile.getAbsolutePath();
		reportName_Execution = doughNutReport.getName();
		reportName_Summary = doughNutPassPercentageReport.getName();
		passedReportName = passBarChartReport.getName();
		objPieDataset = (DefaultPieDataset) JFreeUtility.createPieTestExecutionDataSet();
		this.allTests = allTests;
		this.failedtests = failedtests;
		this.passedTests = passedTests;
		this.skippedTests = skippedTests;
		 File obj = null;
		obj = new File(System.getProperty("user.dir")+"/src/main/resources/appln");
		if(!obj.exists())
		{
			System.out.println("Directory doesnt exists creating output Directory..");
			obj.mkdir();
			obj.setExecutable(true);
			obj.setReadable(true);
			obj.setWritable(true);
		}
		else{
		System.out.println("Directory exists ..");
		}
	}
	
	public void createHtmlReport()
	{
		try {
			objWriter = new FileWriter(testExecutionReportPath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		StringBuilder objStringBuilder = new StringBuilder();
		objStringBuilder.append("<!DOCTYPE html>");
		objStringBuilder.append("<html>");
		objStringBuilder.append("<title>Test Execution report</title>");
		objStringBuilder.append("<style type=\"text/CSS\">");
		objStringBuilder.append("table, thead,tr, td {border: 1px solid black;} tfoot {color:red;}</style>");
		objStringBuilder.append("<style>a:link {color: black;background-color: transparent;text-decoration: none;}a:hover {color: red;background-color: transparent;text-decoration: underline;}</style>");
		objStringBuilder.append("<body>");
		objStringBuilder.append("<h2 style=\"color: #2e6c80;\" align=\"center\" id=\"report\">Test Execution report:</h2>");
		objStringBuilder.append("<table class=\"editorDemoTable\" align=\"center\" bgcolor=\"#ddefae\">");
		objStringBuilder.append("<thead>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td><center><span><strong style=\"font-size: 17px; color: BLACK;\">Serial No</strong></span></center></td>");
		objStringBuilder.append("<td><center><span><strong style=\"font-size: 17px; color: BLACK;\">Summary</strong></span></center></td>");
		objStringBuilder.append("<td><center><span><strong style=\"font-size: 17px; color: BLACK;\">Count</strong></span></center></td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("</thead>");
		objStringBuilder.append("<tbody>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td><center>1</center></td>");
		objStringBuilder.append("<td><center><span><strong style=\"font-size: 17px; color: Grey;\"><bold>Total No of Test Cases Executed</bold></strong></span></center></td>");
		objStringBuilder.append("<td><center><strong style=\"font-size: 17px; color: Grey;\">");
		objStringBuilder.append(""+allTests+"");
		//	objStringBuilder.append("</a>");
		objStringBuilder.append("</strong></center></td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td><center>2</center></td>");
		objStringBuilder.append("<td><center><span><strong style=\"font-size: 17px; color: Green;\"><bold>Total No of Test Cases Passed</bold></strong></span></center></td>");
		objStringBuilder.append("<td><center><strong style=\"font-size: 17px; color: Green;\">");
		//		objStringBuilder.append("<a href=\"url\">");
		objStringBuilder.append(""+passedTests+"");
		//		objStringBuilder.append("</a>");
		objStringBuilder.append("</strong></center></td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td><center>3</center></td>");
		objStringBuilder.append("<td><center><span><strong style=\"font-size: 17px; color: Red;\"><bold>Total No of Test Cases Failed</bold></strong></span></center></td>");
		objStringBuilder.append("<td><center><strong style=\"font-size: 17px; color: Red;\">");
		//		objStringBuilder.append("<a href=\"url\">");
		objStringBuilder.append(""+failedtests+"");
		//		objStringBuilder.append("</a>");
		objStringBuilder.append("</strong></center></td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td><center>4</center></td>");
		objStringBuilder.append("<td><center><span><strong style=\"font-size: 17px; color: #d1c710;\"><bold>Total No of Test Cases Skipped</bold></strong></span></center></td>");
		objStringBuilder.append("<td><center><strong style=\"font-size: 17px; color: #d1c710;\">");
		//		objStringBuilder.append("<a href=\"url\">");
		objStringBuilder.append(""+skippedTests+"");
		//		objStringBuilder.append("</a>");
		objStringBuilder.append("<tfoot>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td colspan=\"3\"><center>");
		objStringBuilder.append("<a id=\"a1\" href=\""+reportName_Execution+"\">VIEW EXECUTION REPORT");
		objStringBuilder.append("</center></a>");
		objStringBuilder.append("</td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td colspan=\"3\"><center>");
		objStringBuilder.append("<a id=\"a2\" href=\""+reportName_Summary+"\">VIEW SUMMARY REPORT");
		objStringBuilder.append("</center></a>");
		objStringBuilder.append("</td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td colspan=\"3\"><center>");
		objStringBuilder.append("<a id=\"a2\" href=\""+passedReportName+"\">VIEW PASSED TEST EXECUTION REPORT");
		objStringBuilder.append("</center></a>");
		objStringBuilder.append("</td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td colspan=\"3\"><center>");
		objStringBuilder.append("<a id=\"a3\" href=\""+passedReportName+"\">VIEW FAILED TEST ANALYSIS REPORT");
		objStringBuilder.append("</center></a>");
		objStringBuilder.append("</td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("<tr>");
		objStringBuilder.append("<td colspan=\"3\"><center>");
		objStringBuilder.append("<a id=\"a4\" href=\""+reportName_Execution+"\">VIEW SKIPPED TEST ANALYSIS REPORT");
		objStringBuilder.append("</center></a>");
		objStringBuilder.append("</td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("</tfoot>");
		objStringBuilder.append("</strong></center></td>");
		objStringBuilder.append("</tr>");
		objStringBuilder.append("</tbody>");
		objStringBuilder.append("</table>");
		/*objStringBuilder.append("<br>");
		objStringBuilder.append("<br>");
		objStringBuilder.append("<div>");
		objStringBuilder.append("<center>");
		objStringBuilder.append("<span>");
		objStringBuilder.append("<button id=\"btnpieChart\" onclick=\"getPieChart()\">Pie Chart</button>");
		objStringBuilder.append("</span></center>");
		objStringBuilder.append("<br>");*/
		objStringBuilder.append("<script>");
		objStringBuilder.append("function getPieChart() {");
		objStringBuilder.append("document.getElementById(\"img1\").src=\"");
		objStringBuilder.append(reportName_Execution+"\"");
		objStringBuilder.append("}");
		objStringBuilder.append("</script>");
		objStringBuilder.append("<script>");
		objStringBuilder.append("var today = new Date();");
		objStringBuilder.append("document.getElementById(\'report\').innerHTML=\"Test Execution report:\"+today;");
		objStringBuilder.append("</script>");
		/*objStringBuilder.append("<center><span>");
		objStringBuilder.append("<button id=\"btnbarChart\" onclick=\"getBarChart()\">Bar Chart</button>");
		objStringBuilder.append("</span></center>");
		objStringBuilder.append("<br>");*/
		objStringBuilder.append("<script>");
		objStringBuilder.append("function getBarChart() {");
		objStringBuilder.append("document.getElementById(\"img2\").src=\"");
		objStringBuilder.append(reportName_Execution+"\"");
		objStringBuilder.append("}");
		objStringBuilder.append("</script>");
		objStringBuilder.append("</div>");
	/*	objStringBuilder.append("<script src=\"jquery.js\"></script>");
		objStringBuilder.append("<script>");
		objStringBuilder.append(" $(function(){");
		objStringBuilder.append("$(\"#REPORT\").load(\"TestExecutionDoughNutReport10_Apr_2018.html\");");
		objStringBuilder.append("});");
		objStringBuilder.append("</script>");
		objStringBuilder.append("<script>"); 
		objStringBuilder.append("$(function(){");
		objStringBuilder.append("$(\"#REPORT\").load(\"TestDoughnutSummaryReport10_Apr_2018.html\");");
		objStringBuilder.append("});");
		objStringBuilder.append("</script>");
		objStringBuilder.append("<script>"); 
		objStringBuilder.append("$(function(){");
		objStringBuilder.append("$(\"#REPORT\").load(\"PassedBarChartReport10_Apr_2018.html\");"); 
		objStringBuilder.append("});");
		objStringBuilder.append("</script>"); 
		objStringBuilder.append("<div id=\"REPORT\" style=\"display:none;\"></div>");*/
		objStringBuilder.append("</body>");
		objStringBuilder.append("</html>");
		String str = new String(objStringBuilder);
		try {
			objWriter.write(str);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			objWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Html Report is created...");
	}
	
	
	public void createJQueryDoughNutReport(double passPercentage,double failPercentage)
	{
		try {
			objWriter = new FileWriter(doughNutPassPercentageReport.getAbsolutePath());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		StringBuilder objStringBuilder = new StringBuilder();
		objStringBuilder.append("<!DOCTYPE HTML>");
		objStringBuilder.append("<html>");
		objStringBuilder.append("<head>");
		objStringBuilder.append("<script>");
		objStringBuilder.append(" window.onload = function () {");
		objStringBuilder.append(" var options = {");
		objStringBuilder.append(" exportEnabled: true,");
		objStringBuilder.append(" animationEnabled: true,");
		objStringBuilder.append(" title: {");
		objStringBuilder.append(" text: \"Test Execution Report\"");             
		objStringBuilder.append(" },");
		objStringBuilder.append(" data: [{");              
		objStringBuilder.append(" type: \"doughnut\",");
		objStringBuilder.append(" innerRadius: \"40%\",");
		objStringBuilder.append(" showInLegend: true,");
		objStringBuilder.append(" legendText: \"{label}\",");
		objStringBuilder.append(" dataPoints: [");
		objStringBuilder.append(" { label: "+"\"Total Test Cases Passed\""+",  y: "+(int)passPercentage+", color: \"Green\" }, ");
		objStringBuilder.append(" { label: "+"\"Total Test Cases Failed\""+",  y: "+(int)failPercentage+",  color: \"Red\"}, ");
		objStringBuilder.append("]}]");
		objStringBuilder.append("};");
		objStringBuilder.append("$(\"#chartContainer\").CanvasJSChart(options);");
		objStringBuilder.append("}");
		objStringBuilder.append("</script>");
		objStringBuilder.append("</head>");
		objStringBuilder.append("<body>");
		objStringBuilder.append("<div id=\"chartContainer\" style=\"height: 370px; width: 100%;\"></div>");
		objStringBuilder.append("<script  src=\"https://canvasjs.com/assets/script/jquery-1.11.1.min.js\"></script>"); 
		objStringBuilder.append("<script  src=\"https://canvasjs.com/assets/script/jquery.canvasjs.min.js\"></script>");
		objStringBuilder.append("</body>");
		objStringBuilder.append("</html>");
		String str = new String(objStringBuilder);
		try {
			objWriter.write(str);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			objWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("DoughNutReport is created...");
	}

	public void createJQueryPieReport()
	{
		try {
			objWriter = new FileWriter(doughNutReport.getAbsolutePath());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		StringBuilder objStringBuilder = new StringBuilder();
		objStringBuilder.append("<!DOCTYPE html>");
		objStringBuilder.append("<html>");
		objStringBuilder.append("<head>");
		objStringBuilder.append("<meta charset=\"UTF-8\">");
		objStringBuilder.append("<script type=\"text/javascript\">");
		objStringBuilder.append(" window.onload = function () {");
		objStringBuilder.append(" var options = {");
		objStringBuilder.append(" exportEnabled: true,");
		objStringBuilder.append(" animationEnabled: true,");
		objStringBuilder.append(" title: {");
		objStringBuilder.append(" text: \"Test Execution Report\"");             
		objStringBuilder.append("},");
		objStringBuilder.append(" legend:{");
		objStringBuilder.append(" horizontalAlign: \"center\",");
		objStringBuilder.append(" verticalAlign: \"bottom\"");
		objStringBuilder.append("},");
		objStringBuilder.append(" data: [{");              
		objStringBuilder.append(" type: \"pie\",");
		objStringBuilder.append(" showInLegend: true,");
		objStringBuilder.append(" indexLabel: \"{y}\",");
		objStringBuilder.append(" legendText: \"{name}\",");
		objStringBuilder.append(" indexLabelPlacement: \"inside\",");
		objStringBuilder.append(" dataPoints: [");
		objStringBuilder.append("{ y: "+allTests+" ,name: \"Total Test Cases\",  color: \"rgb(255, 184, 51)\"},");
		objStringBuilder.append("{ y: "+passedTests+",  name: \"Total Test Cases Passed\", color: \"Green\" },");
		objStringBuilder.append("{ y: "+failedtests+",  name: \"Total Test Cases Failed\",  color: \"Red\"},");
		objStringBuilder.append("{ y: "+skippedTests+",name: \"Total Test Cases Skipped\",  color: \"Yellow\"  }");
		objStringBuilder.append("]");
		objStringBuilder.append("}");
		objStringBuilder.append("]");
		objStringBuilder.append("};");
		objStringBuilder.append(" $(\"#chartContainer\").CanvasJSChart(options);");
	/*	objStringBuilder.append(" document.getElementById(\"exportChart\").addEventListener(\"click\",function(){");
		objStringBuilder.append(" chart.exportChart({format: \"jpg\"});});");*/
		objStringBuilder.append("}");
		objStringBuilder.append("</script>");
		objStringBuilder.append("</head>");
		objStringBuilder.append("<body>");
		objStringBuilder.append("<div id=\"chartContainer\" style=\"height: 370px; width: 100%;\"></div>");
		objStringBuilder.append("<script type=\"text/javascript\" src=\"https://canvasjs.com/assets/script/jquery-1.11.1.min.js\"></script>"); 
		objStringBuilder.append("<script type=\"text/javascript\" src=\"https://canvasjs.com/assets/script/jquery.canvasjs.min.js\"></script>");
		objStringBuilder.append("</body>");
		objStringBuilder.append("</html>");
		String str = new String(objStringBuilder);
		try {
			objWriter.write(str);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			objWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("JQuery PieReport is created...");
	}
	
	public void createPassedColumnChart(TreeSet<String> objSet,HashMap<String, Double> objMap)
	{
		try {
			objWriter = new FileWriter(passBarChartReport.getAbsolutePath());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		StringBuilder objStringBuilder = new StringBuilder();
		objStringBuilder.append("<!DOCTYPE HTML>");
		objStringBuilder.append("<html>");
		objStringBuilder.append("<head>");
		objStringBuilder.append("<script>");
		objStringBuilder.append("window.onload = function () {");
		//Better to construct options first and then pass it as a parameter
		objStringBuilder.append(" var chart = new CanvasJS.Chart(\"chartContainer\", { width:1000,");
		objStringBuilder.append(" exportEnabled: true,");
		objStringBuilder.append(" animationEnabled: true,animationDuration: 5000,");
		objStringBuilder.append(" title: {");
		objStringBuilder.append(" text: \"PASSSED TESTS EXECUTION TIME-LINE\" },");   
		objStringBuilder.append(" axisX: {");
		objStringBuilder.append(" title:\"TEST CASES\", "
				+ "gridThickness: 1,"
				+"tickLength: 10 },");
		objStringBuilder.append(" axisY:{ interval: 0.5,");
		objStringBuilder.append(" title:\"TIME(IN SECONDS)\","
				+ "gridThickness: 1,"
				+"tickLength: 10 },");
		objStringBuilder.append(" data: [ {");
		objStringBuilder.append(" type: \"column\", fillOpacity: .4,");
		objStringBuilder.append(" dataPoints: [");
		for(int i = 0; i<=objSet.size()-1;i++)
		{
			objStringBuilder.append("{ label: \""+objSet.toArray()[i]+"\",y: "+objMap.get(objSet.toArray()[i])+",  color: \"Green\"}");
			if(i==objSet.size()-1)
			{
				break;
			}
			else
			{
				objStringBuilder.append(",");
			}
			
		}
		objStringBuilder.append(" ]}]});");
		objStringBuilder.append(" chart.render();");
		objStringBuilder.append(" }");
		objStringBuilder.append(" </script>");
		objStringBuilder.append(" <script type=\"text/javascript\" src=\"https://canvasjs.com/assets/script/canvasjs.min.js\"></script></head>");
		objStringBuilder.append(" <body>");
		objStringBuilder.append(" <div id=\"chartContainer\" style=\"height: 370px; width: 100%;\"></div>");
		objStringBuilder.append(" </body>");
		objStringBuilder.append(" </html>");
		String str = new String(objStringBuilder);
		try {
			objWriter.write(str);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			objWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("JQuery PassBarChart is created...");
	}
	
	public void createPassedBarChart(TreeSet<String> objSet,HashMap<String, Double> objMap)
	{
		try {
			objWriter = new FileWriter(passBarChartReport.getAbsolutePath());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		StringBuilder objStringBuilder = new StringBuilder();
		objStringBuilder.append("<!DOCTYPE HTML>");
		objStringBuilder.append("<html>");
		objStringBuilder.append("<head>");
		objStringBuilder.append("<script>");
		objStringBuilder.append("window.onload = function () {");
		//Better to construct options first and then pass it as a parameter
		objStringBuilder.append(" var options = {");
		objStringBuilder.append(" exportEnabled: true,");
		objStringBuilder.append(" animationEnabled: true,animationDuration: 1500,");
		objStringBuilder.append(" title: {text: \"Passed Test Execution Report\",fontColor: \"Green\"},");
		objStringBuilder.append(" axisY: {title:\"TEST CASES\",tickThickness: 0,lineThickness: 0.5,valueFormatString: \" \",gridThickness: 0},");
		objStringBuilder.append(" axisX: {title:\"Execution Time(in Secs)\",tickThickness: 5,lineThickness: 5,labelFontSize: 15,labelFontColor: \"Green\"}, dataPointWidth: -50, height:1000,");
		objStringBuilder.append("data: [{indexLabelFontSize: 15,"
				+ "toolTipContent: \"<span style=\\\"color:#62C9C3\\\">{indexLabel}:</span> <span style=\\\"color:GREEN\\\"> <strong>{y}</strong></span>\""+","+"");
		objStringBuilder.append("indexLabelPlacement: \"inside\",indexLabelFontColor: \"Green\",indexLabelFontWeight: 300,");
		objStringBuilder.append("indexLabelFontFamily: \"Times New Roman\",color: \"green\",type: \"bar\",fillOpacity: .35,");
		objStringBuilder.append(" dataPoints: [");
		for(int i = 0; i<=objSet.size()-1;i++)
		{
			//objStringBuilder.append("{ label: \""+objSet.toArray()[i]+"\",y: "+objMap.get(objSet.toArray()[i])+",  color: \"Green\"}");
			
			objStringBuilder.append("{y:"+objMap.get(objSet.toArray()[i])+",label:"+"\""+objMap.get(objSet.toArray()[i])+"s"+"\","+"indexLabel:"+"\""+objSet.toArray()[i]+"\""+"}");
			
			if(i==objSet.size()-1)
			{
				break;
			}
			else
			{
				objStringBuilder.append(",");
			}
			
		}
		objStringBuilder.append(" ]}]};");
		objStringBuilder.append(" $(\"#chartContainer\").CanvasJSChart(options);");
		objStringBuilder.append(" }");
		objStringBuilder.append(" </script></head>");
		objStringBuilder.append(" <body>");
		objStringBuilder.append(" <div id=\"chartContainer\" style=\"height: 500px; width: 112%;\"></div>");
		objStringBuilder.append(" <script type=\"text/javascript\" src=\"https://canvasjs.com/assets/script/jquery-1.11.1.min.js\"></script>");
		objStringBuilder.append(" <script type=\"text/javascript\" src=\"https://canvasjs.com/assets/script/jquery.canvasjs.min.js\"></script>");
		objStringBuilder.append(" </body>");
		objStringBuilder.append(" </html>");
		String str = new String(objStringBuilder);
		try {
			objWriter.write(str);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			objWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("JQuery PassBarChart is created...");
	}
	
	
	
}
