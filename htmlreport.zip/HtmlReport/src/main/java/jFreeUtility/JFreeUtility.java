package jFreeUtility;

import java.awt.Color;
import java.awt.SystemColor;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import listenerUtility.ListenerReport;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.testng.ITestNGMethod;

public class JFreeUtility 
{
	static String filePath = System.getProperty("user.dir")+"/src/main/resources/appln/";
	static Date objDate = null;
	static SimpleDateFormat objSimpleDateFormat = null;
	static DefaultPieDataset objPieDataset = null;
	static DefaultCategoryDataset objCategoryDataset = null;
	static Collection<ITestNGMethod> objCollectionReport = null; 
	static HashMap<String, Double> objMap = null;
	public DefaultCategoryDataset createBarChartData()
	{
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		objCollectionReport = ListenerReport.objCollection;
		objMap = (HashMap<String, Double>) ListenerReport.objMapTestTime_pass;
		Iterator< ITestNGMethod> objIterator = objCollectionReport.iterator();
		String name = null;

		while(objIterator.hasNext())
		{
			name = objIterator.next().getMethodName();
			if(objMap.containsKey(name))
			{
				objCollectionReport.remove(name);
			}
		}

		Set<String> objTestMethods = objMap.keySet();

		TreeSet<String> objSet =  new TreeSet<String>();
		objSet.addAll(objTestMethods);
		System.out.println(objSet);
		for(int i = 0; i<=objSet.size()-1;i++)
		{
			dataset.addValue(objMap.get(objSet.toArray()[i]), "Passed Test Cases",(Comparable) objSet.toArray()[i]);
		}

		/* dataset.addValue(objMap.get(objMap.keySet().toArray()[1]), "Passed Test Cases",(Comparable) objMap.keySet().toArray()[1]);
		 dataset.addValue(objMap.get(objMap.keySet().toArray()[2]), "Passed Test Cases",(Comparable) objMap.keySet().toArray()[2]);*/

		return dataset;
	}

	public  static PieDataset createPieTestExecutionDataSet()
	{
		DefaultPieDataset objPieDataset = new DefaultPieDataset();
		objPieDataset.setValue("Total Test Cases\n "+ListenerReport.allTests,ListenerReport.allTests);
		objPieDataset.setValue("Total Test Cases Passed\n "+ListenerReport.passedTests, ListenerReport.passedTests);
		objPieDataset.setValue("Total Test Cases Failed\n "+ListenerReport.failedTests, ListenerReport.failedTests);
		objPieDataset.setValue("Total Test Cases Skipped\n "+ListenerReport.skippedTests, ListenerReport.skippedTests);
		return objPieDataset;
	}

	public static PieDataset createPieSummaryDataSet()
	{
		DefaultPieDataset objPieDataset = new DefaultPieDataset();
		objPieDataset.setValue("Pass Percentage\n "+Math.round(((double)ListenerReport.passedTests/(double)ListenerReport.allTests)*100), Math.round(((double)ListenerReport.passedTests/(double)ListenerReport.allTests)*100));
		objPieDataset.setValue("Fail Percentage\n "+Math.round(((double)(ListenerReport.failedTests+ListenerReport.skippedTests)/(double)ListenerReport.allTests)*100), Math.round(((double)(ListenerReport.failedTests+ListenerReport.skippedTests)/(double)ListenerReport.allTests)*100));
		return objPieDataset;
	}
	public File[] createPieChart()
	{
		File objFile[] = new File[2];

		JFreeChart chart1 = ChartFactory.createPieChart(
				"Test Execution Report",   // chart title
				createPieTestExecutionDataSet(),          // data
				true,             // include legend
				true,
				false);

		PiePlot plot = (PiePlot) chart1.getPlot();
		plot.setSectionPaint(createPieTestExecutionDataSet().getKey(0), new Color(102, 51, 0));
		plot.setSectionPaint(createPieTestExecutionDataSet().getKey(1), new Color(48, 193, 15));
		plot.setSectionPaint(createPieTestExecutionDataSet().getKey(2), new Color(252, 7, 7));
		plot.setSectionPaint(createPieTestExecutionDataSet().getKey(3), new Color(255, 255, 102));
		JFreeChart chart2 = ChartFactory.createPieChart(
				"Test Summary Report",   // chart title
				createPieSummaryDataSet(),          // data
				true,             // include legend
				true,
				false);
		PiePlot plot2 = (PiePlot) chart2.getPlot();
		plot2.setSectionPaint(createPieSummaryDataSet().getKey(0), new Color(13, 86, 12));
		plot2.setSectionPaint(createPieSummaryDataSet().getKey(1), new Color(119, 8, 8));
		int width = 1000;   /* Width of the image */
		int height = 1000;  /* Height of the image */ 

		objDate = new Date();
		objSimpleDateFormat = new SimpleDateFormat("dd_MMM_yyyy");
		File pieChartTestExecution = new File(filePath+"/TestExecutionReport"+objSimpleDateFormat.format(objDate)+".jpeg"); 
		File pieChartTestSummary = new File(filePath+"/TestSummaryReport"+objSimpleDateFormat.format(objDate)+".jpeg"); 
		try {
			ChartUtilities.saveChartAsJPEG( pieChartTestExecution , chart1 , width , height );
			ChartUtilities.saveChartAsJPEG( pieChartTestSummary , chart2 , width , height );
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pieChartTestExecution.canExecute();
		pieChartTestExecution.canRead();
		pieChartTestExecution.canWrite();
		pieChartTestSummary.canExecute();
		pieChartTestSummary.canRead();
		pieChartTestSummary.canWrite();
		objFile[0] = pieChartTestExecution;
		objFile[1] = pieChartTestSummary;
		System.out.println("PieCharts are created....");
		return objFile;
	}

	public File createBarChart()
	{
		JFreeChart chart = ChartFactory.createBarChart(
				"Passed Tests Execution Time Line",   // chart title
				"Passed Tests",
				"Time (in Seconds)",
				createBarChartData(),            
				PlotOrientation.VERTICAL,             
				true, true, false);
		CategoryPlot objCategoryPlot = chart.getCategoryPlot();
		objCategoryPlot.setBackgroundPaint(SystemColor.inactiveCaption);
		objCategoryPlot.getRangeAxis().setLowerBound(0.0);
		//		objCategoryPlot.getRangeAxis().setRange(0.0, 0.25);
		objCategoryPlot.getRangeAxis().setUpperBound(60.0);

		BarRenderer objCategoryBarRenderer = (BarRenderer)objCategoryPlot.getRenderer();
		objCategoryBarRenderer.setSeriesPaint(0, Color.GREEN);
		int width = 1000;   /* Width of the image */
		int height = 1000;  /* Height of the image */ 
		objDate = new Date();
		objSimpleDateFormat = new SimpleDateFormat("dd_MMM_yyyy");
		File objBarChart = new File(filePath+"/PassedBarChartReport"+objSimpleDateFormat.format(objDate)+".jpeg"); 
		try {
			ChartUtilities.saveChartAsJPEG( objBarChart , chart , width , height );
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Bar Chart is created....");
		objBarChart.canExecute();
		objBarChart.canRead();
		objBarChart.canWrite();
		return objBarChart;
	}
	/*public static void main(String[] args) 
	{
		JFreeUtility.createPieChart();

	}*/
}
