package dummytest;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(listenerUtility.ListenerReport.class)
public class TestDummy2 
{
	@Test
	public void TestA1()
	{
		System.out.println("Inside TestA");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Assert.assertEquals(true, true);
	}
	@Test
	public void TestB1()
	{
		System.out.println("Inside TestB");
		Assert.assertEquals(true, true);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test(dependsOnMethods="TestB1")
	public void TestC1()
	{
		System.out.println("Inside TestC");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test(dependsOnMethods="TestA1")
	public void TestD1()
	{
		System.out.println("Inside TestD");
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test(dependsOnMethods="TestB1")
	public void TestE1()
	{
		System.out.println("Inside TestE");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test(dependsOnMethods="TestB1")
	public void TestF1()
	{
		System.out.println("Inside TestF");
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test(dependsOnMethods="TestA1")
	public void TestG1()
	{
		System.out.println("Inside TestG");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
