package dummytest;

import java.io.File;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

public class MasterTestNG 
{
	static File obj = null;
	@BeforeTest
	public void setUp()
	{
		
	}
	
	@AfterTest
	public void cleanUp()
	{
		if(obj.exists())
		{
			obj.delete();
		}
	}

}
