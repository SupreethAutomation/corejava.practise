package com.java.oops.interfaces;

public class ClassA 
{
	public void methodA()
	{
		System.out.println("methodA of ClassA");
	}
}
