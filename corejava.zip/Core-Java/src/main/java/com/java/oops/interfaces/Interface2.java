package com.java.oops.interfaces;

public interface Interface2 {
int a = 100;
}
