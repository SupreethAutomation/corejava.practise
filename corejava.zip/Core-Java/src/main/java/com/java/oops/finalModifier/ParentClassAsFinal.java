package com.java.oops.finalModifier;

public final class ParentClassAsFinal 
{
	public void access()
	{
		System.out.println("Cant access the method from subclass becos parent class is final");
	}
}
