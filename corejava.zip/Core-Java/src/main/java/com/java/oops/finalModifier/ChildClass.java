package com.java.oops.finalModifier;

public class ChildClass //extends ParentClassAsFinal 
{
	// compile Time Error : The type ChildClass cannot subclass the final class ParentClassAsFinal	
	
	
}
