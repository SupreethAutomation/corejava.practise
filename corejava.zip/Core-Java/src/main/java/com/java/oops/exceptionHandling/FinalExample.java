package com.java.oops.exceptionHandling;

final class A
{
	
}

/*
class B extends A
{
	//The type B cannot subclass the final class A
}

*/

class C
{
	final int a=10;
	
	final void cannotOverRideMe()
	{
		System.out.println("Cannot override me");
	}
}

class D extends C
{
	/*
	public void cannotOverRideMe()
	{
		//cannotOverRideMe
	}
	*/
	
	public void accessVariable()
	{
		// a = 20;
		//The final field C.a cannot be assigned
		System.out.println(a);
	}
}

public class FinalExample 
{
	
}
