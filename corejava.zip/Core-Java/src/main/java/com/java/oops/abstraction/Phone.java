package com.java.oops.abstraction;

public class Phone 
{
	private String modelNo;
	
	private String modelName;
	
	public String getModelNo() {
		return modelNo;
	}
	public void setModelNo(String modelNo) {
		this.modelNo = modelNo;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	
	public void recieveCall()
	{
		System.out.println(modelName + " Phone is receiving a call");
	}
	
	public void requestCall()
	{
		System.out.println(modelName + " Phone is requesting a call");
	}
}
