package com.java.oops.exceptionHandling;

public class TryFinally 
{
	public static void checkTryFinally()
	{
		try
		{
			System.out.println(10/0);
		}
		finally
		{
			System.out.println("PLease close all DB connection.");
		}
	}
}
