package com.java.oops.exceptionHandling;

public class ExceptionIn2Methods 
{
	public void doStuff()
	{
		domoreStuff();
		int a = 10 / 0;
		System.out.println("This is not printed by doStuffMethod because of exception");
	}
	
	public void domoreStuff()
	{
		System.out.println("Hello");
	}
}
