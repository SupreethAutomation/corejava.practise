package com.java.oops.array;

public class TwoDArray 
{
	private int[][] deptIdDeptMgrID = new int[2][5];


	public void setDept()
	{
		int p = 10;

		for(int i = 0;i<=deptIdDeptMgrID.length-1;i++)
		{
			for(int j = 0;j<=deptIdDeptMgrID[i].length-1;j++)
			{
				deptIdDeptMgrID[i][j]= p;
				p+=10;
			}
		}
	}

	public void getDept()
	{
		System.out.println("Array length:"+deptIdDeptMgrID.length);
		
		System.out.println("Array contents: ");
		for(int i = 0;i<=deptIdDeptMgrID.length-1;i++)
		{
			for(int j = 0;j<=deptIdDeptMgrID[i].length-1;j++)
			{
				System.out.print(deptIdDeptMgrID[i][j]+" ");
			}
		}
	}
}
