package com.java.oops.nestedInterfaces;

public interface Vehicle 
{
	public interface Tempo
	{
		 public void startTempo();
		 public void stopTempo();
	}
}
