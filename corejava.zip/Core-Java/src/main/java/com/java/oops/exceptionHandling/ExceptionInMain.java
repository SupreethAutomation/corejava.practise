package com.java.oops.exceptionHandling;

public class ExceptionInMain 
{
	public void doStuff()
	{
		domoreStuff();
		System.out.println("Hi from domorestuff");
	}
	
	public void domoreStuff()
	{
		System.out.println("Hello from DomoreStuff");
	}
}
