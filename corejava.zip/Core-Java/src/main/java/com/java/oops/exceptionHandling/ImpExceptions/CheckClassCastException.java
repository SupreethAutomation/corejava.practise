package com.java.oops.exceptionHandling.ImpExceptions;

import com.java.oops.CompileTimePolymorphism.Overriding.Father;
import com.java.oops.CompileTimePolymorphism.Overriding.Son;

public class CheckClassCastException 
{
	public static void riseClassCastException()
	{
		Father objFather = new Father("Muralidhar");
		Son objSon = (Son) objFather;
	}
}
