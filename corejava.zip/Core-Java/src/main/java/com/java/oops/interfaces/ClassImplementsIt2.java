package com.java.oops.interfaces;

public class ClassImplementsIt2 implements It2
{
	public void m1() {
		System.out.println("Class ClassImplementsIt2 override m1");
		
	}

	public void m2() {
		System.out.println("Class ClassImplementsIt2 override m2");
		
		
	}

}
