package com.java.oops.interfaces;

public interface InterfaceWithVariables 
{
	int a = 10 ; // by default they are public static and final
	int b = 10 ;
}
