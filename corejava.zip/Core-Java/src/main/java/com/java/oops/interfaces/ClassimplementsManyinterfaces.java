package com.java.oops.interfaces;

public class ClassimplementsManyinterfaces implements It1,It2,It3
{

	public void m1() {
		System.out.println("Class ClassimplementsManyinterfaces override m1");
	}

	public void m2() {
		System.out.println("Class ClassimplementsManyinterfaces override m2");
	}

	public void m3() {
		System.out.println("Class ClassimplementsManyinterfaces override m3");
	}
}
