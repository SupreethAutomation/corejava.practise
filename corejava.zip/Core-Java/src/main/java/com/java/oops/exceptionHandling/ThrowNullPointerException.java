package com.java.oops.exceptionHandling;

public class ThrowNullPointerException 
{
	static ArithmeticException e;
	public static void throwNullPointerException()
	{
		throw e;
	}
}
