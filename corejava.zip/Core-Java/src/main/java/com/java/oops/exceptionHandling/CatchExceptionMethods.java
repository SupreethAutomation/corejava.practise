package com.java.oops.exceptionHandling;

public class CatchExceptionMethods 
{
	public static void getCatchExceptionMethods()
	{
		try
		{
			int x = 10/0;
		}catch(Exception e)
		{
			e.printStackTrace();
			/*java.lang.ArithmeticException: / by zero
	at com.java.oops.exceptionHandling.CatchExceptionMethods.getCatchExceptionMethods(CatchExceptionMethods.java:9)
	at com.test.oops.exceptionHandling.TestCatchExceptionMethods.main(TestCatchExceptionMethods.java:8)*/
			
			
			
			System.out.println("e.toString(): "+e.toString());
			/*
			 *  java.lang.ArithmeticException: / by zero
			 */ 
			
			System.out.println("e.getMessage(): "+e.getMessage());
			/*
			  / by zero 
			*/
		}
	}
}
