package com.java.oops.hasARelation;

public class Department 
{
	private String deptName;
	private String deptID;
	private String deptLocation;
	private Employee deptHead;
	public Employee getDeptHead() {
		return deptHead;
	}
	public void setDeptHead(Employee deptHead) {
		this.deptHead = deptHead;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getDeptID() {
		return deptID;
	}
	public void setDeptID(String deptID) {
		this.deptID = deptID;
	}
	public String getDeptLocation() {
		return deptLocation;
	}
	public void setDeptLocation(String deptLocation) {
		this.deptLocation = deptLocation;
	}

	public void displayDeptDetails()
	{
		System.out.println("Dept Name: "+deptName);
		System.out.println("Dept ID: "+deptID);
		System.out.println("Dept Location: "+deptLocation);
		System.out.println("Dept Head: "+getDeptHead().getEmpName());
	}



}
