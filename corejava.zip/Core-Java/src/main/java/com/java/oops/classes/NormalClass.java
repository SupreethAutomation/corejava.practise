package com.java.oops.classes;

public class NormalClass extends AbstractClassWithStaticInstanceBlocks
{
	
	public NormalClass() 
	{
		System.out.println("Normal Class Constructor");
	}

	@Override
	void m1() {
		 System.out.println("This is method M1");
		
	}
	
}