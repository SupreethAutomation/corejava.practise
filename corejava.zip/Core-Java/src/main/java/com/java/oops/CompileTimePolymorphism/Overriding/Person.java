package com.java.oops.CompileTimePolymorphism.Overriding;

public class Person 
{
	protected void m1()
	{
		System.out.println("protected method of class Person");
	}
	
	void m2()
	{
		System.out.println("package method of class Person");
	}
	
	public void m3()
	{
		System.out.println("public method of class Person");
	}
	
}
