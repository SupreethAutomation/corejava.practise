package com.java.oops.exceptionHandling;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class CheckedException 
{
	public void compilerCheckClassNotFoundException() throws ClassNotFoundException
	{
		Class.forName("com.java.oops.classes.Person");
	}
	
	public void compilerCheckFileNotFoundException() throws FileNotFoundException
	{
		PrintWriter objPrintWriter = new PrintWriter("abc.txt");
		objPrintWriter.print("Hello");
		objPrintWriter.close();
	}
	
	public void compilerCheckIOException() throws IOException 
	{
		FileReader objFileReader = new FileReader("xyz.txt");
		objFileReader.read();
		objFileReader.close();
	}
	
	public void compilerCheckInterruptedException() throws InterruptedException 
	{
		Thread.sleep(5000);
	}
}
