package com.java.oops.interfaces;

public class ClassImplementsIt1 implements It1
{
	public void m1() {
		System.out.println("Class ClassImplementsIt1 override m1");
		
	}

}
