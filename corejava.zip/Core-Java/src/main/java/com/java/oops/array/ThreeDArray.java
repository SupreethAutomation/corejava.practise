package com.java.oops.array;

public class ThreeDArray 
{
	private int[][][] deptIdDeptMgrID = new int[2][5][7];

	// 2 multi-dimensional array
	// [0][5][7]
	// [1][5][7]
	// 1st multi-dimensional array consists of  [0][5][7]
	//[0][0][7],[0][1][7],[0][2][7],[0][3][7],[0][4][7]

	// 2nd multi-dimensional array consists of  [1][5][7]
	//[1][0][7],[1][1][7],[1][2][7],[1][3][7],[1][4][7]

	// 1st multi-dimensional array consists of  
	/*
		 [0][0][0],[0][0][1],[0][0][2],[0][0][3],[0][0][4],[0][0][5],[0][0][6]
		 [0][1][0],[0][1][1],[0][1][2],[0][1][3],[0][1][4],[0][1][5],[0][1][6]
		 [0][2][0],[0][2][1],[0][2][2],[0][2][3],[0][2][4],[0][2][5],[0][2][6]
		 [0][3][0],[0][3][1],[0][3][2],[0][3][3],[0][3][4],[0][3][5],[0][3][6]
		 [0][4][0],[0][4][1],[0][4][2],[0][4][3],[0][4][4],[0][4][5],[0][4][6]

	 */
	// 2nd multi-dimensional array consists of  
	/*
			 [1][0][0],[1][0][1],[1][0][2],[1][0][3],[1][0][4],[1][0][5],[1][0][6]
			 [1][1][0],[1][1][1],[1][1][2],[1][1][3],[1][1][4],[1][1][5],[1][1][6]
			 [1][2][0],[1][2][1],[1][2][2],[1][2][3],[1][2][4],[1][2][5],[1][2][6]
			 [1][3][0],[1][3][1],[1][3][2],[1][3][3],[1][3][4],[1][3][5],[1][3][6]
			 [1][4][0],[1][4][1],[1][4][2],[1][4][3],[1][4][4],[1][4][5],[1][4][6]

	 */

	public void setDept()
	{
		int p = 10;

		for(int i = 0;i<=deptIdDeptMgrID.length-1;i++)
		{
			for(int j = 0;j<=deptIdDeptMgrID[i].length-1;j++)
			{
				for(int k = 0;k<=deptIdDeptMgrID[i][j].length-1;k++)
				{
					deptIdDeptMgrID[i][j][k]= p;
					p+=10;
				}
			}
		}
	}

	public void getDept()
	{
		System.out.println("Array length:"+deptIdDeptMgrID.length);
		System.out.println("Array length:"+deptIdDeptMgrID[0].length);
		System.out.println("Array length:"+deptIdDeptMgrID[1].length);
		System.out.println("Array contents: ");
		for(int i = 0;i<=deptIdDeptMgrID.length-1;i++)
		{
			System.out.println("");
			for(int j = 0;j<=deptIdDeptMgrID[i].length-1;j++)
			{
				System.out.println("");
				for(int k = 0;k<=deptIdDeptMgrID[i][j].length-1;k++)
				{
					System.out.print(deptIdDeptMgrID[i][j][k]+" ");
				}
			}
		}
	}
}
