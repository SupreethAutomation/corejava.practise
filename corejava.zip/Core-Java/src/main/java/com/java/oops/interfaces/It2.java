package com.java.oops.interfaces;

public interface It2 extends It1
{
	public void m2();
}
