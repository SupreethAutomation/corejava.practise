package com.java.oops.exceptionHandling.ImpExceptions;

public class CheckIllegalArgumentExecption {

}
