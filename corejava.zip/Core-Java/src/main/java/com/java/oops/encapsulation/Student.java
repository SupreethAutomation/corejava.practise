package com.java.oops.encapsulation;

//Encapsulation: Binding data with the methods

public class Student 
{
	private String studentName;
	private String studentID;
	
	public String getStudentName()
	{
		return this.studentName;
	}
	
	public String getStudentID()
	{
		return this.studentID;
	}
	
	public void setStudentName(String studentName)
	{
		this.studentName = studentName;
	}
	
	public void setStudentID(String studentID)
	{
		this.studentID = studentID;
	}
}
