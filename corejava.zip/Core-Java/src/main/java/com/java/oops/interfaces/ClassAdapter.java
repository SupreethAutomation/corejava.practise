package com.java.oops.interfaces;

public class ClassAdapter implements InterfaceAdapter
{

	public void m1() {
		// TODO Auto-generated method stub
		
	}

	public void m2() {
		// TODO Auto-generated method stub
		
	}

	public void m3() {
		// TODO Auto-generated method stub
		
	}

	public void m4() {
		// TODO Auto-generated method stub
		
	}

	public void m5() {
		// TODO Auto-generated method stub
		
	}

	public void m6() {
		// TODO Auto-generated method stub
		
	}

	public void m7() {
		// TODO Auto-generated method stub
		
	}

	public void m8() {
		// TODO Auto-generated method stub
		
	}

	public void m9() {
		// TODO Auto-generated method stub
		
	}

	public void m10() {
		// TODO Auto-generated method stub
		
	}

}
