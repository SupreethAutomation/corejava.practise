package com.java.oops.CompileTimePolymorphism.OverLoading;

public class Calculator_OperatorOverLoading 
{
	public Calculator_OperatorOverLoading(int a, int b) 
	{
		System.out.println(a+b);
	}
	
	public Calculator_OperatorOverLoading(String str1, String str2) 
	{
		System.out.println(str1+str2);
	}
	
	public Calculator_OperatorOverLoading(String str1, int b) 
	{
		System.out.println(str1+b);
	}
}
