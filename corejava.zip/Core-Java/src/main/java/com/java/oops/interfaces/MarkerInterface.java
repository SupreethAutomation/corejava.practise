package com.java.oops.interfaces;

public interface MarkerInterface {

}

/*
 * Compiled from "Serializable.java"
public interface java.io.Serializable {
}
 * 
 * 
 * */

/*
 * Compiled from "RandomAccess.java"
public interface java.util.RandomAccess {
}
 * 
 * 
 */

/*
 * Compiled from "Cloneable.java"
public interface java.lang.Cloneable {
}
 * 
 */
