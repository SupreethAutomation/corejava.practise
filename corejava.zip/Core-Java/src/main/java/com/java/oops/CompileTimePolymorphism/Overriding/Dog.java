package com.java.oops.CompileTimePolymorphism.Overriding;

public class Dog extends Animal
{
	public Dog eat()
	{
		System.out.println("Inside Dog class");
		return new Dog();
	}
}
