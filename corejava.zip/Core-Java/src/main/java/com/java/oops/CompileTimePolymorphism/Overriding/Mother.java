package com.java.oops.CompileTimePolymorphism.Overriding;

public class Mother 
{
	private int receipe;
	private void cook()
	{
		System.out.println("Mother is cooking privately");
	}
}
