package com.java.oops.classes;

public class NonAbstractClass extends AbstractClass
{

	@Override
	public void m1() {
		System.out.println("This is overridden method m1 within nonabstract class");
		
	}

	@Override
	public void m2() {
		System.out.println("This is overridden method m2 within nonabstract class");
		
	}

	@Override
	public void m3() {
		System.out.println("This is overridden method m3 within nonabstract class");
		
	}

}
