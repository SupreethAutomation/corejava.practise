package com.java.oops.nestedInterfaces;

public class InterfaceWithInClass implements Dog.Animal
{

	public void sleep() {
		System.out.println("Sleeping");
		
	}

}
