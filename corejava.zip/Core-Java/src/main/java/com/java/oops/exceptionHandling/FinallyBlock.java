package com.java.oops.exceptionHandling;

public class FinallyBlock 
{
	static int a ;
	public static void TestFinallyBlock()
	{
		try
		{
			a = 10/0;
		}
		catch (ArithmeticException e) {
			a = 10/2;
		}
		catch (Exception e) {
			
		}
		finally {
			a = 10/10;
		}
		System.out.println("Final value with finally:" +a);
	}
	
	public static void TestwithoutFinallyBlock()
	{
		try
		{
			a = 10/0;
		}
		catch (ArithmeticException e) {
			a = 10/2;
		}
		catch (Exception e) {
			
		}
		System.out.println("Final value without finally:" +a);
	}
}
