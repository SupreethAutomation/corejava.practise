package com.java.oops.exceptionHandling.ImpExceptions;

public class CheckExceptionInInitializerError 
{
	// Exception occured while executing static block or static variable initialization
	
	static int a= 10/0;
	
	public static void riseExceptionInInitializerError()
	{
		System.out.println(a);
	}
}
