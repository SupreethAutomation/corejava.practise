package com.java.oops.interfaces;

public interface It4 extends It1,It2,It3
{
	public void m4();
}
