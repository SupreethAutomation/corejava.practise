package com.java.oops.exceptionHandling;

public class NestedTryBlock 
{
	public static void checkNestedTryBlock()
	{
		try {
			System.out.println("Inside Try 1");
			try {
				System.out.println("Inside Try 2");
				System.out.println(10/0);
			}catch(Exception e1)
			{
				System.out.println("Inside catch 2");
			}
		}
		catch(Exception e2)
		{
			System.out.println("Inside catch 1");
		}
	}
}
