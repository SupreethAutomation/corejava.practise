package com.java.oops.nestedInterfaces;

public class Dog 
{
	interface Animal
	{
		public void sleep();
	}
}
