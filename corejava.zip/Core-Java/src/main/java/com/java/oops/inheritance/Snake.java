package com.java.oops.inheritance;

public class Snake extends Animal
{
	public void hiss()
	{
		System.out.println(getAnimalName() + "is hissing");
	}
}
