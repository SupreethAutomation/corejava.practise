package com.java.oops.classes;

public abstract class AbstractClass 
{
	public abstract void m1();
	public abstract void m2();
	public abstract void m3();
	public void concreteMethod()
	{
		System.out.println("This is concrete method within abstract class");
	}
}

