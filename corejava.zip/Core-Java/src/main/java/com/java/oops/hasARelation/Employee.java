package com.java.oops.hasARelation;

public class Employee 
{
	private String empName;
	private String empID;
	private double salary;
	private Department objDept;
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpID() {
		return empID;
	}
	public void setEmpID(String empID) {
		this.empID = empID;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Department getObjDept() {
		return objDept;
	}
	public void setObjDept(Department objDept) {
		this.objDept = objDept;
	}

	public void displayEmployeeDetails()
	{
		System.out.println("Employee Name: "+empName);
		System.out.println("Employee ID: "+empID);
		System.out.println("Employee salary: "+salary);
		System.out.println("DeptName: "+this.getObjDept().getDeptName());
	}
}
