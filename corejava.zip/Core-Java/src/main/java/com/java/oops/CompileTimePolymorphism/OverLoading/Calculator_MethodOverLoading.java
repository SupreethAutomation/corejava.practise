package com.java.oops.CompileTimePolymorphism.OverLoading;

/*
 * Class containing more than 1 method with same method name 
 * with different no of arguments or different argument data type
 * 
 */

public class Calculator_MethodOverLoading 
{
	public void add(int a)
	{
		System.out.println("Result: "+ (a+a));
	}

	public void add(char c)
	{
		System.out.println("Result: "+ (c+c));
	}
	
	public void add(int a, int b)
	{
		System.out.println("Result: "+ (a+b));
	}

	public void add(int a,double d)
	{
		System.out.println("Result: "+ (a+d));
	}

	public void add(int a,String str2)
	{
		System.out.println("Result: "+ (a + str2));
	}

	public void add(String str1,String str2)
	{
		System.out.println("Result: "+ (str1 + str2));
	}

}
