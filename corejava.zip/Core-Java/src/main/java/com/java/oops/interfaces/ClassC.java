package com.java.oops.interfaces;

public class ClassC extends ClassB
{
	public void m2() {
		System.out.println("overridden method m2 of ClassC");	
	}

}
