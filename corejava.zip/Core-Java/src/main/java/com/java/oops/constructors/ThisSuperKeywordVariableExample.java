package com.java.oops.constructors;

class A 
{
	int a = 10;
	int b = 20;
	
	
}
public class ThisSuperKeywordVariableExample extends A 
{
	int a = 30;
	int b = 40;
	
	public ThisSuperKeywordVariableExample(int a, int b) 
	{
		System.out.println("a from local: "+ a + "b from local: "+ b);
		System.out.println("a from current class: "+ this.a + "b from current class: "+ this.b);
		System.out.println("a from super class: "+ super.a + "b from super class: "+ super.b);
	}
}


