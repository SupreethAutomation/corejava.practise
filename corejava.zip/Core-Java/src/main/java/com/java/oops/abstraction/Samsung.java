package com.java.oops.abstraction;

public class Samsung extends Phone 
{

}
