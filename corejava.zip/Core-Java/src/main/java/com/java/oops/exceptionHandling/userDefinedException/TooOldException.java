package com.java.oops.exceptionHandling.userDefinedException;

public class TooOldException extends RuntimeException 
{
	public TooOldException(String s) 
	{
		super(s);
	}
}
