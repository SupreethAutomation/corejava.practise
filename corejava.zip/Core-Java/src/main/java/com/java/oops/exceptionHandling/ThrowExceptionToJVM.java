package com.java.oops.exceptionHandling;

public class ThrowExceptionToJVM 
{
	public static void throwExceptionManually()
	{
		throw new ArithmeticException("Division by ZERO");
	}
	
}
