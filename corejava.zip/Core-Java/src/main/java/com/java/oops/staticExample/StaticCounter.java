package com.java.oops.staticExample;

public class StaticCounter 
{
	static int counter;
	
}



