package com.java.oops.interfaces;

public class Pulsar implements Vehicle
{

	public void ignitionON() 
	{
		System.out.println("Pulsar ignition ON");
	}

	public void changeGear() {
		System.out.println("Pulsar change gear");
		
	}

	public void accelerate() {
		System.out.println("Pulsar accelerate");
		
	}

	public void applyBrakes() {
		System.out.println("Pulsar Applybrakes at humps and on stopage");
		
	}

	public void ignitionOFF() {
		System.out.println("Pulsar ignition OFF");
		
	}

	public void deAccelerate() {
		System.out.println("Pulsar deAccelerate");
		
	}

}
