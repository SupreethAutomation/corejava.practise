package com.java.oops.CompileTimePolymorphism.Overriding;

public class Daughter extends Mother
{
	private void cook()
	{
		System.out.println("Daughter is cooking privately");
	}
}
