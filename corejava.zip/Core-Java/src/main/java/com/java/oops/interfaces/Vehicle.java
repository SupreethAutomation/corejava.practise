package com.java.oops.interfaces;

public interface Vehicle 
{
	public void ignitionON();
	public void changeGear();
	public void accelerate();
	public void deAccelerate();
	public void applyBrakes();
	public void ignitionOFF();
}
