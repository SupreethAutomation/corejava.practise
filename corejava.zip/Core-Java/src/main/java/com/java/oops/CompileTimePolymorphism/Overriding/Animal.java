package com.java.oops.CompileTimePolymorphism.Overriding;

public class Animal 
{
	public Animal eat()
	{
		System.out.println("Inside Animal class");
		return new Animal();
	}
}
