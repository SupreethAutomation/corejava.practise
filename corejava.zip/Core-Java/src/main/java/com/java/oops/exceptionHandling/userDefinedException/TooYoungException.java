package com.java.oops.exceptionHandling.userDefinedException;

public class TooYoungException extends RuntimeException
{
	public TooYoungException(String s) 
	{
		super(s);
	}
}
