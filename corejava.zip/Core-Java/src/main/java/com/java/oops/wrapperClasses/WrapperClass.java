package com.java.oops.wrapperClasses;

public class WrapperClass 
{
	Byte objByte;
	Short objShort;
	Integer objInteger;
	Long objLong;
	Float objFloat;
	Double objDouble;
	Character objCharacter;
	Boolean objBoolean;
	
	public WrapperClass(byte b,short s,int i,long l,float f,double d,char c,boolean isBool) 
	{
		objByte = Byte.valueOf(b);
		objShort = Short.valueOf(s);
		objInteger = Integer.valueOf(i);
		objLong = Long.valueOf(l);
		objFloat = Float.valueOf(f);
		objDouble = Double.valueOf(d);
		objCharacter = Character.valueOf(c);
		objBoolean = Boolean.valueOf(isBool);
	}
	
	public void displayValues()
	{
		System.out.println(objByte.byteValue());
		System.out.println(objShort.shortValue());
		System.out.println(objInteger.intValue());
		System.out.println(objLong.longValue());
		System.out.println(objFloat.floatValue());
		System.out.println(objDouble.doubleValue());
		System.out.println(objCharacter.charValue());
		System.out.println(objBoolean.booleanValue());
	}
}
