package com.java.oops.exceptionHandling;

public class OnlyTryNoCatch_OnlyCatchwithoutTry_OnlyFinally 
{
	public static void OnlyTry()
	{
		/*try
		{
			System.out.println("value: "+10/0);
		}*/
		//Syntax error, insert "Finally" to complete BlockStatements
	}
	
	public static void OnlyCatchWithoutTry()
	{
		/*
		catch(Exception e)
		{
			System.out.println("value: "+10/0);
		}*/
		//Syntax error on token "catch", for expected
	}
	
	public static void OnlyFinally()
	{
		/*finally
		{
			System.out.println("value: "+10/0);
		}*/
		//Syntax error on token "finally",
	}
}
