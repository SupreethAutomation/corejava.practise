package com.java.oops.interfaces;

public class ClassImplementsIt4ExtendingManyInterfaces implements It4
{

	public void m1() {
		System.out.println("Class ClassImplementsIt4ExtendingManyInterfaces override m1");
		
	}

	public void m2() {
		System.out.println("Class ClassImplementsIt4ExtendingManyInterfaces override m2");
		
		
	}

	public void m3() {
		System.out.println("Class ClassImplementsIt4ExtendingManyInterfaces override m3");
		
	}

	public void m4() {
		System.out.println("Class ClassImplementsIt4ExtendingManyInterfaces override m4");
		
	}

}
