package com.java.oops.CompileTimePolymorphism.Overriding;

public class Father 
{
	String name;
	
	public Father(String name) {
		this.name = name;
	}
	
	public void eat()
	{
		System.out.println(name+" eats only healthy food");
	}
}
