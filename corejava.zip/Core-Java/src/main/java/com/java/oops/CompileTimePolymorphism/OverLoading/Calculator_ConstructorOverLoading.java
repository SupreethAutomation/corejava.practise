package com.java.oops.CompileTimePolymorphism.OverLoading;

public class Calculator_ConstructorOverLoading 
{
	int a;
	int b;
	double d;
	char c;
	String str;
	
	public Calculator_ConstructorOverLoading()
	{
		System.out.println("a: "+this.a);
		System.out.println("b: "+this.b);
		System.out.println("c: "+this.c);
		System.out.println("str: "+this.str);
		System.out.println("d: "+this.d);
	}
	
	public Calculator_ConstructorOverLoading(int a)
	{
		this.a = a;
		System.out.println("a: "+this.a);
		System.out.println("b: "+this.b);
		System.out.println("c: "+this.c);
		System.out.println("str: "+this.str);
		System.out.println("d: "+this.d);
	}
	
	public Calculator_ConstructorOverLoading(int a , int b)
	{
		this.a = a;
		this.b = b;
		System.out.println("a: "+this.a);
		System.out.println("b: "+this.b);
		System.out.println("c: "+this.c);
		System.out.println("str: "+this.str);
		System.out.println("d: "+this.d);
	}
	
	public Calculator_ConstructorOverLoading(int a, double d)
	{
		this.a = a;
		this.d = d;
		System.out.println("a: "+this.a);
		System.out.println("b: "+this.b);
		System.out.println("c: "+this.c);
		System.out.println("str: "+this.str);
		System.out.println("d: "+this.d);
	}
	
	public Calculator_ConstructorOverLoading(String str, char c)
	{
		this.str = str;
		this.c = c;
		System.out.println("a: "+this.a);
		System.out.println("b: "+this.b);
		System.out.println("c: "+this.c);
		System.out.println("str: "+this.str);
		System.out.println("d: "+this.d);
	}
	
	public Calculator_ConstructorOverLoading(char c)
	{
		this.c = c;
		System.out.println("a: "+this.a);
		System.out.println("b: "+this.b);
		System.out.println("c: "+this.c);
		System.out.println("str: "+this.str);
		System.out.println("d: "+this.d);
	}
	
}
