package com.java.oops.CompileTimePolymorphism.Overriding;

public class Son extends Father
{
	public Son(String fatherName,String name) {
		super(fatherName);
		this.name = name;
		// TODO Auto-generated constructor stub
	}
	@Override
	public void eat()
	{
		System.out.println(name+" eats only junk food");
	}
}
