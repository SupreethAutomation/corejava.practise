package com.java.oops.exceptionHandling;

import java.io.IOException;

public class NeverThrownFromTry
{
	public static void exception1()
	{
		try {
			System.out.println("Hello in Exp1");
		} catch (ArithmeticException e) {
			// TODO: handle exception
		}
	}
	
	public static void exception2()
	{
		try {
			System.out.println("Hello in Exp2 ");
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public static void exception3()
	{
		/*
		try {
			System.out.println("Hello");
		} catch (IOException e) {
			// TODO: handle exception
		}
		*/
		//Unreachable catch block for IOException. This exception is never thrown from the try statement body
	}
	
	public static void exception4()
	{/*
		
		try {
			System.out.println("Hello");
		} catch (InterruptedException e) {
			// TODO: handle exception
		}
		*/
		//Unreachable catch block for IOException. This exception is never thrown from the try statement body
	}
	
	public static void exception5()
	{
		try {
			System.out.println("Hello in Exp5");
		} catch (Error e) {
			// TODO: handle exception
		}
	}
	
}
