package com.java.oops.interfaces;

public class MarkerInterfaceUsage implements Cloneable
{
	public int a;
	public int b;
}
