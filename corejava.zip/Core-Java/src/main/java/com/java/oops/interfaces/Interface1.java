package com.java.oops.interfaces;

public interface Interface1 
{
	int a = 10;
}
