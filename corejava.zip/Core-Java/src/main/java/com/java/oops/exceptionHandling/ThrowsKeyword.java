package com.java.oops.exceptionHandling;

public class ThrowsKeyword 
{
	public static void explicitWait() throws InterruptedException 
	{
		Thread.sleep(5000);
	}
}
