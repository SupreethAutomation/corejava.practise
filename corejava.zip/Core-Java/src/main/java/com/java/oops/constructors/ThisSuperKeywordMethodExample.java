package com.java.oops.constructors;

class Parent
{
	public void method1()
	{
		System.out.println("Parent class method1");
	}
	
	Parent()
	{
		System.out.println("Parent class constructor");
	}
}

public class ThisSuperKeywordMethodExample extends Parent
{
	public void method1()
	{
		System.out.println("Child class method1");
	}
	public ThisSuperKeywordMethodExample() 
	{
		System.out.println("Child class constructor");
		method1();
		this.method1();
		super.method1();
	}
	
}
