package com.java.oops.exceptionHandling;

import com.java.oops.classes.Person;

public class UnCheckedException 
{
	public int checkArithmeticException(int x)
	{
		return (x/0);
	}
	
	public Person checkNullPointerException()
	{
		return null;
	}
	
	public int checkIndexOutOfBoundsException(int arr[])
	{
		return arr[10];
	}
}
