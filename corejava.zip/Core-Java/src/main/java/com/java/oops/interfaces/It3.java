package com.java.oops.interfaces;

public interface It3 extends It2
{
	public void m3();
}
