package com.java.oops.exceptionHandling;

public class DefaultExceptionHandler 
{
	public void doStuff()
	{
		domoreStuff();
		System.out.println("This is not printed by doStuffMethod");
	}
	
	public void domoreStuff()
	{
		int a = 10 / 0;
		System.out.println("This is not printed by doMoreStuffMethod");
	}
}
