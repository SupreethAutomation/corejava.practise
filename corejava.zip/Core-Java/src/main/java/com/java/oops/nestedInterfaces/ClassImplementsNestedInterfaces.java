package com.java.oops.nestedInterfaces;

public class ClassImplementsNestedInterfaces implements Vehicle.Tempo
{

	public void startTempo() {
		System.out.println("Starting Tempo");
		
	}

	public void stopTempo() {
		System.out.println("Stoping Tempo");
		
	}

}
