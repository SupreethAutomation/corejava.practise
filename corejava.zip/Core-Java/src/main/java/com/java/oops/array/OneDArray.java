package com.java.oops.array;

public class OneDArray 
{
	private int[] marks = new int[5];
	
	public void setMarks()
	{
		int j = 10;
		for(int i = 0;i<=marks.length-1;i++)
		{
			marks[i]= j;
			j+=10;
		}
	}
	
	public void getMarks()
	{
		System.out.println("Array contents: ");
		for(int i = 0;i<=marks.length-1;i++)
		{
			System.out.print(marks[i]+" ");
		}
	}
}
