package com.java.oops.inheritance;

public class Animal 
{
	private String animalName;

	public String getAnimalName() {
		return animalName;
	}

	public void setAnimalName(String animalName) {
		this.animalName = animalName;
	}
	
	public void sleep()
	{
		System.out.println(animalName + " is sleeping");
	}
	
	public void eat()
	{
		System.out.println(animalName + " is eating");
	}
	
}
