package com.java.oops.interfaces;

public abstract class Activa implements Vehicle
{

	public void ignitionON() {
		System.out.println("Activa ignition ON");
		
	}

	public void accelerate() {
		System.out.println("Activa acclerate");
		
	}

	public void deAccelerate() {
		System.out.println("Activa de-acclerate");
		
	}

	public void applyBrakes() {
		System.out.println("Activa applybrakes");
		
	}

	public void ignitionOFF() {
		System.out.println("Activa ignition OFF");
		
	}

}
