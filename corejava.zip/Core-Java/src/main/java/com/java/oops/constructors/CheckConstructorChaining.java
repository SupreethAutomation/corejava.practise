package com.java.oops.constructors;


public class CheckConstructorChaining 
{
	public CheckConstructorChaining() 
	{
		this(10);
		System.out.println("No Arg Constructor");
	}
	
	public CheckConstructorChaining(int i) 
	{
		this(12.33, 13.22);
		System.out.println("1 Arg Constructor");
	}
	
	public CheckConstructorChaining(double d1, double d2) 
	{
		System.out.println("2 Arg Constructor");
	}
}
