package com.java.oops.exceptionHandling;

public class ThrowsForConstructors 
{
	public int a;
	public ThrowsForConstructors() throws ArithmeticException
	{
		a = 10/0;
	}
}
