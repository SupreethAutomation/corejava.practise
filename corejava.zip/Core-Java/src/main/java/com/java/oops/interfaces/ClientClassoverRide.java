package com.java.oops.interfaces;

public class ClientClassoverRide extends ClassAdapter
{
	public void m1()
	{
		System.out.println("OverRidden method m1 of AdapterClass");
	}
	
	public void m10()
	{
		System.out.println("OverRidden method m10 of AdapterClass");
	}
}
