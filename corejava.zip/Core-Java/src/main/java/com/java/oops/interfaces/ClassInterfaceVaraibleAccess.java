package com.java.oops.interfaces;

public class ClassInterfaceVaraibleAccess implements Interface1,Interface2
{
	public void method1()
	{
	//	System.out.println(a); int a = 10 ;
		
		System.out.println("value of a from interface 1:"+Interface1.a);
		System.out.println("value of a from interface 2:"+Interface2.a);
	}
}
