package com.java.oops.interfaces;

public abstract class ClassB extends ClassA implements It1,It2
{
	public void methodB()
	{
		System.out.println("methodB of ClassB");
	}

	public void m1() {
		System.out.println("overridden method m1 of ClassB");	
	}
}
