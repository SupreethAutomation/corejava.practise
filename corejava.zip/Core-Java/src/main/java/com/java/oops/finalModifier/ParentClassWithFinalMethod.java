package com.java.oops.finalModifier;

public class ParentClassWithFinalMethod 
{
	public final void cantOverRide()
	{
		System.out.println("Final methods cant be overridden");
	}
}
