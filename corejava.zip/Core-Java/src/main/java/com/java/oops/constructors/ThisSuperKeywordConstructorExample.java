package com.java.oops.constructors;

class SuperClass
{
	int a,b;
	public SuperClass(int a, int b) 
	{
		System.out.println("super class 2-Arg constructor");
		this.a = a;
		this.b = b;
	}
}

public class ThisSuperKeywordConstructorExample extends SuperClass
{
	int a,b;
	public ThisSuperKeywordConstructorExample(int x, int y) 
	{
		super((x+1),(y+1));
		this.a = 10;
		this.b = 20;
		System.out.println("Child class constructor");
		System.out.println("this.a: "+this.a);
		System.out.println("this.b: "+ this.b);
		System.out.println("super a: "+ super.a);
		System.out.println("super b: "+ super.b);
	}
	
}
