package com.java.oops.classes;

public abstract class AbstractClassWithStaticInstanceBlocks 
{
	public AbstractClassWithStaticInstanceBlocks() 
	{
		System.out.println("Abstract Class Constructor");
	}
	
	static 
	{
		System.out.println("Static block1 in abstract class");
	}
	
	static 
	{
		System.out.println("Static block2 in abstract class");
	}
	
	 
	{
		System.out.println("instance block in abstract class");
	}
	
		
	abstract void m1();
	
	 public void m2()
	 {
		 System.out.println("This is method M2");
	 }
	 
}

