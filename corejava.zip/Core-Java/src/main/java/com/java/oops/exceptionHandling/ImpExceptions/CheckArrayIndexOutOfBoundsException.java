package com.java.oops.exceptionHandling.ImpExceptions;

public class CheckArrayIndexOutOfBoundsException 
{
	public static void checkArrayElements(int arr[])
	{
		for(int i = 1; i <= arr.length; i++)
		{
			System.out.println("value at "+i+" is "+arr[i]);
		}
	}
}
