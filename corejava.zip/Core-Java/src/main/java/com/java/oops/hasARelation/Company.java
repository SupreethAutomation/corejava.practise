package com.java.oops.hasARelation;

public class Company 
{
	Employee[] objEmployees;
	Department[] objDepartment;
	public Employee[] getObjEmployees() {
		return objEmployees;
	}
	public void setObjEmployees(Employee[] objEmployees) {
		this.objEmployees = objEmployees;
	}
	public Department[] getObjDepartment() {
		return objDepartment;
	}
	public void setObjDepartment(Department[] objDepartment) {
		this.objDepartment = objDepartment;
	}

	public int getCompanyStrength()
	{
		return this.objEmployees.length;
	}

	public int getDeptStrength()
	{
		return this.objDepartment.length;
	}
	
	public void displayCompanyDetails()
	{
		for(Employee objEmployee : getObjEmployees())
		{
			objEmployee.displayEmployeeDetails();
			System.out.println("***************");
		}
		
		for(Department objDepartment : getObjDepartment())
		{
			objDepartment.displayDeptDetails();
			System.out.println("***************");
		}
	}
	
	

}
