package com.java.oops.exceptionHandling.ImpExceptions;

public class CheckStackOverFlowError 
{
	public static void m1()
	{
			m2();
	}
	
	public static void m2()
	{
			m1();
	}
}
