package com.java.oops.classes;

public class Person 
{
	/* 
	 * attribute : name;age;gender;address
	 * methods:eat,sleep, work,
	 */
	
	public String name;
	public int age;
	public char gender;
	public String address;
	
	
	public void eat()
	{
		System.out.println(name+" eats");
	}
	public void sleep()
	{
		System.out.println(name+" sleeps");
	}
	public void work()
	{
		System.out.println(name+" works");
	}
	
	public void displayPersonDetails()
	{
		System.out.println("name "+"is "+name);
		System.out.println("age "+"is "+age);
		System.out.println("gender "+"is "+gender);
		System.out.println("address "+"is "+address);
	}
	
}
