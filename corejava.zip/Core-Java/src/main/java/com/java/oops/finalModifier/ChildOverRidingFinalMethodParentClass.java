package com.java.oops.finalModifier;

public class ChildOverRidingFinalMethodParentClass extends ParentClassWithFinalMethod
{
	//public void cantOverRide(): Cannot override the final method from ParentClassWithFinalMethod
	{
		
	}
}
