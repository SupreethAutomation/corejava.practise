package com.java.oops.abstraction;

public class PhoneRepair 
{
	public void repairPhone(Phone objPhone)
	{
		objPhone.requestCall();
		objPhone.recieveCall();
	}
}
