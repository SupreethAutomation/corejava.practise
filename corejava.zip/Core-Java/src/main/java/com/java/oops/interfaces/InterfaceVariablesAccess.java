package com.java.oops.interfaces;

public class InterfaceVariablesAccess implements InterfaceWithVariables
{
	public void m1()
	{
		// a = a+10; The final field InterfaceWithVariables.a cannot be assigned
		
		System.out.println("The value is b :"+b);
	}
}
