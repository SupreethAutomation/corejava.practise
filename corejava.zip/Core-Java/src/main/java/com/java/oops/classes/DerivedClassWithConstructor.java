package com.java.oops.classes;

public class DerivedClassWithConstructor extends AbstractClassWithConstructor
{

	@Override
	public void m1() {
		System.out.println("overriddden method m1");
		
	}

	@Override
	public void m2() {
		System.out.println("overriddden method m2");
		
	}

	@Override
	public void m3() {
		System.out.println("overriddden method m3");
		
	}

	public DerivedClassWithConstructor() 
	{
		super();
		System.out.println("This is DerivedClassWithConstructor");
	}
	
}
