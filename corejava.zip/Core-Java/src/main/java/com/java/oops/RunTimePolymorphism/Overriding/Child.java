package com.java.oops.RunTimePolymorphism.Overriding;

public class Child extends Parent
{
	public void m1()
	{
		System.out.println("Overrided method of Child");
	}
	
	public void m2()
	{
		System.out.println("instance method of Child");
	}
}
