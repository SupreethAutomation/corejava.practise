package com.java.oops.classes;

public abstract class AbstractClassWithConstructor {
	public abstract void m1();
	public abstract void m2();
	public abstract void m3();
	public void concreteMethod()
	{
		System.out.println("This is concrete method within abstract class");
	}
	public AbstractClassWithConstructor() 
	{
		System.out.println("This is AbstractClassWithConstructor within abstract class");
	}
	
}
