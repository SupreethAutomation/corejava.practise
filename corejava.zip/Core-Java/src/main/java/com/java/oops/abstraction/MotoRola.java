package com.java.oops.abstraction;

public class MotoRola extends Phone
{
	
}
