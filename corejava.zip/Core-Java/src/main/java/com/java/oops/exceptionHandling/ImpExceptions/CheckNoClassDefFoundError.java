package com.java.oops.exceptionHandling.ImpExceptions;

public class CheckNoClassDefFoundError 
{
	public static void checkNoClassDefFound()
	{
		//When JVM is not able to find the particular class to execute at runtime.
	}
}
