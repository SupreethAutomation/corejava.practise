package com.java.oops.exceptionHandling;

public class CustomizedExceptionHandling 
{
	public void divideByZero(int num)
	{
		System.out.println("Stmt1");
		try
		{
			System.out.println(num/0);
		}
		catch(ArithmeticException exp)
		{
			System.out.println("Exception occurred so printing catch block statment divide "+num+" by 2:"+(num/2));
		}
		System.out.println("Stmt3");
	}
}
