package com.java.oops.interfaces;

public interface It1 
{
	public void m1();
}
