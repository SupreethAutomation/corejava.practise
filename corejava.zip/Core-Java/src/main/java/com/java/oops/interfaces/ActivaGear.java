package com.java.oops.interfaces;

public class ActivaGear extends Activa
{

	public void changeGear() {
		System.out.println("Activa-Gear change gear");
		
	}

}
