package com.java.oops.finalModifier;

public class ClassWithFinalVariable 
{
	public static void main(String[] args) 
	{
		final int a = 50;
		System.out.println("value of a "+  a);
		// a = a + 10; The type ChildClass cannot subclass the final class ParentClassAsFinal
	}
}
