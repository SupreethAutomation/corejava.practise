package com.java.oops.exceptionHandling;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class ControlFlowInTryCatch 
{
	public static void checkControlFlowInTryCatchNormalTermination()
	{
		try
		{
			System.out.println("stmt--1");
			System.out.println("stmt--2");
			System.out.println("stmt--3");
		}
		catch(Exception exp)
		{
			System.out.println("stmt--4");
		}
		System.out.println("stmt--5");
	}
	
	public static void checkControlFlowInTryCatchExceptionatStmt1NormalTermination()
	{
		try
		{
			System.out.println(10/0);
			System.out.println("stmt--1");
			System.out.println("stmt--3");
		}
		catch(Exception exp)
		{
			System.out.println("stmt--4");
		}
		System.out.println("stmt--5");
	}
	
	public static void checkControlFlowInTryCatchExceptionatStmt2NormalTermination()
	{
		try
		{
			System.out.println("stmt--1");
			System.out.println(10/0);
			System.out.println("stmt--3");
		}
		catch(Exception exp)
		{
			System.out.println("stmt--4");
		}
		System.out.println("stmt--5");
	}
	
	public static void checkControlFlowInTryCatchExceptionatStmt3NormalTermination()
	{
		try
		{
			System.out.println("stmt--1");
			System.out.println("stmt--2");
			System.out.println(10/0);
		}
		catch(Exception exp)
		{
			System.out.println("stmt--4");
		}
		System.out.println("stmt--5");
	}
}
