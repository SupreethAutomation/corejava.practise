package com.java.oops.exceptionHandling.ImpExceptions;

import com.java.oops.encapsulation.Student;

public class CheckNullPointerException 
{
	public static void checkNullPointerException(Student objStudent)
	{
		System.out.println(objStudent.getStudentID());
	}
}
