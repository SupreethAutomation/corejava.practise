package com.java.oops.interfaces;

public class ClassImplementsIt3 implements It3
{
	public void m1() {
		System.out.println("Class ClassImplementsIt3 override m1");
		
	}

	public void m2() {
		System.out.println("Class ClassImplementsIt3 override m2");
		
		
	}

	public void m3() {
		System.out.println("Class ClassImplementsIt3 override m3");
		
	}

}
