package com.java.oops.CompileTimePolymorphism.Overriding;

public class Employee extends Person
{
	/*void m1() Cannot reduce the visibility of the inherited method from Person
	{
		System.out.println("protected method of class Person");
	}*/
	
	public void m1() // increase the access level
	{
		
	}
	
	void m2() // same level
	{
		System.out.println("protected method of class Person");
	}
	
	 /*private void m3() Cannot reduce the visibility of the inherited method from Person
	{
		System.out.println("protected method of class Person");
	}*/
}
