package com.java.oops.staticExample;

public class Parent_StaticMethod 
{
	public static void m1()
	{
		System.out.println("Inside static method M1 of Parent class");
	}
}
