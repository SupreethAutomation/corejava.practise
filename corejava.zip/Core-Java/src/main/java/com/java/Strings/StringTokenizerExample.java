package com.java.Strings;

import java.util.StringTokenizer;

public class StringTokenizerExample 
{
	public void tokenizationByDefault(String strInput)
	{
		StringTokenizer objStringTokenizer = new StringTokenizer(strInput);
		//default pattern for StringTokenizer is space
		while(objStringTokenizer.hasMoreTokens())
		{
			System.out.println(objStringTokenizer.nextToken());
		}
	}
	
	public void tokenizationByDelim(String strInput,String delim)
	{
		StringTokenizer objStringTokenizer = new StringTokenizer(strInput,delim);
		//default pattern for StringTokenizer is space
		while(objStringTokenizer.hasMoreTokens())
		{
			System.out.println(objStringTokenizer.nextToken());
		}
	}
	
	
}
