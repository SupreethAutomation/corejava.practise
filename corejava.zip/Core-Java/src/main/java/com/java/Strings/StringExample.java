package com.java.Strings;

public class StringExample 
{
	String resStr = null;
	public void concatExample(String str1,String str2)
	{
		resStr = str1.concat(str2);
		System.out.println("cancatenation of "+str1+" " + "and " +str2+ " : "+resStr);
	}

	public void displayCharAt(String str)
	{
		for(int i = 0; i <=str.length()-1; i++)
			System.out.println("Character at position "+(i+1)+" : "+str.charAt(i));
	}

	public void displayCharCodePointAt(String str)
	{
		for(int i = 0; i <=str.length()-1; i++)
			System.out.println("AscII value of "+str.charAt(i)+" : "+str.codePointAt(i));
	}

	public void copyStringToCharArray(String str,char[] arr)
	{
		str.getChars(0, str.length(), arr, 0);
		System.out.print("contents of the copied array: ");
		for(int i =0; i <=arr.length-1;i++)
			System.out.print(arr[i]);
		System.out.println();
	}
	
	public void areStringEqual(String str1,String str2)
	{
		System.out.println(str1+" " + "and " +str2+ " are equal : "+str1.equals(str2));
	}

	public void verifyStringwithCharacterArray(String str,CharSequence objCS)
	{
		System.out.println(str+" " + "and " +objCS.toString()+ " are equal : "+str.contentEquals(objCS));
	}
	
	public void areStringEqualIgnoreCase(String str1,String str2)
	{
		System.out.println(str1+" " + "and " +str2+ " are equal : "+str1.equalsIgnoreCase(str2));
	}
	
	public void compareStringslexicographically(String str1,String str2)
	{
		System.out.println(str1+" " + "and " +str2+ " are equal : "+str1.compareTo(str2));
	}
	
	public void matchesRegion(String str1,String str2,int offset,int noofChars)
	{
		System.out.println(str1+" " + "and " +str2+ " are equal : "+str1.regionMatches(offset-1,str2,offset-1,noofChars));
	}
	
	public void stringCheckPrefix(String str,String prefix,int from)
	{
		System.out.println(str+" " + "starts with " +prefix+ " @position "+from+" from "+str.startsWith(prefix,from));
	}
	
	public void stringCheckSuffix(String str,String suffix)
	{
		System.out.println(str+" " + "endsWith " +suffix+ " : "+str.endsWith(suffix));
	}
	
	public void getFirstOccurenceOfCharacterInString(String str,int ch)
	{
			System.out.println("First Occurence Of "+str.indexOf(ch)+" in "+str);
	}
	
	public void getFirstOccurenceOfCharacterInStringFrom(String str,int ch,int from)
	{
			System.out.println("First Occurence Of "+str.indexOf(ch,from)+" in "+str+" from position "+ from );
	}
	
	public void getLastOccurenceOfCharacterInString(String str,int ch)
	{
			System.out.println("Last Occurence Of "+str.lastIndexOf(ch)+" in "+str);
	}
	
	public void getLastOccurenceOfCharacterInStringFrom(String str,int ch,int from)
	{
			System.out.println("Last Occurence Of "+str.lastIndexOf(ch,from)+" in "+str+" from position "+ from );
	}
	
	public void cutStringfrom(String str, int cutFrom)
	{
		System.out.println("Substring of " +str+ " is "+ str.substring(cutFrom));
	}
	
	public void cutStringbyRange(String str, int cutFrom, int cutTo)
	{
		System.out.println("Substring of " +str+ " is "+ str.substring(cutFrom,cutTo));
	}
	
	public void replace(String str,char fromCh, char toCh)
	{
		System.out.println("Replace of " +str+ " by replacing "+ fromCh + " to "+toCh+ " = "+str.replace(fromCh, toCh));
	}
	
	public void split(String str,String splitStr)
	{
		String[] strTokens = str.split(splitStr);
		for (String strToken : strTokens)
		{
			System.out.println(strToken);
		}
	}
	
	public void patternMatchesInput(String pattern, String input)
	{
		System.out.println("The "+input+" matches the regExp pattern "+pattern+" : "+input.matches(pattern));
	}
	
	
	public void getSubString(int start,int end,String input)
	{
		System.out.println("The SubString of "+input+" from "+start+" to "+end+" is "+input.substring(start, end));
	}
	
	public void displayValueOf(int i, double d, float f, char c,Object obj,boolean b)
	{
		System.out.println("String representation of int "+String.valueOf(i));
		System.out.println("String representation of double "+String.valueOf(d));
		System.out.println("String representation of float "+String.valueOf(f));
		System.out.println("String representation of char "+String.valueOf(c));
		System.out.println("String representation of Object "+String.valueOf(obj));
		System.out.println("String representation of boolean "+String.valueOf(b));
	}
	
	public void getCharArrayFromString(String input)
	{
		char[] tochar = input.toCharArray();
		for(char c : tochar)
		{
			System.out.println("char value: "+c);
		}
	}
	
	public void getTrimmedString(String input)
	{
		System.out.println("Trimmed String from: "+input+"--->" + input.trim());
	}
	
}

