package com.java.opps.isARelation;

public class Teacher extends Person
{

}
