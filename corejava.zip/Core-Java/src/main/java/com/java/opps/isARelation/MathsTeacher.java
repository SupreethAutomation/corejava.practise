package com.java.opps.isARelation;

public class MathsTeacher extends Teacher
{

}
