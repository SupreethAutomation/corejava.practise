package com.java.opps.isARelation;

public class Person {

}
