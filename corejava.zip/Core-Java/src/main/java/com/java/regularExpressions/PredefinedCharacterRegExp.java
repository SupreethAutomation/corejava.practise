package com.java.regularExpressions;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PredefinedCharacterRegExp 
{
	/*
	  	\s - search for space character
	  	\S - search any character except space character
	  	\d - search any digit [0-9]
	  	\D - search any character except any character
	  	\w  - any word character ([a-zA-Z0-9])
	  	\W - any character except word character (special character)
	  	. - (dot) any character either alphanumeric or special character. 	
	 */
	
	static Pattern objPattern = null;
	static Matcher objMatcher = null;

	public static void matchAndFindStartIndexOfTheMatch(String pattern,String input)
	{
		objPattern = Pattern.compile(pattern);
		objMatcher = objPattern.matcher(input);
		while(objMatcher.find())
		{
			System.out.println("position: "+objMatcher.start() + "group: "+objMatcher.group());
		}
	}
	
}
