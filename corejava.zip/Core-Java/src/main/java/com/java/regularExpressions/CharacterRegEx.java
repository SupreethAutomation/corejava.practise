package com.java.regularExpressions;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CharacterRegEx 
{
	/*
	[abc] - either a or b or c
	[^abc] - except a, b and c
	[a-z] - any lower case alphabet
	[A-Z] - any upper case alphabet
	[a-zA-Z] - any alphabet symbol
	[0-9] - any digit from 0 to 9
	[a-zA-Z0-9] and alphanumeric character
	[^a-zA-Z0-9] except alphanumeric characters (special characters)
	*/
	static Pattern objPattern = null;
	static Matcher objMatcher = null;

	public static void matchAndFindStartIndexOfTheMatch(String pattern,String input)
	{
		objPattern = Pattern.compile(pattern);
		objMatcher = objPattern.matcher(input);
		//search for the pattern ab with in ababbaba
		while(objMatcher.find())
		{
			System.out.println("position: "+objMatcher.start() + "group: "+objMatcher.group());
		}
	}
	
}
