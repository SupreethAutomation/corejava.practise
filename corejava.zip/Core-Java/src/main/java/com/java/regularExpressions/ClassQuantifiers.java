package com.java.regularExpressions;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ClassQuantifiers 
{
	/*
	 	Quantifiers : used to specify the no of occurrences to match
	 	input = abaabaaab
	 	pattern = a
	 	0-a,2-a,3-a,5-a,6-a,7-a
	 	pattern = a+ sequence of pattern considered as single match
	 	0-a,2-aa,5-aaa
	 	
	 	
	 */
	
	static Pattern objPattern = null;
	static Matcher objMatcher = null;

	public static void matchAndFindStartIndexOfTheMatch(String pattern,String input)
	{
		objPattern = Pattern.compile(pattern);
		objMatcher = objPattern.matcher(input);
		while(objMatcher.find())
		{
			System.out.println("position: "+objMatcher.start() + "group: "+objMatcher.group());
		}
	}
}
