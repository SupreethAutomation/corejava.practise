package com.java.regularExpressions;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExpDemo 
{
	static Pattern objPattern = null;
	static Matcher objMatcher = null;

	public static void matchAndFindStartIndexOfTheMatch(String pattern,String input)
	{
		objPattern = Pattern.compile(pattern);
		objMatcher = objPattern.matcher(input);
		int count = 0;
		//search for the pattern ab with in ababbaba
		while(objMatcher.find())
		{
			count++;
			System.out.println("Start index of the match:"+objMatcher.start());
		}

		System.out.println("No of times pattern occurred: "+count);
	}
	
	public static void matchAndFindEndIndexOfTheMatch(String pattern,String input)
	{
		objPattern = Pattern.compile(pattern);
		objMatcher = objPattern.matcher(input);
		int count = 0;
		while(objMatcher.find())
		{
			count++;
			System.out.println("end index of the match:"+objMatcher.end());
		}

		System.out.println("No of times pattern occurred: "+count);
	}
	
	public static void matchAndFindGroupIndexOfTheMatch(String pattern,String input)
	{
		objPattern = Pattern.compile(pattern);
		objMatcher = objPattern.matcher(input);
		int count = 0;
		//search for the pattern ab with in ababbaba
		while(objMatcher.find())
		{
			count++;
			System.out.println("group of the match:"+objMatcher.group());
		}

		System.out.println("No of times pattern occurred: "+count);
	}
	
	public static void validateIndianTelephoneNumber(String pattern,String telephoneNo)
	{
		/*
		 * condition 1 : each no must be exactly 10 digits
		 * condition 2 : each no must start with either 7 8 or 9
		 * 
		 * exp : [7-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9] long way
		 * [7-9][0-9]{9} shorter way
		 * 
		 * condition 3 : each no can be 11 digits if 11 then 1st digit must be 0
		 * 0?[7-9][0-9]{9}
		 * 
		 * 
		 * condition 4 : each no can be either 10 digit or 11 digit or 12 digit if 11 then 1st digit must be 0 if 12 digit then it must start with 91
		 * (0|91)?[7-9][0-9]{9}
		 * 
		 * */
		objPattern = Pattern.compile(pattern);
		objMatcher = objPattern.matcher(telephoneNo);
		System.out.println("The pattern valid?: "+objMatcher.matches());
	}
	
	public static void validateEmailID(String pattern,String emailID)
	{
		/*
		 * emailId - durga_ocjp.123@gmail.com
		 * pattern1 : durga_ocjp.123, 
		 * pattern2 :@ , 
		 * pattern3 :gmail, 
		 * pattern4 :. 
		 * pattern5 :com
		 * 
		 * possibility for pattern1 : a-z,A-Z,0-9,_,.
		 * possibility for pattern2 : @
		 * possibility for pattern3 : a-z,A-Z,0-9
		 * possibility for pattern4 : @
		 * possibility for pattern5 : a-z,A-Z
		 * 
		 * 
		 * example valid pattern1 : [a-zA-Z0-9][a-zA-Z0-9_.]*@[a-zA-Z0-9]+([.][a-z,A-Z])+  //.COM OR .CO.INS
		 * 
		 */
		objPattern = Pattern.compile(pattern);
		objMatcher = objPattern.matcher(emailID);
		System.out.println("The pattern valid?: "+objMatcher.matches());
	}
	
	public static void validateStudentName(String pattern,String studentName)
	{
		//Name starts with either s or S
		//Name ends with either h or H
		//Name starts with either s or S and ends with either h or H
		
		objPattern = Pattern.compile(pattern);
		objMatcher = objPattern.matcher(studentName);
		System.out.println("The pattern valid?: "+objMatcher.matches());
	}
	
	public static void extractMobileNumbersFromFile(File outputFile,File inputFile,String pattern) throws IOException
	{
		Pattern objPattern = Pattern.compile(pattern);
		PrintWriter objPrintWriter = new PrintWriter(outputFile);
		FileReader objFileReader = new FileReader(inputFile);
		BufferedReader objBufferedReader = new BufferedReader(objFileReader);
		Matcher objMatcher = null;
		String str = null;
		while((str = objBufferedReader.readLine())!= null)
		{
			objMatcher = objPattern.matcher(str);
			while(objMatcher.find())
			{
				objPrintWriter.write(objMatcher.group()+"\n");
			}
		}
		objPrintWriter.close();
		objFileReader.close();
		objBufferedReader.close();
		System.out.println("Scanning is complete... check the output file");
		
	}
	
	public static void extractemailIdsFromFile(File outputFile,File inputFile,String pattern) throws IOException
	{
		Pattern objPattern = Pattern.compile(pattern);
		PrintWriter objPrintWriter = new PrintWriter(outputFile);
		FileReader objFileReader = new FileReader(inputFile);
		BufferedReader objBufferedReader = new BufferedReader(objFileReader);
		Matcher objMatcher = null;
		String str = null;
		while((str = objBufferedReader.readLine())!= null)
		{
			objMatcher = objPattern.matcher(str);
			while(objMatcher.find())
			{
				objPrintWriter.write(objMatcher.group()+"\n");
			}
		}
		objPrintWriter.close();
		objFileReader.close();
		objBufferedReader.close();
		System.out.println("Scanning is complete... check the output file");
		
	}
	
	
	
	
}


