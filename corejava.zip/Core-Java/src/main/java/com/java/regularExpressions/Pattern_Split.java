package com.java.regularExpressions;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Pattern_Split 
{
	static Pattern objPattern = null;
	static Matcher objMatcher = null;
	static String[] strTokens = null;
	public static void split_RegExp(String pattern,String input)
	{
		objPattern = Pattern.compile(pattern);
		strTokens = objPattern.split(input);
		System.out.println("Split the input: "+input+ " according to the pattern "+ pattern);
		
		for (String str : strTokens)
		{
			System.out.println(str);
		}
	}
}
