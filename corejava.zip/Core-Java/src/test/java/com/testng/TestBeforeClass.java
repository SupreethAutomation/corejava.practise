package com.testng;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class TestBeforeClass 
{
	@BeforeClass
	public void beforeClass()
	{
		System.out.println("beforeClass");
	}
	
	
	@AfterClass
	public void afterClass()
	{
		System.out.println("afterClass");
	}
}
