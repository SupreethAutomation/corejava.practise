package com.testng;

import org.testng.annotations.Test;

public class TestTestNGTestMethod 
{
	@Test(priority=3)
	public void testM1()
	{
		System.out.println("This is test method M1");
	}
	
	@Test
	public void testM2()
	{
		System.out.println("This is test method M2");
	}
	
	@Test(priority=1)
	public void testM10()
	{
		System.out.println("This is test method M10");
	}
	
	/*
	 *  This is test method M2
		This is test method M10
		This is test method M1
	 * 
	 * 
	 */
	
}
