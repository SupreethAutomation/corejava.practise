package com.testng;

import org.testng.annotations.Test;

public class TestClass1 extends TestBeforeClass
{
	@Test
	public void TestClass1_test1()
	{
		System.out.println("TestClass1_test1");
	}
	
	@Test
	public void TestClass1_test2()
	{
		System.out.println("TestClass1_test2");
	}
}
