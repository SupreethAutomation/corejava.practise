package com.testng;

import org.testng.annotations.Test;

public class TestClass2 extends TestBeforeClass
{
	@Test
	public void TestClass2_test1()
	{
		System.out.println("TestClass2_test1");
	}
	
	@Test
	public void TestClass2_test2()
	{
		System.out.println("TestClass2_test2");
	}
}
