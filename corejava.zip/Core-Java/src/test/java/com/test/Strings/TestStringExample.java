package com.test.Strings;

import com.java.Strings.StringExample;
import com.java.Strings.StringTokenizerExample;
import com.java.oops.classes.Person;

public class TestStringExample 
{
	public static void main(String[] args) 
	{
		StringExample objStringExample = new StringExample();
		objStringExample.concatExample("Supreeth", "Muralidhar");
		objStringExample.displayCharAt("Supreeth");
		objStringExample.displayCharCodePointAt("aAbBcC");
		objStringExample.copyStringToCharArray("Supreeth", new char[8]);
		objStringExample.areStringEqual("Supreeth", "Supreeth");
		CharSequence objCS = "Supreeth"; 
		objStringExample.verifyStringwithCharacterArray("Supreeth", objCS);
		objStringExample.areStringEqualIgnoreCase("Supreeth", "SUPREETH");
		objStringExample.compareStringslexicographically("Supreeth","Supreeth");
		objStringExample.compareStringslexicographically("Supreetha","Supreeth");
		objStringExample.compareStringslexicographically("Supreeth","Supreetha");
		objStringExample.matchesRegion("Supreeth", "Supreeth", 1,1);
		objStringExample.matchesRegion("SupREETH", "SuPREETH", 1,3);
		objStringExample.stringCheckPrefix("Supreeth", "Sup",0);
		objStringExample.stringCheckPrefix("Supreeth", "th",6);
		objStringExample.stringCheckPrefix("Supreeth", "TH",6);
		objStringExample.stringCheckSuffix("Supreeth","eth");
		objStringExample.stringCheckSuffix("Supreeth","Sup");
		objStringExample.getFirstOccurenceOfCharacterInString("abcda", 'a'); //0
		objStringExample.getFirstOccurenceOfCharacterInString("abcda", 'c'); //2
		objStringExample.getFirstOccurenceOfCharacterInString("abcda", 'z'); //-1
		objStringExample.getFirstOccurenceOfCharacterInStringFrom("abcda", 'a',0); //0
		objStringExample.getFirstOccurenceOfCharacterInStringFrom("abcda", 'a',1); //4
		objStringExample.getFirstOccurenceOfCharacterInStringFrom("abcda", 'c',2); //2
		objStringExample.getFirstOccurenceOfCharacterInStringFrom("abcda", 'z',0); //-1
		objStringExample.getLastOccurenceOfCharacterInString("abcda", 'a'); //4
		objStringExample.getLastOccurenceOfCharacterInString("abccda", 'c'); //3
		objStringExample.getLastOccurenceOfCharacterInString("abcda", 'z'); //-1
		objStringExample.getLastOccurenceOfCharacterInStringFrom("abcde", 'b',2); // 1  from position 2(c) go backwards and check last presence of b i.e 1
		objStringExample.getLastOccurenceOfCharacterInStringFrom("abbde", 'b',2); //  2 from position 2(c) go backwards and check last presence of b i.e 2
		objStringExample.getLastOccurenceOfCharacterInStringFrom("cbacda", 'a',4);// 2 from position 4(d) go backwards and check last presence of a i.e 2
		objStringExample.getLastOccurenceOfCharacterInStringFrom("abcda", 'c',1); // -1 from position 1(b) go backwards and check last presence of c i.e -1
		objStringExample.getLastOccurenceOfCharacterInStringFrom("abcda", 'z',0);
		objStringExample.cutStringfrom("UnHappyIndia", 2); // cut from H to end of String
		objStringExample.cutStringbyRange("UnHappyIndia", 2,12); // cut from H till a
		objStringExample.replace("I am Sad", 'S', 'B');
		objStringExample.split("Erevmax Technologies Pvt Ltd"," ");
		StringTokenizerExample objStringTokenizerExample = new StringTokenizerExample();
		objStringTokenizerExample.tokenizationByDefault("I LOVE MY INDIA");
		objStringTokenizerExample = new StringTokenizerExample();
		objStringTokenizerExample.tokenizationByDelim("I-LOVE-MY-PARENTS","-");
		
		objStringExample.patternMatchesInput("(0|91)?[7-9][0-9]{9}", "8861122754");
		objStringExample.patternMatchesInput("(0|91)?[7-9][0-9]{9}", "08861122754");
		objStringExample.patternMatchesInput("(0|91)?[7-9][0-9]{9}", "918861122754");
		objStringExample.patternMatchesInput("(0|91)?[7-9][0-9]{9}", "1861122754");
		
		objStringExample.getSubString(0, 5, "Supreeth Muralidhar"); //from 0(inclusive) to 4(5-1)
		objStringExample.getSubString(1, 5, "Supreeth Muralidhar"); //from 1(inclusive) to 4(5-1)
		objStringExample.getSubString(9, 19, "Supreeth Muralidhar"); //from 9(inclusive) to 18(19-1)
		
		objStringExample.displayValueOf(10, 5.555555, 2.3f,'S', new Person(),true);
		
		objStringExample.getCharArrayFromString("Supreeth");
		objStringExample.getTrimmedString("Supreeth            ");
		objStringExample.getTrimmedString("            Supreeth            ");
		objStringExample.getTrimmedString("            Supreeth");
	}
}
