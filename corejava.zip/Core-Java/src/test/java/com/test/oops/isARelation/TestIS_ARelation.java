package com.test.oops.isARelation;

import com.java.opps.isARelation.MathsTeacher;
import com.java.opps.isARelation.Person;
import com.java.opps.isARelation.Teacher;

public class TestIS_ARelation 
{
	public static void main(String[] args) 
	{
		Person objPerson = new Person();
		Teacher objTeacher = new Teacher();
		MathsTeacher objMathsTeacher = new MathsTeacher();
		
		System.out.println("objMathsTeacher instanceof Teacher----" +( objMathsTeacher instanceof Teacher));
		System.out.println("objMathsTeacher instanceof Person-----" + (objMathsTeacher instanceof Person));
		System.out.println("objTeacher instanceof Person-----" + (objTeacher instanceof Person));
		
	}
}
