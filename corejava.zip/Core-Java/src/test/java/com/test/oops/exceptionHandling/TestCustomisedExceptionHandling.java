package com.test.oops.exceptionHandling;

import com.java.oops.exceptionHandling.CustomizedExceptionHandling;

public class TestCustomisedExceptionHandling 	
{
	public static void main(String[] args) 
	{
		CustomizedExceptionHandling objCustomizedExceptionHandling = new CustomizedExceptionHandling();
		objCustomizedExceptionHandling.divideByZero(10);
	}
}
