package com.test.oops.exceptionHandling;

import com.java.oops.exceptionHandling.NestedTryBlock;

public class TestNestedTry 
{
	public static void main(String[] args) 
	{
		NestedTryBlock.checkNestedTryBlock();
	}
}
