package com.test.oops.CompileTimePolymorphism.overloading;

import com.java.oops.CompileTimePolymorphism.OverLoading.Calculator_MethodOverLoading;

public class TestCalculator_MethodOverLoading 
{
	public static void main(String[] args) 
	{
		Calculator_MethodOverLoading objCalculator = new Calculator_MethodOverLoading();
		
		objCalculator.add(10);
		
		objCalculator.add(10,20);
		
		objCalculator.add(10, 12.32);
		
		objCalculator.add(1, "BI08scs21");
		
		objCalculator.add("Supreeth", "VM");
		
		objCalculator.add('M');
	}
	
}
