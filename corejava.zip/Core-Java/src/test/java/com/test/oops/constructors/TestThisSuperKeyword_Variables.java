package com.test.oops.constructors;

import com.java.oops.constructors.ThisSuperKeywordVariableExample;

public class TestThisSuperKeyword_Variables 
{
	public static void main(String[] args) 
	{
		ThisSuperKeywordVariableExample objExample = new ThisSuperKeywordVariableExample(11, 12);
	}
}


