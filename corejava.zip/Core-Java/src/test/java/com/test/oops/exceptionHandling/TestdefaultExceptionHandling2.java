package com.test.oops.exceptionHandling;

import com.java.oops.exceptionHandling.ExceptionIn2Methods;

public class TestdefaultExceptionHandling2 
{
	public static void main(String[] args) 
	{
		new ExceptionIn2Methods().doStuff();
	}
}

/*
Hello
Exception in thread "main" java.lang.ArithmeticException: / by zero
	at com.java.oops.exceptionHandling.ExceptionIn2Methods.doStuff(ExceptionIn2Methods.java:8)
	at com.test.oops.exceptionHandling.TestdefaultExceptionHandling2.main(TestdefaultExceptionHandling2.java:9)
*/