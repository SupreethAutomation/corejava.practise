package com.test.oops.exceptionHandling.ImpExceptions;

import com.java.oops.exceptionHandling.ImpExceptions.CheckArrayIndexOutOfBoundsException;

public class TestArrayIndexOutOfBoundsException 
{
	public static void main(String[] args) 
	{
		int arr[] = {1,2,3};
		CheckArrayIndexOutOfBoundsException.checkArrayElements(arr);
	}
	/*
	Exception in thread "main" java.lang.ArrayIndexOutOfBoundsException: 3
	at com.java.oops.exceptionHandling.ImpExceptions.CheckArrayIndexOutOfBoundsException.checkArrayElements(CheckArrayIndexOutOfBoundsException.java:9)
	at com.test.oops.exceptionHandling.ImpExceptions.TestArrayIndexOutOfBoundsException.main(TestArrayIndexOutOfBoundsException.java:10)
	*/
}
