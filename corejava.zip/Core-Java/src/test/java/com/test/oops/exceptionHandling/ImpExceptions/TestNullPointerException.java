package com.test.oops.exceptionHandling.ImpExceptions;

import com.java.oops.encapsulation.Student;
import com.java.oops.exceptionHandling.ImpExceptions.CheckNullPointerException;

public class TestNullPointerException 
{
	public static void main(String[] args) 
	{/*
		Student objStudent = null;
		CheckNullPointerException.checkNullPointerException(objStudent);
		Exception in thread "main" java.lang.NullPointerException
		at com.java.oops.exceptionHandling.ImpExceptions.CheckNullPointerException.checkNullPointerException(CheckNullPointerException.java:9)
		at com.test.oops.exceptionHandling.ImpExceptions.TestNullPointerException.main(TestNullPointerException.java:11)
		*/
		
		String s = null;
		System.out.println(s.length());
		
		/*Exception in thread "main" java.lang.NullPointerException
	at com.test.oops.exceptionHandling.ImpExceptions.TestNullPointerException.main(TestNullPointerException.java:18)
		 * */
	}
	
}
