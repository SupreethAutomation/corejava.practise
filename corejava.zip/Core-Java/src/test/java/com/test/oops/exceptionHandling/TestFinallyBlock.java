package com.test.oops.exceptionHandling;

import com.java.oops.exceptionHandling.FinallyBlock;

public class TestFinallyBlock 
{
	public static void main(String[] args) 
	{
		FinallyBlock.TestFinallyBlock();
		FinallyBlock.TestwithoutFinallyBlock();
	}
}
