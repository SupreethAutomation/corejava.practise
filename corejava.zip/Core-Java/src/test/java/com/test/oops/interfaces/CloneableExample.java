package com.test.oops.interfaces;

public class CloneableExample implements Cloneable
{
	public int a;
	public int b;
	public static void main(String[] args) 
	{
		CloneableExample objInterfaceUsage = new CloneableExample();
		System.out.println("Default values:");
		System.out.println("objInterfaceUsage.a:"+objInterfaceUsage.a);
		System.out.println("objInterfaceUsage.b:"+objInterfaceUsage.b);
		objInterfaceUsage.a = 10;
		objInterfaceUsage.b = 20;
		System.out.println("values after assignment1:");
		System.out.println("objInterfaceUsage.a:"+objInterfaceUsage.a);
		System.out.println("objInterfaceUsage.b:"+objInterfaceUsage.b);
		CloneableExample objInterfaceUsage2 = null;
		try {
			 objInterfaceUsage2 = (CloneableExample)objInterfaceUsage.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		objInterfaceUsage.a = 100;
		objInterfaceUsage.b = 200;
		System.out.println("values after assignment2:");
		System.out.println("objInterfaceUsage.a:"+objInterfaceUsage.a);
		System.out.println("objInterfaceUsage.b:"+objInterfaceUsage.b);
		
		System.out.println("values cloned:");
		System.out.println("objInterfaceUsage2.a:"+objInterfaceUsage2.a);
		System.out.println("objInterfaceUsage2.b:"+objInterfaceUsage2.b);
		
	}
}
