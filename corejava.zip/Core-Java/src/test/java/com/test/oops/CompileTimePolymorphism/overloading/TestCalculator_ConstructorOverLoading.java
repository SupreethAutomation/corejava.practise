package com.test.oops.CompileTimePolymorphism.overloading;

import com.java.oops.CompileTimePolymorphism.OverLoading.Calculator_ConstructorOverLoading;

public class TestCalculator_ConstructorOverLoading 
{
	public static void main(String[] args) 
	{
		Calculator_ConstructorOverLoading objCalculator = new Calculator_ConstructorOverLoading();
		objCalculator = new Calculator_ConstructorOverLoading('M');
		objCalculator = new Calculator_ConstructorOverLoading(10);
		objCalculator = new Calculator_ConstructorOverLoading(11,12.32);
		objCalculator = new Calculator_ConstructorOverLoading(10,20);
		objCalculator = new Calculator_ConstructorOverLoading("Supreeth",'M');
	}
}
