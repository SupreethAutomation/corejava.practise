package com.test.oops.arrays;

import com.java.oops.array.ThreeDArray;

public class TestThreeDArray 
{
	public static void main(String[] args) 
	{
		ThreeDArray objThreeDArray = new ThreeDArray();
		objThreeDArray.setDept();
		objThreeDArray.getDept();
	}
	
}
