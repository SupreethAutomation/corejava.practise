package com.test.oops.hasARelation;

import com.java.oops.hasARelation.Company;
import com.java.oops.hasARelation.Department;
import com.java.oops.hasARelation.Employee;

public class TestHasARelation 
{
	public static void main(String[] args) 
	{
		Employee objEmployee1 = new Employee();
		objEmployee1.setEmpID("111");
		objEmployee1.setEmpName("ABC");
		objEmployee1.setSalary(20000);
		
		Department objDepartment = new Department();
		objDepartment.setDeptHead(objEmployee1);
		objDepartment.setDeptID("D1");
		objDepartment.setDeptLocation("Bangalore");
		objDepartment.setDeptName("Development");
		
		objEmployee1.setObjDept(objDepartment);
				
		Employee objEmployee2 = new Employee();
		objEmployee2.setEmpID("222");
		objEmployee2.setEmpName("PQR");
		objEmployee2.setSalary(30000);
		objEmployee2.setObjDept(objDepartment);
		
		Employee objEmployee3 = new Employee();
		objEmployee3.setEmpID("333");
		objEmployee3.setEmpName("XYZ");
		objEmployee3.setSalary(40000);
		objEmployee3.setObjDept(objDepartment);
		
		Company objCompany = new Company();
		
		Employee[] objEmployees = {objEmployee1,objEmployee2,objEmployee3};
		objCompany.setObjEmployees(objEmployees);
		
		Department[] objDepartments = {objDepartment};
		objCompany.setObjDepartment(objDepartments);
		
		
		objCompany.displayCompanyDetails();
	}
}
