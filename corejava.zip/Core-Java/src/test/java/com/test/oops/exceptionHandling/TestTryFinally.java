package com.test.oops.exceptionHandling;

import com.java.oops.exceptionHandling.TryFinally;

public class TestTryFinally 
{
	public static void main(String[] args) 
	{
	TryFinally.checkTryFinally();	
	}
}
