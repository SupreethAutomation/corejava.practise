package com.test.oops.exceptionHandling;

import com.java.oops.exceptionHandling.ThrowNullPointerException;

public class TestThrowNullpointerException 
{
	public static void main(String[] args) 
	{
		ThrowNullPointerException.throwNullPointerException();
	}
}
