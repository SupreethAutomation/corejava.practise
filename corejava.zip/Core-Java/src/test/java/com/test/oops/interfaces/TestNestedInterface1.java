package com.test.oops.interfaces;

import com.java.oops.nestedInterfaces.ClassImplementsNestedInterfaces;

public class TestNestedInterface1 
{
	public static void main(String[] args) 
	{
		ClassImplementsNestedInterfaces objNestedInterfaces = new ClassImplementsNestedInterfaces();
		objNestedInterfaces.startTempo();
		objNestedInterfaces.stopTempo();
	}
}
