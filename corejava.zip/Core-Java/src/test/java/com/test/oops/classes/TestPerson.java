package com.test.oops.classes;

import com.java.oops.classes.Person;

public class TestPerson 
{
	public static void main(String[] args) 
	{
		Person objPerson1 = new Person();
		objPerson1.name="Supreeth";
		objPerson1.age=32;
		objPerson1.gender='M';
		objPerson1.address="Mysore";
		
		objPerson1.eat();
		objPerson1.sleep();
		objPerson1.work();
		objPerson1.displayPersonDetails();
		
		
		Person objPerson2 = new Person();
		objPerson2.name="Saraswathi";
		objPerson2.age=60;
		objPerson2.gender='F';
		objPerson2.address="Mysore";
		
		objPerson2.eat();
		objPerson2.sleep();
		objPerson2.work();
		objPerson2.displayPersonDetails();
	}
}
