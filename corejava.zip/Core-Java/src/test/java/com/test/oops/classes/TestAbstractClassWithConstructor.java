package com.test.oops.classes;

import com.java.oops.classes.DerivedClassWithConstructor;

public class TestAbstractClassWithConstructor 
{
	public static void main(String[] args) 
	{
		DerivedClassWithConstructor objDerivedClassWithConstructor = new DerivedClassWithConstructor(); 
	}
}
