package com.test.oops.exceptionHandling;

import com.java.oops.exceptionHandling.ThrowExceptionToJVM;

public class TestThrowExceptionToJVMManually 
{
	public static void main(String[] args) 
	{
		ThrowExceptionToJVM.throwExceptionManually();
	}
}
