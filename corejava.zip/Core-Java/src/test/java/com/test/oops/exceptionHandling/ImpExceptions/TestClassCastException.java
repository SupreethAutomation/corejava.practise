package com.test.oops.exceptionHandling.ImpExceptions;

import com.java.oops.exceptionHandling.ImpExceptions.CheckClassCastException;

public class TestClassCastException 
{
	public static void main(String[] args) 
	{
		CheckClassCastException.riseClassCastException();
		/*
		 Exception in thread "main" java.lang.ClassCastException: com.java.oops.CompileTimePolymorphism.Overriding.Father cannot be cast to com.java.oops.CompileTimePolymorphism.Overriding.Son
	at com.java.oops.exceptionHandling.ImpExceptions.CheckClassCastException.riseClassCastException(CheckClassCastException.java:11)
	at com.test.oops.exceptionHandling.ImpExceptions.TestClassCastException.main(TestClassCastException.java:9)
		 * */
	}
}
