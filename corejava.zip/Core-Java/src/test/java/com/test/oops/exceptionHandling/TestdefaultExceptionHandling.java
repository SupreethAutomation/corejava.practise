package com.test.oops.exceptionHandling;

import com.java.oops.exceptionHandling.DefaultExceptionHandler;

public class TestdefaultExceptionHandling 
{
	public static void main(String[] args) 
	{
		new DefaultExceptionHandler().doStuff();
	}
}

/*
Exception in thread "main" java.lang.ArithmeticException: / by zero
	at com.java.oops.exceptionHandling.DefaultExceptionHandler.domoreStuff(DefaultExceptionHandler.java:13)
	at com.java.oops.exceptionHandling.DefaultExceptionHandler.doStuff(DefaultExceptionHandler.java:7)
	at com.test.oops.exceptionHandling.TestdefaultExceptionHandling.main(TestdefaultExceptionHandling.java:9)
*/