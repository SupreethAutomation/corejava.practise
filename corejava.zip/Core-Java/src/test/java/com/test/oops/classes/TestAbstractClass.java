package com.test.oops.classes;

import com.java.oops.classes.NonAbstractClass;

public class TestAbstractClass 
{
	public static void main(String[] args) 
	{
		//AbstractClass objAbstractClass = new AbstractClass(); Cannot instantiate the type AbstractClass
		
		
		NonAbstractClass objNonAbstractClass = new NonAbstractClass();
		objNonAbstractClass.m1();
		objNonAbstractClass.m2();
		objNonAbstractClass.m3();
		objNonAbstractClass.concreteMethod();
	}
}
