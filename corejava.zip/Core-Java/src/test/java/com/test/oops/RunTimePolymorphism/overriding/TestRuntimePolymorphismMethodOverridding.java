package com.test.oops.RunTimePolymorphism.overriding;

import com.java.oops.RunTimePolymorphism.Overriding.Child;
import com.java.oops.RunTimePolymorphism.Overriding.Parent;

public class TestRuntimePolymorphismMethodOverridding
{
	public static void main(String[] args) 
	{
		Parent objParent = new Child();
		objParent.m1(); 
		// compile time compiler will check whether m1 is present in class Parent
		// run time jvm will execute the m1 method based on the object created i.e Child 
		//objParent.m2(); // compile time compiler will check whether m2 is present in class Parent
		((Child) objParent).m2();
	}
}
