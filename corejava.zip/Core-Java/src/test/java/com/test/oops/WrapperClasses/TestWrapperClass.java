package com.test.oops.WrapperClasses;

import com.java.oops.wrapperClasses.WrapperClass;

public class TestWrapperClass 
{
	public static void main(String[] args) 
	{
		WrapperClass objWrapperClass = new WrapperClass((byte)127, (short)32767, 2147483647, 9223372036854775807l, 2147483647f, 9223372036854775807d, 'S',true);
		objWrapperClass.displayValues();
	}
}
