package com.test.oops.exceptionHandling;

import com.java.oops.exceptionHandling.UnCheckedException;

public class TestUnCheckedExceptions 
{
	public static void main(String[] args) 
	{
		UnCheckedException objUnCheckedException = new UnCheckedException();
	//  objUnCheckedException.checkArithmeticException(10);
		/*
		Exception in thread "main" java.lang.ArithmeticException: / by zero
		at com.java.oops.exceptionHandling.UnCheckedException.checkArithmeticException(UnCheckedException.java:9)
		at com.test.oops.exceptionHandling.TestUnCheckedExceptions.main(TestUnCheckedExceptions.java:10)
		*/
	//	objUnCheckedException.checkIndexOutOfBoundsException(new int[5]);
		/*
		Exception in thread "main" java.lang.ArrayIndexOutOfBoundsException: 10
		at com.java.oops.exceptionHandling.UnCheckedException.checkIndexOutOfBoundsException(UnCheckedException.java:19)
		at com.test.oops.exceptionHandling.TestUnCheckedExceptions.main(TestUnCheckedExceptions.java:16)
		*/
	//objUnCheckedException.checkNullPointerException().displayPersonDetails();
		/*
 		Exception in thread "main" java.lang.NullPointerException
		at com.test.oops.exceptionHandling.TestUnCheckedExceptions.main(TestUnCheckedExceptions.java:24)
		*/
	}
}
