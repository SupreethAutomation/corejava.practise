package com.test.oops.constructors;

import com.java.oops.constructors.ThisSuperKeywordMethodExample;

public class TestThisSuperKeyword_Methods 
{
	public static void main(String[] args) 
	{
		ThisSuperKeywordMethodExample objExample = new ThisSuperKeywordMethodExample();
	}
}


