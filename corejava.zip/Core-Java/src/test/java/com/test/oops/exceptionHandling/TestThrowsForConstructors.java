package com.test.oops.exceptionHandling;

import com.java.oops.exceptionHandling.ThrowsForConstructors;

public class TestThrowsForConstructors 
{
	public static void main(String[] args) 
	{
		ThrowsForConstructors objThrowsForConstructors = null;
		try
		{
			objThrowsForConstructors = new ThrowsForConstructors();
		}
		catch (Exception e) {
			try
			{
			objThrowsForConstructors.a = 10/2;
			}
			catch (NullPointerException e2) 
			{
				System.out.println("value of a is null");
			}
		}
		
	}
}
