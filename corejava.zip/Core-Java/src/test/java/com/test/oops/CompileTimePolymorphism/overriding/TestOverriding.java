package com.test.oops.CompileTimePolymorphism.overriding;

import com.java.oops.CompileTimePolymorphism.Overriding.Father;
import com.java.oops.CompileTimePolymorphism.Overriding.Son;

public class TestOverriding 
{
	public static void main(String[] args) 
	{
		Son objSon = new Son("Muralidhar", "Supreeth");
		
		objSon.eat();
		
		Father objFather = new Father("Muralidhar");
		
		objFather.eat();
	}
}
