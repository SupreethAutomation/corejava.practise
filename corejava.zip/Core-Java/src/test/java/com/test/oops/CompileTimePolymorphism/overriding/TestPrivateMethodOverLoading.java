package com.test.oops.CompileTimePolymorphism.overriding;

import com.java.oops.CompileTimePolymorphism.Overriding.Daughter;
import com.java.oops.CompileTimePolymorphism.Overriding.Mother;

public class TestPrivateMethodOverLoading 
{
	public static void main(String[] args) 
	{
		Mother objMother = new Daughter();
		// objMother.cook(); The method cook() from the type Mother is not visible becos it is private
		//objMother.receipe; The field Mother.receipe is not visible
	}
}
