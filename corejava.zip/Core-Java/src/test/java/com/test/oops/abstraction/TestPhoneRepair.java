package com.test.oops.abstraction;

import com.java.oops.abstraction.MotoRola;
import com.java.oops.abstraction.Phone;
import com.java.oops.abstraction.PhoneRepair;
import com.java.oops.abstraction.Samsung;

public class TestPhoneRepair
{
	public static void main(String[] args) 
	{
		Phone objSamsungS7 = new Samsung();
		objSamsungS7.setModelNo("s7007");
		objSamsungS7.setModelName("samsung galaxy s7");
		
		Phone objMotoRolaG2 = new MotoRola();
		objMotoRolaG2.setModelNo("moto007");
		objMotoRolaG2.setModelName("MotoRola Gen-2");
		
		PhoneRepair objPhoneRepair = new PhoneRepair();
		objPhoneRepair.repairPhone(objMotoRolaG2);
		
	}
}
