package com.test.oops.staticExample;

import com.java.oops.staticExample.Child_StaticMethod;
import com.java.oops.staticExample.Parent_StaticMethod;

public class StaticMethodOverRiding_MethodHiding 
{
	public static void main(String[] args) 
	{
		Parent_StaticMethod objParent_StaticMethod = new Child_StaticMethod();
		objParent_StaticMethod.m1();
		//static methods are always specific to the Class not to the Object
		
		//In java overriding static methods is not possible becos they are bound with class.
		
		
		
	}
}
