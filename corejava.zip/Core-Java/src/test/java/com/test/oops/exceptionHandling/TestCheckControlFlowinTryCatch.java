package com.test.oops.exceptionHandling;

import com.java.oops.exceptionHandling.ControlFlowInTryCatch;

public class TestCheckControlFlowinTryCatch 
{
	public static void main(String[] args) 
	{
		//case - 1: NormalTermination
		System.out.println("Case-1: Normal Termication");
		ControlFlowInTryCatch.checkControlFlowInTryCatchNormalTermination();
		System.out.println("Case-2: Normal Termication");
		ControlFlowInTryCatch.checkControlFlowInTryCatchExceptionatStmt1NormalTermination();
		System.out.println("Case-3: Normal Termication");
		ControlFlowInTryCatch.checkControlFlowInTryCatchExceptionatStmt2NormalTermination();
		System.out.println("Case-4: Normal Termication");
		ControlFlowInTryCatch.checkControlFlowInTryCatchExceptionatStmt3NormalTermination();
		
		
	}
}
