package com.test.oops.interfaces;

import com.java.oops.interfaces.ClassC;

public class ClassextendsClassImplementsInterface 
{
	public static void main(String[] args) 
	{
		ClassC objC = new ClassC();
		objC.m1();
		objC.m2();
		objC.methodA();
		objC.methodB();
	}
}
