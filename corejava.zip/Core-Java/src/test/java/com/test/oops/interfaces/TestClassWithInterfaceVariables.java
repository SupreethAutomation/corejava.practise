package com.test.oops.interfaces;

import com.java.oops.interfaces.ClassInterfaceVaraibleAccess;

public class TestClassWithInterfaceVariables
{
	public static void main(String[] args) 
	{
		ClassInterfaceVaraibleAccess objAccess  =new ClassInterfaceVaraibleAccess();
		objAccess.method1();
	}
}
