package com.test.oops.exceptionHandling.ImpExceptions;

import com.java.oops.exceptionHandling.ImpExceptions.CheckStackOverFlowError;

public class TestStackOverFlowError 
{
	public static void main(String[] args) 
	{
		CheckStackOverFlowError.m1();
	}
}
