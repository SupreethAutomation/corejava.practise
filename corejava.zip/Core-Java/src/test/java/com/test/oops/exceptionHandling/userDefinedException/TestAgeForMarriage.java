package com.test.oops.exceptionHandling.userDefinedException;

import java.util.Scanner;

import com.java.oops.exceptionHandling.userDefinedException.TooOldException;
import com.java.oops.exceptionHandling.userDefinedException.TooYoungException;

public class TestAgeForMarriage 
{
	public static void main(String[] args) 
	{
		int age = 0;
		System.out.println("Please enter your age");
		Scanner objScanner = new Scanner(System.in);
		age = objScanner.nextInt();
		if(age > 60)
		{
			throw new TooYoungException("U are too young for marriage, please wait");
		}
		else if(age < 18)
		{
			throw new TooOldException("U are too old for marriage, please take care of urself");
		}
		else
		{
			System.out.println("U are eligible for the marriage, details will be shared soon");
		}
		if(objScanner!=null)
		objScanner.close();
	}
}
