package com.test.oops.interfaces;

import com.java.oops.nestedInterfaces.InterfaceWithInClass;

public class TestInterfaceWithInClass 
{
	public static void main(String[] args) 
	{
		InterfaceWithInClass objInterfaceWithInClass = new InterfaceWithInClass();
		objInterfaceWithInClass.sleep();
	}
}
