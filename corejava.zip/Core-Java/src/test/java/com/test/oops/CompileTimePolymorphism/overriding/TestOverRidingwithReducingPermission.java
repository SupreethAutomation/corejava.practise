package com.test.oops.CompileTimePolymorphism.overriding;

public class TestOverRidingwithReducingPermission 
{
	
}
