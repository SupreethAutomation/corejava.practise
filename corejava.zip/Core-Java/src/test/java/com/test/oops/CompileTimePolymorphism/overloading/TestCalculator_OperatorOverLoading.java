package com.test.oops.CompileTimePolymorphism.overloading;

import com.java.oops.CompileTimePolymorphism.OverLoading.Calculator_OperatorOverLoading;

public class TestCalculator_OperatorOverLoading 
{
	public static void main(String[] args) 
	{
		Calculator_OperatorOverLoading objCalculator = new Calculator_OperatorOverLoading(1, 2);
		objCalculator = new Calculator_OperatorOverLoading("Saraswathi", "Muralidhar");
		objCalculator = new Calculator_OperatorOverLoading("Supreeth", 1985);
	}
	
}
