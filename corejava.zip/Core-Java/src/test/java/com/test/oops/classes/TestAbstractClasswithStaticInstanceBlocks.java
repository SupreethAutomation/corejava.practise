package com.test.oops.classes;

import com.java.oops.classes.NormalClass;

public class TestAbstractClasswithStaticInstanceBlocks 
{
	public static void main(String[] args) 
	{
		NormalClass objNormalClass = new NormalClass();
	}
}
