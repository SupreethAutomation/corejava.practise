package com.test.oops.constructors;

import com.java.oops.constructors.CheckConstructorChaining;

public class TestConstructorChaining 
{
	public static void main(String[] args) 
	{
		CheckConstructorChaining objCheckConstructorChaining = new CheckConstructorChaining();
	}
}
