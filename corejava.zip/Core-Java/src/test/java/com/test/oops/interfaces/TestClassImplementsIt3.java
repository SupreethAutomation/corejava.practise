package com.test.oops.interfaces;

import com.java.oops.interfaces.ClassImplementsIt3;

public class TestClassImplementsIt3 
{
	public static void main(String[] args) 
	{
		ClassImplementsIt3 objClassImplementsIt3 = new ClassImplementsIt3();
		objClassImplementsIt3.m1();
		objClassImplementsIt3.m2();
		objClassImplementsIt3.m3();
	}
}
