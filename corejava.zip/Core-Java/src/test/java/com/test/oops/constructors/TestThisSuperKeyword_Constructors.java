package com.test.oops.constructors;

import com.java.oops.constructors.ThisSuperKeywordConstructorExample;

public class TestThisSuperKeyword_Constructors 
{
	public static void main(String[] args) 
	{
		ThisSuperKeywordConstructorExample objConstructorExample = new ThisSuperKeywordConstructorExample(10,20);
	}
}
