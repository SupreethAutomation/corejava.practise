package com.test.oops.exceptionHandling.ImpExceptions;

import com.java.oops.exceptionHandling.ImpExceptions.CheckExceptionInInitializerError;

public class TestExceptionInInitialzerError 
{
	public static void main(String[] args) 
	{
		CheckExceptionInInitializerError.riseExceptionInInitializerError();
		
		/*
		 * Exception in thread "main" java.lang.ExceptionInInitializerError
	at com.test.oops.exceptionHandling.ImpExceptions.TestExceptionInInitialzerError.main(TestExceptionInInitialzerError.java:9)
Caused by: java.lang.ArithmeticException: / by zero
	at com.java.oops.exceptionHandling.ImpExceptions.CheckExceptionInInitializerError.<clinit>(CheckExceptionInInitializerError.java:7)
		 */
	}
}
