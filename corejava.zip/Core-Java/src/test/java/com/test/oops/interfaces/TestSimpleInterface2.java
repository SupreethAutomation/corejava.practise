package com.test.oops.interfaces;

import com.java.oops.interfaces.ActivaGear;
import com.java.oops.interfaces.Vehicle;

public class TestSimpleInterface2 
{
	public static void main(String[] args) 
	{
		Vehicle objVehicle = new ActivaGear();
		objVehicle.ignitionON();
		objVehicle.changeGear();
		objVehicle.accelerate();
		objVehicle.deAccelerate();
		objVehicle.changeGear();
		objVehicle.applyBrakes();
		objVehicle.ignitionOFF();
	}
}
