package com.test.oops.exceptionHandling;

import com.java.oops.exceptionHandling.ExceptionInMain;

public class TestExceptionInMain 
{
	public static void main(String[] args) 
	{
		new ExceptionInMain().doStuff();
		int a = 10 / 0;
		System.out.println("This is not printed by main because of exception");
	}
}

/*
	Hello from DomoreStuff
	Hi from domorestuff
	Exception in thread "main" java.lang.ArithmeticException: / by zero
	at com.test.oops.exceptionHandling.TestExceptionInMain.main(TestExceptionInMain.java:10)
*/