package com.test.oops.exceptionHandling;

import com.java.oops.exceptionHandling.ThrowsKeyword;

public class TestThrowsKeyword 
{
	public static void main(String[] args) 
	{
		try {
			ThrowsKeyword.explicitWait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
