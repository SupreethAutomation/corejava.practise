package com.test.oops.arrays;

import com.java.oops.array.OneDArray;

public class TestOneDArray 
{
	public static void main(String[] args) 
	{
		OneDArray objOneDArray = new OneDArray();
		objOneDArray.setMarks();
		objOneDArray.getMarks();
	}
	
}
