package com.test.oops.arrays;

import com.java.oops.array.TwoDArray;

public class TestTwoDArray 
{
	public static void main(String[] args) 
	{
		TwoDArray objTwoDArray = new TwoDArray();
		objTwoDArray.setDept();
		objTwoDArray.getDept();
	}
	
}
