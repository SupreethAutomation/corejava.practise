package com.test.oops.CompileTimePolymorphism.overriding;

import com.java.oops.CompileTimePolymorphism.Overriding.Dog;

public class TestCovariantMethodOverriding 
{
	public static void main(String[] args) {
		Dog objDog  = new Dog();
		objDog.eat();
	}
}
