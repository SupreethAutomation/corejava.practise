package com.test.oops.interfaces;

import com.java.oops.interfaces.Pulsar;

public class TestSimpleInterface 
{
	public static void main(String[] args) 
	{
		Pulsar objPulsar = new Pulsar();
		objPulsar.ignitionON();
		objPulsar.changeGear();
		objPulsar.accelerate();
		objPulsar.deAccelerate();
		objPulsar.changeGear();
		objPulsar.applyBrakes();
		objPulsar.ignitionOFF();
	}
}
