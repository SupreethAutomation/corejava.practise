package com.test.oops.encapsulation;

import com.java.oops.encapsulation.Student;

public class TestStudent 
{
	public static void main(String[] args) 
	{
		Student objStudent = new Student();
		
		objStudent.setStudentID("1BI08SCS21");
		objStudent.setStudentName("Supreeth VM");
		
		System.out.println("Student ID is: "+objStudent.getStudentID());
		System.out.println("Student Name is: "+objStudent.getStudentName());
	}
}
