package com.test.oops.inheritance;

import com.java.oops.inheritance.Animal;
import com.java.oops.inheritance.Dog;

public class TestAnimal 
{
	public static void main(String[] args) 
	{
		Animal objAnimal = new Dog();
		objAnimal.setAnimalName("puttu");
		objAnimal.eat();
		objAnimal.sleep();
		((Dog)objAnimal).bark();
		
	}
}
