package com.test.RegularExpressions;

import com.java.regularExpressions.CharacterRegEx;

public class TestCharacterRegExp 
{
	public static void main(String[] args) 
	{
		CharacterRegEx.matchAndFindStartIndexOfTheMatch("[abc]", "a7b@z#9X");
		System.out.println("*********************************************");
		CharacterRegEx.matchAndFindStartIndexOfTheMatch("[^abc]", "a7b@z#9X");
		System.out.println("*********************************************");
		CharacterRegEx.matchAndFindStartIndexOfTheMatch("[a-z]", "a7b@z#9X");
		System.out.println("*********************************************");
		CharacterRegEx.matchAndFindStartIndexOfTheMatch("[A-Z]", "a7b@z#9X");
		System.out.println("*********************************************");
		CharacterRegEx.matchAndFindStartIndexOfTheMatch("[a-zA-Z]", "a7b@z#9X");
		System.out.println("*********************************************");
		CharacterRegEx.matchAndFindStartIndexOfTheMatch("[^a-zA-Z]", "a7b@z#9X");
		System.out.println("*********************************************");
		CharacterRegEx.matchAndFindStartIndexOfTheMatch("[0-9]", "a7b@z#9X");
		System.out.println("*********************************************");
		CharacterRegEx.matchAndFindStartIndexOfTheMatch("[^0-9]", "a7b@z#9X");
		System.out.println("*********************************************");
		CharacterRegEx.matchAndFindStartIndexOfTheMatch("[a-zA-Z0-9]", "a7b@z#9X");
		System.out.println("*********************************************");
		CharacterRegEx.matchAndFindStartIndexOfTheMatch("[^a-zA-Z0-9]", "a7b@z#9X");
	}
}
