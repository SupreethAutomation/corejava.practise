package com.test.RegularExpressions;

import com.java.regularExpressions.ClassQuantifiers;

public class TestQuantifiers 
{
	public static void main(String[] args) 
	{
		System.out.println("Check where ever 'a' is there print it (single a)" );
		ClassQuantifiers.matchAndFindStartIndexOfTheMatch("a", "abaabaaab");
		System.out.println("*********************************************");
		
		System.out.println("Check where ever atleast single 'a' are there print it (atleast 1 a)");
		ClassQuantifiers.matchAndFindStartIndexOfTheMatch("a+", "abaabaaab");
		System.out.println("*********************************************");
		
		System.out.println("Check where ever any no sequence of a are there print it (0 or any 1 a)");
		ClassQuantifiers.matchAndFindStartIndexOfTheMatch("a*", "abaabaaab"); // a* = a+ U {E}
		System.out.println("*********************************************");
		
		System.out.println("Check where ever atmost single a are there print it (0 or atmost 1 a)");
		ClassQuantifiers.matchAndFindStartIndexOfTheMatch("a?", "abaabaaab"); 
		System.out.println("*********************************************");
		
	}
}
