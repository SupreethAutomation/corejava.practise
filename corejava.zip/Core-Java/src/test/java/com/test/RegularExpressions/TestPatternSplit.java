package com.test.RegularExpressions;

import com.java.regularExpressions.Pattern_Split;

public class TestPatternSplit 
{
	public static void main(String[] args) 
	{
		System.out.println("Split by space");
		Pattern_Split.split_RegExp("\\s", "Erevmax Technologies Pvt Ltd.");
		System.out.println("********************************************");
		
		System.out.println("Split by o");
		Pattern_Split.split_RegExp("o", "Erevmax Technologies Pvt Ltd.");
		System.out.println("********************************************");
		
		System.out.println("Split by . means except any character split rest");
		Pattern_Split.split_RegExp(".", "Erevmax Technologies Pvt Ltd.");
		System.out.println("********************************************");
		
		System.out.println("Split by . means except any character split rest");
		Pattern_Split.split_RegExp("\\.", "www.erevmax.com");
		System.out.println("********************************************");
		
		System.out.println("Split by . means except any character split rest");
		Pattern_Split.split_RegExp("[.]", "www.erevmax.com");
		System.out.println("********************************************");
	}
}
