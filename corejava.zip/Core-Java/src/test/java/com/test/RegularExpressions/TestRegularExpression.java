package com.test.RegularExpressions;

import java.io.File;
import java.io.IOException;

import com.java.regularExpressions.RegExpDemo;

public class TestRegularExpression 
{
	public static void main(String[] args) 
	{
		RegExpDemo.matchAndFindStartIndexOfTheMatch("ab","abababba");
		System.out.println("***************************************");
		RegExpDemo.matchAndFindEndIndexOfTheMatch("ab","abababba");
		System.out.println("***************************************");
		RegExpDemo.matchAndFindGroupIndexOfTheMatch("ab","abababba");
		System.out.println("***************************************");
		
		RegExpDemo.validateIndianTelephoneNumber("[7-9][0-9]{9}","8861122754");
		System.out.println("***************************************");
		RegExpDemo.validateIndianTelephoneNumber("[7-9][0-9]{9}","123456");
		System.out.println("***************************************");
		RegExpDemo.validateIndianTelephoneNumber("[7-9][0-9]{9}","6666666666");
		System.out.println("***************************************");
		RegExpDemo.validateIndianTelephoneNumber("0?[7-9][0-9]{9}","08861122754");
		System.out.println("***************************************");
		RegExpDemo.validateIndianTelephoneNumber("0?[7-9][0-9]{9}","0123456");
		System.out.println("***************************************");
		RegExpDemo.validateIndianTelephoneNumber("0?[7-9][0-9]{9}","06666666666");
		System.out.println("***************************************");
		RegExpDemo.validateIndianTelephoneNumber("(0|91)?[7-9][0-9]{9}","918861122754");
		System.out.println("***************************************");
		RegExpDemo.validateIndianTelephoneNumber("(0|91)?[7-9][0-9]{9}","08861122754");
		System.out.println("***************************************");
		RegExpDemo.validateIndianTelephoneNumber("(0|91)?[7-9][0-9]{9}","53232323230");
		System.out.println("***************************************");
		
		RegExpDemo.validateEmailID("[a-zA-Z0-9][a-zA-Z0-9_.]*@[a-zA-Z0-9]+([.][a-zA-Z]+)+", "durga_ocjp.123@gmail.com");
		System.out.println("***************************************");
		RegExpDemo.validateEmailID("[a-zA-Z0-9][a-zA-Z0-9_.]*@[a-zA-Z0-9]+([.][a-zA-Z]+)+", "123durga_ocjp.123@gmail.com");
		System.out.println("***************************************");
		RegExpDemo.validateEmailID("[a-zA-Z0-9][a-zA-Z0-9_.]*@[a-zA-Z0-9]+([.][a-zA-Z]+)+", "durga_ocjp.123@YAHOO.co.in");
		System.out.println("***************************************");
		RegExpDemo.validateEmailID("[a-zA-Z0-9][a-zA-Z0-9_.]*@[a-zA-Z0-9]+([.][a-zA-Z]+)+", "@durga_ocjp.123@YAHOO.co.in.edu");
		System.out.println("***************************************");
		
		RegExpDemo.validateStudentName("[sS][a-zA-Z]*", "supreeth");
		System.out.println("***************************************");
		RegExpDemo.validateStudentName("[sS][a-zA-Z]*", "Supreeth");
		System.out.println("***************************************");
		RegExpDemo.validateStudentName("[sS][a-zA-Z]*", "zupreeth");
		System.out.println("***************************************");
		
		RegExpDemo.validateStudentName("[a-zA-Z]*[hH]", "supreeth");
		System.out.println("***************************************");
		RegExpDemo.validateStudentName("[a-zA-Z]*[hH]", "SupreetH");
		System.out.println("***************************************");
		RegExpDemo.validateStudentName("[a-zA-Z]*[hH]", "SupreetS");
		System.out.println("***************************************");
		
		RegExpDemo.validateStudentName("[sS][a-zA-Z]*[hH]", "supreeth");
		System.out.println("***************************************");
		RegExpDemo.validateStudentName("[sS][a-zA-Z]*[hH]", "SupreetH");
		System.out.println("***************************************");
		RegExpDemo.validateStudentName("[sS][a-zA-Z]*[hH]", "zupreets");
		System.out.println("***************************************");
		
		File outputFile = new File("D:\\corejava\\Core-Java\\src\\test\\resources\\appln\\output.txt");
		File inputFile = new File("D:\\corejava\\Core-Java\\src\\test\\resources\\appln\\input.txt");
		
		try {
			RegExpDemo.extractMobileNumbersFromFile(outputFile, inputFile, "(0|91)?[7-9][0-9]{9}");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			RegExpDemo.extractemailIdsFromFile(outputFile, inputFile, "[a-zA-Z0-9][a-zA-Z0-9_.]*@[a-zA-Z0-9]+([.][a-zA-Z]+)+");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
