package com.test.RegularExpressions;

import com.java.regularExpressions.PredefinedCharacterRegExp;

public class TestPredefinedCharacterRegExp 
{
	public static void main(String[] args) 
	{
		System.out.println("Search for Space character");
		PredefinedCharacterRegExp.matchAndFindStartIndexOfTheMatch("\\s","a7b k@9");
		System.out.println("*****************************************************");
		System.out.println("Search for Non-Space character");
		PredefinedCharacterRegExp.matchAndFindStartIndexOfTheMatch("\\S","a7b k@9");
		System.out.println("*****************************************************");
		System.out.println("Search for digit character");
		PredefinedCharacterRegExp.matchAndFindStartIndexOfTheMatch("\\d","a7b k@9");
		System.out.println("*****************************************************");
		System.out.println("Search for Non Digit character");
		PredefinedCharacterRegExp.matchAndFindStartIndexOfTheMatch("\\D","a7b k@9");
		System.out.println("*****************************************************");
		System.out.println("Search for word character (alphanumeric)");
		PredefinedCharacterRegExp.matchAndFindStartIndexOfTheMatch("\\w","a7b k@9");
		System.out.println("*****************************************************");
		System.out.println("Search for NonWord character (special character)");
		PredefinedCharacterRegExp.matchAndFindStartIndexOfTheMatch("\\W","a7b k@9");
		System.out.println("*****************************************************");
		System.out.println("Search for any character");
		PredefinedCharacterRegExp.matchAndFindStartIndexOfTheMatch(".","a7b k@9");
		System.out.println("*****************************************************");
		
	}
}
