package com.jqueryui.button;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.jqueryui.MainTest.MainTest;

public class Button extends MainTest
{
	public Button(WebDriver objWebDriver) {
		this.objWebDriver = objWebDriver;
	}

	public void TestButton_Default()
	{
		objWebDriver.get("https://jqueryui.com/button/");
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame); 
		WebElement objEle = objWebDriver.findElement(By.xpath("//div[@class='widget']//button"));
		System.out.println("before click");
		String topBefore = objEle.getCssValue("border-top-color");
		String leftBefore = objEle.getCssValue("border-left-color");
		String rightBefore = objEle.getCssValue("border-right-color");
		String bottomBefore = objEle.getCssValue("border-bottom-color");
		
		System.out.println(topBefore + leftBefore + rightBefore + bottomBefore);
		
		objEle.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("after click");
		String topAfter = objEle.getCssValue("border-top-color");
		String leftAfter = objEle.getCssValue("border-left-color");
		String rightAfter = objEle.getCssValue("border-right-color");
		String bottomAfter = objEle.getCssValue("border-bottom-color");
		
		System.out.println(topAfter + leftAfter + rightAfter + bottomAfter);
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	} 

}
