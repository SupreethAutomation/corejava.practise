package com.jqueryui.draggable;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.jqueryui.MainTest.MainTest;

public class Draggable_RevertPosition extends MainTest
{
	
	public Draggable_RevertPosition(WebDriver objWebDriver) {
		this.objWebDriver = objWebDriver;
	}
 
	public void TestDraggable_SortableInteraction() 
	{
		objWebDriver.get("https://jqueryui.com/draggable/");
		objWebDriver.findElement(By.linkText("Revert position")).click();
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame); 
		WebElement eleDraggable = objWebDriver.findElement(By.id("draggable"));
		String style1 = eleDraggable.getAttribute("style");
		System.out.println(style1); 
		
		try
		{
			System.out.println("TRY");
			Actions objActions = new Actions(objWebDriver);
			objActions.clickAndHold(objWebDriver.findElement(By.id("draggable"))).moveByOffset(0, 50).release(objWebDriver.findElement(By.id("draggable"))).perform();
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String style2 = objWebDriver.findElement(By.id("draggable")).getAttribute("style");
			System.out.println(style2);
			objWebDriver.switchTo().defaultContent();
			try {
				Thread.sleep(2500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Assert.assertEquals(style1, style2);
		}
		catch(Exception exp)
		{
			System.out.println("CATCH");
			Actions objActions = new Actions(objWebDriver);
			objActions.clickAndHold(objWebDriver.findElement(By.id("draggable"))).moveByOffset(0, 50).release(objWebDriver.findElement(By.id("draggable"))).perform();
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String style2 = objWebDriver.findElement(By.id("draggable")).getAttribute("style");
			System.out.println(style2);
			objWebDriver.switchTo().defaultContent();
			try {
				Thread.sleep(2500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Assert.assertEquals("position: relative; left: 0px; top: 0px;", style2);
		}
		
	}
}
