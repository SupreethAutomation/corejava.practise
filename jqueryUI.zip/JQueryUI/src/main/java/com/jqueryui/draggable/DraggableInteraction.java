package com.jqueryui.draggable;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.jqueryui.MainTest.MainTest;

public class DraggableInteraction extends MainTest
{
//	public WebDriver objWebDriver;
	
	public DraggableInteraction(WebDriver objWebDriver) {
		this.objWebDriver = objWebDriver;
	}

	public void TestDraggableInteraction() 
	{
		objWebDriver.get("https://jqueryui.com/draggable/");
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);
		WebElement eleDraggable = objWebDriver.findElement(By.id("draggable"));
		Actions objActions = new Actions(objWebDriver);
		objActions.clickAndHold(eleDraggable).moveByOffset(100, 100).release(eleDraggable).perform();
		String style = eleDraggable.getAttribute("style");
		System.out.println(style);
		Assert.assertEquals(style, "position: relative; left: 100px; top: 100px;");
		objWebDriver.switchTo().defaultContent();
		try {
			Thread.sleep(2500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
