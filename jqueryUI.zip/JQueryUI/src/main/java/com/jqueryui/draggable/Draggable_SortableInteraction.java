package com.jqueryui.draggable;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.jqueryui.MainTest.MainTest;

public class Draggable_SortableInteraction extends MainTest
{
//	public WebDriver objWebDriver;
	public Draggable_SortableInteraction(WebDriver objWebDriver) {
		this.objWebDriver = objWebDriver;
	}

	public void TestDraggable_SortableInteraction() 
	{
		objWebDriver.get("https://jqueryui.com/draggable/");
		
		
		objWebDriver.findElement(By.linkText("jQuery UI Draggable + Sortable")).click();
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);
		
		WebElement eleDraggable = objWebDriver.findElement(By.xpath("//ul[@id='sortable']//li[1]"));
		Actions objActions = new Actions(objWebDriver);
		objActions.clickAndHold(eleDraggable).moveByOffset(0, 50).release(eleDraggable).perform();
		try {
			Thread.sleep(2500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		objActions.clickAndHold(eleDraggable).moveByOffset(0, -45).release(eleDraggable).perform();
		objWebDriver.switchTo().defaultContent();
		try {
			Thread.sleep(2500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
