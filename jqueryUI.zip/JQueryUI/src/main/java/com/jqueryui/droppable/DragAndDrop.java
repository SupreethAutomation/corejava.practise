package com.jqueryui.droppable;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.jqueryui.MainTest.MainTest;

public class DragAndDrop extends MainTest
{
//	public WebDriver objWebDriver;
	
	public DragAndDrop(WebDriver objWebDriver) {
		this.objWebDriver = objWebDriver;
	}
	
	public void TestDragAndDrop_Default() 
	{
		objWebDriver.get("https://jqueryui.com/droppable/");
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);
		WebElement objDraggable = objWebDriver.findElement(By.id("draggable"));
		
		WebElement objDroppable = objWebDriver.findElement(By.id("droppable"));
		
		
		String backgroundColor_Droppable_before = objDroppable.getCssValue("background-color");
		System.out.println("backgroundColor_Droppable_before:"+backgroundColor_Droppable_before);
		
		Assert.assertEquals(backgroundColor_Droppable_before, "rgba(233, 233, 233, 1)");
		
		String textColor_Droppable_before = objDroppable.getCssValue("color");
		System.out.println("textColor_Droppable_before:"+textColor_Droppable_before);
		
		Assert.assertEquals(textColor_Droppable_before, "rgba(51, 51, 51, 1)");
		
		Assert.assertEquals(objWebDriver.findElement(By.xpath("//div[@id='droppable']//p")).getText(),"Drop here");
		
		
		Actions objActions = new Actions(objWebDriver);
		objActions.dragAndDrop(objDraggable, objDroppable).release(objDraggable).perform();
		
		String backgroundColor_Droppable_after = objDroppable.getCssValue("background-color");
		System.out.println("backgroundColor_Droppable_after:"+backgroundColor_Droppable_after);
		
		Assert.assertEquals(backgroundColor_Droppable_after, "rgba(255, 250, 144, 1)");
		
		String textColor_Droppable_after = objDroppable.getCssValue("color");
		System.out.println("backgroundColor_Droppable_after:"+textColor_Droppable_after);
		
		Assert.assertEquals(textColor_Droppable_after, "rgba(119, 118, 32, 1)");
		
		Assert.assertEquals(objWebDriver.findElement(By.xpath("//div[@id='droppable']//p")).getText(),"Dropped!");
		
		try {
			Thread.sleep(2500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		objWebDriver.switchTo().defaultContent();
	}
	
	public void TestDragAndDrop_PhotoManager() 
	{
		objWebDriver.get("https://jqueryui.com/droppable/");
		
		objWebDriver.findElement(By.linkText("Simple photo manager")).click();
		
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);
		
		WebElement objElement_Trash = objWebDriver.findElement(By.id("trash"));
		
		List<WebElement> listOfImages = objWebDriver.findElements(By.xpath("//ul[@id='gallery']//li//img")); 
		
		 
		int listOriginalSize = listOfImages.size();
		System.out.println("Original list of elements: "+listOriginalSize);
		
		Actions objActions = new Actions(objWebDriver);
		
		for(WebElement ele : listOfImages)
		{
			objActions.dragAndDrop(ele, objElement_Trash).release().perform();
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		listOriginalSize = objWebDriver.findElements(By.xpath("//ul[@id='gallery']//li")).size();
		System.out.println("new list of elements: "+listOriginalSize);
		Assert.assertEquals(listOriginalSize, 0);
		List<WebElement> listOfImages_Trash = objWebDriver.findElements(By.xpath("//div[@id='trash']//li//img")); 
		Assert.assertEquals(listOfImages_Trash.size(), 4);
		
		try {
			Thread.sleep(2500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	
	
}
