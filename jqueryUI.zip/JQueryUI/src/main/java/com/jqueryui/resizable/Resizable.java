package com.jqueryui.resizable;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.jqueryui.MainTest.MainTest;

public class Resizable extends MainTest
{
//	public WebDriver objWebDriver;
	
	public Resizable(WebDriver objWebDriver) {
		this.objWebDriver = objWebDriver;
	}
	
	public void TestResizeHorizontal_Default() 
	{
		objWebDriver.get("https://jqueryui.com/resizable/");
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);
		
		WebElement objDraggable = objWebDriver.findElement(By.xpath("//div[contains(@class,'ui-resizable-e')]"));
		
		Actions objActions = new Actions(objWebDriver);
		objActions.dragAndDropBy(objDraggable, 100, 0).release(objDraggable).perform();
		
		try {
			Thread.sleep(2500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		objWebDriver.switchTo().defaultContent();
	}
	
	public void TestResizeVertical_Default() 
	{
		objWebDriver.get("https://jqueryui.com/resizable/");
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);
		
		WebElement objDraggable = objWebDriver.findElement(By.xpath("//div[contains(@class,'ui-resizable-s')]"));
		
		Actions objActions = new Actions(objWebDriver);
		objActions.dragAndDropBy(objDraggable, 0, 100).release(objDraggable).perform();
		
		try {
			Thread.sleep(2500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		objWebDriver.switchTo().defaultContent();
	}
	
	public void TestResizebothDirection() 
	{
		objWebDriver.get("https://jqueryui.com/resizable/");
		
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);
		
		Actions objActions = new Actions(objWebDriver);
		objActions.dragAndDropBy(objWebDriver.findElement(By.cssSelector(".ui-resizable-handle.ui-resizable-se.ui-icon.ui-icon-gripsmall-diagonal-se")),150,150).release().perform();
		try {
			Thread.sleep(2500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		objWebDriver.switchTo().defaultContent();
	}
	
	public void TestResizeAnimate() 
	{
		objWebDriver.get("https://jqueryui.com/resizable/");
		
		WebElement objAnimate = objWebDriver.findElement(By.linkText("Animate"));
		objAnimate.click();
		
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);

		Actions objActions = new Actions(objWebDriver);
		
		try {
		objActions = objActions.dragAndDropBy(objWebDriver.findElement(By.cssSelector(".ui-resizable-handle.ui-resizable-se.ui-icon.ui-icon-gripsmall-diagonal-se")),150,150);
		objActions.release(objWebDriver.findElement(By.cssSelector(".ui-resizable-handle.ui-resizable-se.ui-icon.ui-icon-gripsmall-diagonal-se"))).perform();
		}
		catch (Exception e) {
			objActions = objActions.dragAndDropBy(objWebDriver.findElement(By.cssSelector(".ui-resizable-handle.ui-resizable-se.ui-icon.ui-icon-gripsmall-diagonal-se")),150,150);
			objActions.release(objWebDriver.findElement(By.cssSelector(".ui-resizable-handle.ui-resizable-se.ui-icon.ui-icon-gripsmall-diagonal-se"))).perform();
		}
		try {
			Thread.sleep(2500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		objWebDriver.switchTo().defaultContent();
	}
}
