package com.jqueryui.widgets.accordion;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.jqueryui.MainTest.MainTest;

public class Accordion extends MainTest
{
	public Accordion(WebDriver objWebDriver) {
		this.objWebDriver = objWebDriver;
	}

	public void TestAccordion_Default()
	{
		objWebDriver.get("https://jqueryui.com/accordion/");
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame); 
		int sectionCount = objWebDriver.findElements(By.xpath("//div[@id='accordion']//h3")).size();
		System.out.println("No of SEctions: "+ sectionCount);
		String activeSection = objWebDriver.findElement(By.cssSelector("h3#ui-id-1.ui-state-active")).getText();
		Assert.assertEquals("Section 1", activeSection);
		String bckGnColor = objWebDriver.findElement(By.cssSelector("h3#ui-id-1.ui-state-active")).getCssValue("background-color");
		Assert.assertEquals("rgba(0, 127, 255, 1)", bckGnColor);
		List<WebElement> objList = objWebDriver.findElements(By.xpath("//h3[contains(@class,'ui-accordion-header-collapsed')]"));
		List<String> objNonClicked = new ArrayList<String>();
		for(WebElement ele : objList)
		{
			objNonClicked.add(ele.getText());
		}
		Assert.assertTrue(objNonClicked.contains("Section 2"));
		Assert.assertTrue(objNonClicked.contains("Section 3"));
		Assert.assertTrue(objNonClicked.contains("Section 4"));
		Assert.assertFalse(objNonClicked.contains("Section 1"));
	}

	public void TestExpandCollapseSections()
	{
		objWebDriver.get("https://jqueryui.com/accordion/");

		objWebDriver.findElement(By.linkText("Collapse content")).click();

		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame); 


		WebElement objSection1 = objWebDriver.findElement(By.xpath("//h3[text()='Section 1']"));
		WebElement objSection4 = objWebDriver.findElement(By.xpath("//h3[text()='Section 4']"));


		

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try
		{

			objSection4.click();
			Assert.assertTrue(objSection4.getAttribute("class").contains("ui-accordion-header-active"));

			Assert.assertTrue(objSection1.getAttribute("class").contains("ui-state-default"));
			
			
			objSection1.click();
			Assert.assertTrue(objSection1.getAttribute("class").contains("ui-accordion-header-active"));

			Assert.assertTrue(objSection4.getAttribute("class").contains("ui-state-default"));
		}
		catch(Exception exp)
		{
			
			objSection1 = objWebDriver.findElement(By.xpath("//h3[text()='Section 1']"));
			objSection4 = objWebDriver.findElement(By.xpath("//h3[text()='Section 4']"));
			objSection4.click();
			Assert.assertTrue(objSection4.getAttribute("class").contains("ui-accordion-header-active"));
			Assert.assertTrue(objSection1.getAttribute("class").contains("ui-state-default"));
			objSection1 = objWebDriver.findElement(By.xpath("//h3[text()='Section 1']"));
			objSection4 = objWebDriver.findElement(By.xpath("//h3[text()='Section 4']"));
			objSection4.click();
			objSection1.click();
			Assert.assertTrue(objSection1.getAttribute("class").contains("ui-accordion-header-active"));

			Assert.assertTrue(objSection4.getAttribute("class").contains("ui-state-default"));
		}

	}

	public void TestNoAutoHeight()
	{
		objWebDriver.get("https://jqueryui.com/accordion/");
		objWebDriver.findElement(By.linkText("No auto height")).click();
		WebElement demo_frame = null;
		WebElement objSection3 = null;
		JavascriptExecutor obJavascriptExecutor = null;
		WebDriverWait objDriverWait = new WebDriverWait(objWebDriver, 20);
		try {
			demo_frame = objWebDriver.findElement(By.className("demo-frame"));
			objWebDriver.switchTo().frame(demo_frame); 
			System.out.println("inside if");
			objSection3 = objWebDriver.findElement(By.id("ui-id-5"));
		/*	Actions objActions = new Actions(objWebDriver);
			objActions.doubleClick(objSection3);
			*/
			obJavascriptExecutor = (JavascriptExecutor) objWebDriver;
			obJavascriptExecutor.executeScript("arguments[0].click();",objSection3);
			obJavascriptExecutor.executeScript("window.scrollBy(0, 100);");
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		catch(Exception exp)
		{
			/*demo_frame = objWebDriver.findElement(By.className("demo-frame"));
			objWebDriver.switchTo().frame(demo_frame); 
			System.out.println("inside else");
			objSection3 = objDriverWait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h3[text()='Section 3']//following-sibling::div")));
			objWebDriver.findElement(By.xpath("//h3[text()='Section 3']")).click();
			obJavascriptExecutor = (JavascriptExecutor) objWebDriver;
			obJavascriptExecutor.executeScript("window.scrollBy(0, 10);");
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
*/
		}

	}

}
