package com.jqueryui.widgets.autocomplete;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.jqueryui.MainTest.MainTest;

public class AutoComplete extends MainTest
{
	public AutoComplete(WebDriver objWebDriver) {
		this.objWebDriver = objWebDriver;
	}

	public void TestAutoComplete_Default()
	{
		objWebDriver.get("https://jqueryui.com/autocomplete/");
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame); 
		WebElement objEle = objWebDriver.findElement(By.id("ui-id-1"));
		Assert.assertFalse(objEle.isDisplayed(),"Options are displayed");
		objWebDriver.findElement(By.id("tags")).sendKeys("Java");
		objWebDriverWait = new WebDriverWait(objWebDriver, 10);
		objWebDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@id='ui-id-1']")));
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Assert.assertTrue(objEle.isDisplayed(),"Options are not displayed");
		
		Assert.assertEquals(objWebDriverWait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@id='ui-id-1']//li"))).size(),2);
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void TestAutoComboBox(String item)
	{
		objWebDriver.get("https://jqueryui.com/autocomplete/");
		
		WebElement objElement = objWebDriver.findElement(By.linkText("Combobox"));
		objElement.click();
		
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame); 
/*
		objWebDriver.findElement(By.xpath("//a[@role='button']")).click();
		JavascriptExecutor obJavascriptExecutor = null;
		obJavascriptExecutor = (JavascriptExecutor) objWebDriver;
		obJavascriptExecutor.executeScript("window.scrollBy(0, 200);");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		obJavascriptExecutor.executeScript("window.scrollBy(0, -200);");*/
		WebElement objEle = objWebDriver.findElement(By.id("ui-id-1"));
		objWebDriver.findElement(By.xpath("//span[@class='custom-combobox']//input")).sendKeys("a");
		objWebDriverWait = new WebDriverWait(objWebDriver, 10);
		objWebDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@id='ui-id-1']")));
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Assert.assertTrue(objWebDriver.findElement(By.id("ui-id-1")).isDisplayed(),"Options are not displayed");
		
		Assert.assertEquals(objWebDriverWait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@id='ui-id-1']//li"))).size(),10);
		
		objWebDriver.findElement(By.xpath("//ul[@id='ui-id-1']//div[text()='"+item+"']")).click();
		
		objWebDriver.findElement(By.id("toggle")).click();
		
		Select objSelect = new Select(objWebDriver.findElement(By.id("combobox")));
		
		String selectedText = objSelect.getFirstSelectedOption().getText();
		
		System.out.println("Selected Option: " + selectedText);
		
		Assert.assertEquals(selectedText, "BASIC");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	

	}

