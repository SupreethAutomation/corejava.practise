package com.jqueryui.sortable;


import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.jqueryui.MainTest.MainTest;

public class Sortable extends MainTest
{
	/*public WebDriver objWebDriver;
	 */
	public Sortable(WebDriver objWebDriver) {
		this.objWebDriver = objWebDriver;
	} 

	public void TestMoveFirstitemToLast_javascript() 
	{
		objWebDriver.get("https://jqueryui.com/sortable/");
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);

		WebElement objDraggable_element_1 = objWebDriver.findElement(By.xpath("(//ul[@id='sortable']//li)[1]"));
		WebElement objDraggable_element_7 = objWebDriver.findElement(By.xpath("(//ul[@id='sortable']//li)[7]"));

		JavascriptExecutor objJavascriptExecutor = (JavascriptExecutor) objWebDriver;
		objJavascriptExecutor.executeScript("arguments[0].setAttribute('style', 'width: 151.44px;height: 18.08px; position: absolute; z-index:1000; left: 7px; top: 253px;')",objDraggable_element_1);

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		objJavascriptExecutor.executeScript("arguments[0].setAttribute('style', 'width: 151.44px;height: 18.08px; position: absolute; z-index:1000; left: 11px; top: 6.4px;')",objDraggable_element_7);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void TestMoveFirstitemToLast() 
	{
		objWebDriver.get("https://jqueryui.com/sortable/");
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);
		List<WebElement> objLstOfItems = objWebDriver.findElements(By.xpath("//ul[@id='sortable']//li"));
		List<String> objStrLstOfItems = new ArrayList<String>();
		for(WebElement webEle : objLstOfItems)
		{
			objStrLstOfItems.add(webEle.getText());
		} 
		System.out.println(objStrLstOfItems.get(objLstOfItems.size()-objLstOfItems.size()));
		Assert.assertEquals(objStrLstOfItems.get(0),"Item 1","Item is not matching");
		WebElement objDraggable_element_1 = objWebDriver.findElement(By.xpath("(//ul[@id='sortable']//li)[1]"));
		Actions objActions = new Actions(objWebDriver);
		for(int i = 0; i <=2; i++)
		{
			objActions = objActions.dragAndDropBy(objDraggable_element_1,0,100);
			objActions.release(objDraggable_element_1).perform();
		}
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		objLstOfItems.clear();
		objStrLstOfItems.clear();
		objLstOfItems = objWebDriver.findElements(By.xpath("//ul[@id='sortable']//li"));
		for(WebElement webEle : objLstOfItems)
		{
			objStrLstOfItems.add(webEle.getText());
		}
		System.out.println(objStrLstOfItems.get(objLstOfItems.size()-1));
		Assert.assertEquals(objStrLstOfItems.get(objLstOfItems.size()-1),"Item 1","Item is not matching");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		objWebDriver.switchTo().defaultContent();
	}

	public void TestReOrderItems_DescendingOrder()
	{
		objWebDriver.get("https://jqueryui.com/sortable/");
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);

		WebElement objDraggable_element_7 = objWebDriver.findElement(By.xpath("(//ul[@id='sortable']//li)[7]"));
		Actions objActions = new Actions(objWebDriver);
		for(int i = 0; i <=2; i++)
		{
			objActions = objActions.dragAndDropBy(objDraggable_element_7,0,-80);
			objActions.release(objDraggable_element_7).perform();
		}
		objDraggable_element_7 = objWebDriver.findElement(By.xpath("(//ul[@id='sortable']//li)[7]"));
		for(int i = 0; i <=4; i++)
		{
			System.out.println(objDraggable_element_7.getText());
			objActions = objActions.dragAndDropBy(objDraggable_element_7,0,-40);
			objActions.release(objDraggable_element_7).perform();
		}

		objDraggable_element_7 = objWebDriver.findElement(By.xpath("(//ul[@id='sortable']//li)[7]"));
		for(int i = 0; i <=3; i++)
		{
			System.out.println(objDraggable_element_7.getText());
			objActions = objActions.dragAndDropBy(objDraggable_element_7,0,-40);
			objActions.release(objDraggable_element_7).perform();
		}

		objDraggable_element_7 = objWebDriver.findElement(By.xpath("(//ul[@id='sortable']//li)[7]"));
		for(int i = 0; i <=2; i++)
		{
			System.out.println(objDraggable_element_7.getText());
			objActions = objActions.dragAndDropBy(objDraggable_element_7,0,-40);
			objActions.release(objDraggable_element_7).perform();
		}

		objDraggable_element_7 = objWebDriver.findElement(By.xpath("(//ul[@id='sortable']//li)[7]"));
		for(int i = 0; i <=1; i++)
		{
			System.out.println(objDraggable_element_7.getText());
			objActions = objActions.dragAndDropBy(objDraggable_element_7,0,-40);
			objActions.release(objDraggable_element_7).perform();
		}

		objDraggable_element_7 = objWebDriver.findElement(By.xpath("(//ul[@id='sortable']//li)[6]"));
		for(int i = 0; i <=1; i++)
		{
			System.out.println(objDraggable_element_7.getText());
			objActions = objActions.dragAndDropBy(objDraggable_element_7,0,45);
			objActions.release(objDraggable_element_7).perform();
		}
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		objWebDriver.switchTo().defaultContent();
	}

	public void TestConnectLists()
	{
		objWebDriver.get("https://jqueryui.com/sortable/");
		objWebDriver.findElement(By.linkText("Connect lists")).click();
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);
		WebElement objDraggable_List1element_1 = null;
		WebElement objDraggable_List2element_1 = null;
		int lstCount = objWebDriver.findElements(By.xpath("//ul[@id='sortable1']//li")).size() * 2;
		Actions objActions = new Actions(objWebDriver);
		for(int j = 1; j<=lstCount; j=j+2)
		{
			int i = 1;
			objDraggable_List1element_1 = objWebDriver.findElement(By.xpath("(//ul[@id='sortable1']//li)["+i+"]"));
			objDraggable_List2element_1 = objWebDriver.findElement(By.xpath("(//ul[@id='sortable2']//li)["+j+"]"));
			objActions = objActions.dragAndDrop(objDraggable_List1element_1,objDraggable_List2element_1);
			objActions.release(objDraggable_List1element_1).perform();
		}
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		objWebDriver.switchTo().defaultContent();
	}

	public void TestDisplayAsGrid()
	{
		objWebDriver.get("https://jqueryui.com/sortable/");
		objWebDriver.findElement(By.linkText("Display as grid")).click();
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);
		WebElement objDraggable_List1element_1 = null;
		WebElement objDraggable_List1element_N = null;
		WebDriverWait objDriverWait = new WebDriverWait(objWebDriver, 20);
		int lstCount = objDriverWait.until(ExpectedConditions.numberOfElementsToBeMoreThan(By.cssSelector(".ui-state-default.ui-sortable-handle"), 10)).size();
		System.out.println("lstCount: "+lstCount);

		Actions objActions = new Actions(objWebDriver);
		int locX_12 = 0;
		int locY_12 = 0;
		for(int i = 1; i<=lstCount; i=i+1)
		{
			objDraggable_List1element_1 = objWebDriver.findElement(By.xpath("(//ul[@id='sortable']//li)[1]"));
			objDraggable_List1element_N = objWebDriver.findElement(By.xpath("(//ul[@id='sortable']//li)[12]"));
			locX_12 = objDraggable_List1element_N.getLocation().x;
			locY_12 = objDraggable_List1element_N.getLocation().y;
			objActions = objActions.dragAndDropBy(objDraggable_List1element_1,locX_12+5,locY_12+5);
			objActions.release(objDraggable_List1element_1).perform();
		}
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		objWebDriver.switchTo().defaultContent();
	}

	public void TestPortlets(String itemName)
	{
		objWebDriver.get("https://jqueryui.com/sortable/");
		objWebDriver.findElement(By.linkText("Portlets")).click();
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);

		WebElement objElement = objWebDriver.findElement(By.xpath("//div[text()='"+itemName+"']//span"));
		String className = objElement.getAttribute("class");

		Assert.assertTrue(className.contains("ui-icon-minusthick"));

		objWebDriver.findElement(By.xpath("//div[text()='"+itemName+"']//span")).click();

		objElement = objWebDriver.findElement(By.xpath("//div[text()='"+itemName+"']//span"));
		className = objElement.getAttribute("class");

		Assert.assertTrue(className.contains("ui-icon-plusthick"));

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		objWebDriver.switchTo().defaultContent();

	}

}
