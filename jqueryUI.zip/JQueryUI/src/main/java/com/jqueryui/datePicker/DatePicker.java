package com.jqueryui.datePicker;

import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.jqueryui.MainTest.MainTest;

public class DatePicker extends MainTest
{
	public DatePicker(WebDriver objWebDriver) {
		this.objWebDriver = objWebDriver;
	}
	
	public void TestDefaultFunctionality()
	{
		objWebDriver.get("https://jqueryui.com/datepicker/");
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame); 
		WebElement objElement_DatePicker = objWebDriver.findElement(By.id("ui-datepicker-div"));
		boolean isDisplayed =  objElement_DatePicker.isDisplayed();
		Assert.assertFalse(isDisplayed);
		System.out.println("DataPicker displayed: " + isDisplayed);
		objWebDriver.findElement(By.id("datepicker")).click();
		isDisplayed = objElement_DatePicker.isDisplayed();
		Assert.assertTrue(isDisplayed);
		objWebDriverWait = new WebDriverWait(objWebDriver, 20);
		objWebDriverWait.until(ExpectedConditions.elementToBeClickable(objElement_DatePicker));
		System.out.println("DataPicker displayed: " + isDisplayed);		
		
		// check the current date
		Calendar today = Calendar.getInstance();
		int today_num = today.getTime().getDate();
		int month_num = (today.getTime().getMonth())+1;
		int year_num = today.getWeekYear();
		
		Integer objInteger = new Integer(today_num);
		String str_Num = objInteger.toString(today_num);
		System.out.println(str_Num);
		
		System.out.println(month_num);		
		System.out.println(year_num);
		
		WebElement dateElement = objWebDriver.findElement(By.xpath("//a[contains(@class,'ui-state-highlight')]"));
		String str_Num_UI = dateElement.getText();
		
		Assert.assertEquals(str_Num, str_Num_UI);
		String bgColor = dateElement.getCssValue("background-color");
		
		System.out.println(bgColor);
		
		Assert.assertEquals(bgColor, "rgba(255, 250, 144, 1)");
		
		
		dateElement.click();
		isDisplayed =  objElement_DatePicker.isDisplayed();
		System.out.println("DataPicker displayed: " + isDisplayed);
		Assert.assertTrue(isDisplayed);
		String selectedValue = objWebDriver.findElement(By.id("datepicker")).getAttribute("value");
		System.out.println("selected value:" + selectedValue);
		
		Assert.assertEquals(selectedValue, month_num+"/"+str_Num+"/"+year_num);
	}
	
	public void TestFormatDateFunctionality()
	{
		objWebDriver.get("https://jqueryui.com/datepicker/");
		
		objWebDriver.findElement(By.linkText("Format date")).click();
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame); 
		
		try
		{
		
		objWebDriver.findElement(By.id("datepicker")).click();
		objWebDriver.findElement(By.xpath("//a[contains(@class,'ui-state-highlight')]")).click();
		
		Calendar today = Calendar.getInstance();
		int today_num = today.getTime().getDate();
		int month_num = (today.getTime().getMonth())+1;
		int year_num = today.getWeekYear();
		String selectedValue = objWebDriver.findElement(By.id("datepicker")).getAttribute("value");
		System.out.println("selected value:" + selectedValue);
	//	Assert.assertEquals(selectedValue, month_num+"/"+today_num+"/"+year_num);
		Select objSelect = new Select(objWebDriver.findElement(By.id("format")));
		objWebDriver.findElement(By.id("datepicker")).click();
		objWebDriver.findElement(By.xpath("//a[contains(@class,'ui-state-highlight')]")).click();
		
		for(int i = 0; i <= 5; i++)
		{
			objSelect.selectByIndex(i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			selectedValue = objWebDriver.findElement(By.id("datepicker")).getAttribute("value");
			System.out.println("selected value:" + selectedValue);
		}
		
		}
		catch(Exception exp)
		{
			objWebDriver.findElement(By.id("datepicker")).click();
			objWebDriver.findElement(By.xpath("//a[contains(@class,'ui-state-highlight')]")).click();
			
			Calendar today = Calendar.getInstance();
			int today_num = today.getTime().getDate();
			int month_num = (today.getTime().getMonth())+1;
			int year_num = today.getWeekYear();
			String selectedValue = objWebDriver.findElement(By.id("datepicker")).getAttribute("value");
			System.out.println("selected value:" + selectedValue);
			
		//	Assert.assertEquals(selectedValue, month_num+"/"+today_num+"/"+year_num);
			
			objWebDriver.findElement(By.id("datepicker")).click();
			objWebDriver.findElement(By.xpath("//a[contains(@class,'ui-state-highlight')]")).click();
			
			Select objSelect = new Select(objWebDriver.findElement(By.id("format")));
			
			for(int i = 0; i <= 5; i++)
			{
				objSelect.selectByIndex(i);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
	
	
}
