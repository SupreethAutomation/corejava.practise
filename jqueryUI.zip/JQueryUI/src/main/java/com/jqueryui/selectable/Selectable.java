package com.jqueryui.selectable;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.jqueryui.MainTest.MainTest;

public class Selectable extends MainTest
{
//	public WebDriver objWebDriver;

	public Selectable(WebDriver objWebDriver) {
		this.objWebDriver = objWebDriver;
	}

	public void TestSelectSingleItem(String itemvalue) 
	{
		objWebDriver.get("https://jqueryui.com/selectable/");
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);
		WebElement objSelectable = objWebDriver.findElement(By.xpath("//ol[@id='selectable']//li[text()='Item "+itemvalue+"']"));

		Actions objActions = new Actions(objWebDriver);
		objActions.click(objSelectable).release(objSelectable).perform();

		Assert.assertEquals(objWebDriver.findElement(By.xpath("//li[contains(@class,'ui-selected')]")).getCssValue("background-color"),"rgba(243, 152, 20, 1)");

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		objWebDriver.switchTo().defaultContent();
	}

	public void TestSelectSingleItem_Grid(String itemvalue) 
	{
		objWebDriver.get("https://jqueryui.com/selectable/");
		WebElement objClickable = objWebDriver.findElement(By.linkText("Display as grid"));
		objClickable.click();
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);
		Actions objActions = new Actions(objWebDriver);
		WebElement objSelectable = objWebDriver.findElement(By.xpath("//ol[@id='selectable']//li[text()='"+itemvalue+"']"));
		objActions.click(objSelectable).release(objSelectable).perform();

		try {
			Thread.sleep(2500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		objWebDriver.switchTo().defaultContent();
	}

	public void TestSelectSingleItem_DisplayValue(String itemvalue) 
	{
		objWebDriver.get("https://jqueryui.com/selectable/");
		WebElement objClickable = objWebDriver.findElement(By.linkText("Serialize"));
		objClickable.click();
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);

		try {
			WebElement objSelectable = objWebDriver.findElement(By.xpath("//ol[@id='selectable']//li[text()='Item "+itemvalue+"']"));
			Actions objActions = new Actions(objWebDriver);
			objActions.click(objSelectable).release(objSelectable).perform();
		}
		catch(Exception exp)
		{
			WebElement objSelectable = objWebDriver.findElement(By.xpath("//ol[@id='selectable']//li[text()='Item "+itemvalue+"']"));
			Actions objActions = new Actions(objWebDriver);
			objActions.click(objSelectable).release(objSelectable).perform();
		}

		try {
			Thread.sleep(2500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String staticText = "You've selected:";
		String val = objWebDriver.findElement(By.xpath("(//p[@id='feedback']//span)[2]")).getText();

		System.out.println(staticText+" "+val);

		Assert.assertEquals(staticText+" "+val, staticText+" "+val,"Selected Wrong value");
		objWebDriver.switchTo().defaultContent();
	}

	public void TestMultipleSelectByClickandDrag(String itemvalue) 
	{
		objWebDriver.get("https://jqueryui.com/selectable/");
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);
		WebElement objSelectable = objWebDriver.findElement(By.xpath("//ol[@id='selectable']//li[text()='Item "+itemvalue+"']"));

		Actions objActions = new Actions(objWebDriver);
		objActions.clickAndHold(objSelectable).moveByOffset(0, 250).release().perform();

		try {
			Thread.sleep(2500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		objWebDriver.switchTo().defaultContent();
	}

	public void TestMultipleSelectByHoldandClick(String itemValue,String itemValue2,String itemValue3) 
	{
		objWebDriver.get("https://jqueryui.com/selectable/");
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);
		WebElement objSelectable = objWebDriver.findElement(By.xpath("//ol[@id='selectable']//li[text()='Item "+itemValue+"']"));

		Actions objActions = new Actions(objWebDriver);
		objActions = objActions.click(objSelectable);
		objActions = objActions.keyDown(Keys.CONTROL);
		objActions = objActions.click(objWebDriver.findElement(By.xpath("//ol[@id='selectable']//li[text()='Item "+itemValue2+"']")));
		objActions = objActions.click(objWebDriver.findElement(By.xpath("//ol[@id='selectable']//li[text()='Item "+itemValue3+"']")));
		objActions = objActions.keyUp(Keys.CONTROL);
		objActions.release().perform();

		try {
			Thread.sleep(2500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		objWebDriver.switchTo().defaultContent();
	}

	public void TestMultipleSelectAndUnselect(String itemValue,String itemValue2,String itemValue3) 
	{
		objWebDriver.get("https://jqueryui.com/selectable/");

		WebElement objClickable = objWebDriver.findElement(By.linkText("Serialize"));
		objClickable.click();

		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame);
		Actions objActions = null;
		try {
			WebElement objSelectable = objWebDriver.findElement(By.xpath("//ol[@id='selectable']//li[text()='Item "+itemValue+"']"));
			objActions = new Actions(objWebDriver);
			objActions = objActions.click(objSelectable);
			objActions = objActions.keyDown(Keys.CONTROL);
			objActions = objActions.click(objWebDriver.findElement(By.xpath("//ol[@id='selectable']//li[text()='Item "+itemValue2+"']")));
			objActions = objActions.click(objWebDriver.findElement(By.xpath("//ol[@id='selectable']//li[text()='Item "+itemValue3+"']")));
			objActions = objActions.keyUp(Keys.CONTROL);
			objActions.release().perform();
		}
		catch (Exception e) {
			WebElement objSelectable = objWebDriver.findElement(By.xpath("//ol[@id='selectable']//li[text()='Item "+itemValue+"']"));
			objActions = new Actions(objWebDriver);
			objActions = objActions.click(objSelectable);
			objActions = objActions.keyDown(Keys.CONTROL);
			objActions = objActions.click(objWebDriver.findElement(By.xpath("//ol[@id='selectable']//li[text()='Item "+itemValue2+"']")));
			objActions = objActions.click(objWebDriver.findElement(By.xpath("//ol[@id='selectable']//li[text()='Item "+itemValue3+"']")));
			objActions = objActions.keyUp(Keys.CONTROL);
			objActions.release().perform();
		}
		
		String staticText = "You've selected:";
		String val = objWebDriver.findElement(By.xpath("(//p[@id='feedback']//span)[2]")).getText();

		System.out.println(staticText+" "+val);
		Assert.assertEquals(staticText+" "+val, staticText+" "+val,"Selected Wrong value");
		
		try {
			WebElement objSelectable = objWebDriver.findElement(By.xpath("//ol[@id='selectable']//li[text()='Item "+itemValue+"']"));
			objActions.click(objSelectable).release().perform();
		}
		catch (Exception e)
		{
			WebElement objSelectable = objWebDriver.findElement(By.xpath("//ol[@id='selectable']//li[text()='Item "+itemValue+"']"));
			objActions.click(objSelectable).release().perform();
		}
		String staticText2 = "You've selected:";
		String val2 = objWebDriver.findElement(By.xpath("(//p[@id='feedback']//span)[2]")).getText();

		System.out.println(staticText2+" "+val2);
		Assert.assertEquals(staticText2+" "+val2, staticText+" "+val2,"Selected Wrong value");
		try {
			Thread.sleep(2500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		objWebDriver.switchTo().defaultContent();
	}



}
