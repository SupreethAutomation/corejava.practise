package com.jqueryui.controlgroup;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.jqueryui.MainTest.MainTest;

public class ControlGroup extends MainTest
{
	public ControlGroup(WebDriver objWebDriver) {
		this.objWebDriver = objWebDriver;
	}

	public void TestControlGroupToolBar()
	{
		objWebDriver.get("https://jqueryui.com/controlgroup/");
		objWebDriver.findElement(By.linkText("Toolbar")).click();
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame); 
		objWebDriver.findElement(By.xpath("//span[text()='Zoom']")).click();
		objWebDriver.findElement(By.xpath("//div[text()='125%']")).click();
		WebElement objElementPage = objWebDriver.findElement(By.id("page"));
		String style = objElementPage.getAttribute("style");
		System.out.println("Style: "+ style);
		Assert.assertEquals(style, "zoom: 125%;");
		Robot objRobot = null;
		try {
			objRobot = new Robot();
		} catch (AWTException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		objWebDriver.findElement(By.xpath("//span[text()='Font']")).click();
		Actions objActions = new Actions(objWebDriver);
		objActions = objActions.contextClick(objElementPage);
		objActions.sendKeys(Keys.CONTROL +"a").build().perform();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		objWebDriver.findElement(By.xpath("//span[text()='Size']")).click();
		objWebDriver.findElement(By.xpath("//div[text()='10px']")).click();

		String size = objWebDriver.findElement(By.xpath("//pre[@id='page']//font")).getAttribute("size");

		System.out.println(size);
		Assert.assertEquals(size, "3");

		objWebDriver.findElement(By.xpath("//span[text()='Highlight']")).click();
		objWebDriver.findElement(By.xpath("//div[text()='Orange']")).click();

		style = objWebDriver.findElement(By.xpath("//pre[@id='page']//font")).getAttribute("style");

		System.out.println(style);
		Assert.assertEquals(style, "background-color: orange;");
		objWebDriver.findElement(By.xpath("//span[text()='Color']")).click();

		objWebDriverWait = new WebDriverWait(objWebDriver, 10);
		objWebDriverWait.until(ExpectedConditions.visibilityOf(objWebDriver.findElement(By.xpath("(//div[text()='Grey'])[2]"))));
		objWebDriver.findElement(By.xpath("(//div[text()='Grey'])[2]")).click();

		style = objWebDriver.findElement(By.xpath("//pre[@id='page']//font")).getAttribute("color");
		System.out.println(style);
		Assert.assertEquals(style, "#cccccc");
		
		objRobot.keyPress(KeyEvent.VK_ESCAPE);
		objRobot.keyRelease(KeyEvent.VK_ESCAPE);
		
		objActions.click(objElementPage).build().perform();
	
		objRobot.keyPress(KeyEvent.VK_CONTROL);
		objRobot.keyPress(KeyEvent.VK_A);
		
		objRobot.keyRelease(KeyEvent.VK_A);
		objRobot.keyRelease(KeyEvent.VK_CONTROL);
		
		
		objRobot.keyPress(KeyEvent.VK_CONTROL);
		objRobot.keyPress(KeyEvent.VK_X);
		
		objRobot.keyRelease(KeyEvent.VK_X);
		objRobot.keyRelease(KeyEvent.VK_CONTROL);

		String text = objElementPage.getText();
		System.out.println(text.isEmpty());
		
		objRobot.keyPress(KeyEvent.VK_CONTROL);
		objRobot.keyPress(KeyEvent.VK_V);
		
		objRobot.keyRelease(KeyEvent.VK_V);
		objRobot.keyRelease(KeyEvent.VK_CONTROL);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		text = objElementPage.getText();
		System.out.println(text.isEmpty());
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
