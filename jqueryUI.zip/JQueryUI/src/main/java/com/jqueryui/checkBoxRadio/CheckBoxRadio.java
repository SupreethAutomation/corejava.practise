package com.jqueryui.checkBoxRadio;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.jqueryui.MainTest.MainTest;

public class CheckBoxRadio extends MainTest
{
	public CheckBoxRadio(WebDriver objWebDriver) {
		this.objWebDriver = objWebDriver;
	}

	public void TestRadio_Default(String item)
	{
		objWebDriver.get("https://jqueryui.com/checkboxradio/");
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame); 
		WebElement objEle = objWebDriver.findElement(By.xpath("//label[text()='"+item+"']//span[1]"));
		
		System.out.println("before click");
		String bgBefore = objWebDriver.findElement(By.xpath("//label[text()='"+item+"']")).getCssValue("backgroundColor");
		
		System.out.println(bgBefore);
		
		objEle.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("after click");
		String bgAfter = objWebDriver.findElement(By.xpath("//label[text()='"+item+"']")).getCssValue("backgroundColor");
		
		System.out.println(bgAfter);
		Assert.assertEquals(bgAfter, "rgba(0, 127, 255, 1)");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	} 
	
	public void TestCheckBoxALL_Default()
	{
		objWebDriver.get("https://jqueryui.com/checkboxradio/");
		WebElement demo_frame = objWebDriver.findElement(By.className("demo-frame"));
		objWebDriver.switchTo().frame(demo_frame); 
		List<WebElement> lstElements =   objWebDriver.findElements(By.xpath("//legend[contains(text(),'Hotel Ratings')]/following-sibling::label[contains(@for,'checkbox')]"));
		
		for(WebElement objElement: lstElements)
		{
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			objElement.click();
		}
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
