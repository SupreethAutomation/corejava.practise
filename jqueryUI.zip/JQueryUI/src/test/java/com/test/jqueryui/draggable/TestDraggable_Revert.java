package com.test.jqueryui.draggable;

import org.testng.annotations.Test;

import com.jqueryui.MainTest.MainTest;

public class TestDraggable_Revert extends MainTest
{
	@Test
	public void testDraggable()
	{
		objDraggable_RevertPosition.TestDraggable_SortableInteraction();
	}
}
  