package com.test.jqueryui.resizable;

import org.testng.annotations.Test;

import com.jqueryui.MainTest.MainTest;

public class TestResizable extends MainTest
{
	@Test
	public void testDragAndDrop_Default()
	{
		objResizable.TestResizeHorizontal_Default();
		objResizable.TestResizeVertical_Default();
		objResizable.TestResizebothDirection();
		objResizable.TestResizeAnimate();
	}
} 
