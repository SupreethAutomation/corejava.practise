package com.test.jqueryui.draggable;

import org.testng.annotations.Test;

import com.jqueryui.MainTest.MainTest;

public class TestDraggable_Sortable extends MainTest
{
	@Test
	public void testDraggable()
	{
		objDraggable_SortableInteraction.TestDraggable_SortableInteraction();
	}
}
 