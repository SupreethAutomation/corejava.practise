package com.test.jqueryui.draggable;

import org.testng.annotations.Test;

import com.jqueryui.MainTest.MainTest;

public class TestDraggable extends MainTest
{
	@Test
	public void testDraggable()
	{
		objDraggableInteraction.TestDraggableInteraction();
	}
	
	
}
 