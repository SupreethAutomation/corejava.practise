package com.test.jqueryui.button;

import org.testng.annotations.Test;

import com.jqueryui.MainTest.MainTest;

public class TestButton extends MainTest {

	@Test
	public void TestButtonFunctionality() 
	{
		objButton.TestButton_Default();
	}
}
