package com.test.jqueryui.sortable;

import org.testng.annotations.Test;

import com.jqueryui.MainTest.MainTest;

public class TestSortable extends MainTest
{
	@Test
	public void testDragAndDrop_Default()
	{
		objSortable.TestMoveFirstitemToLast();

		objSortable.TestReOrderItems_DescendingOrder();

		objSortable.TestConnectLists();

		objSortable.TestDisplayAsGrid();

		objSortable.TestPortlets("Feeds");
	}
}
