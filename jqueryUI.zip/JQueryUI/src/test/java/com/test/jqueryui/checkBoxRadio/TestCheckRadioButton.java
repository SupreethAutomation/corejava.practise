package com.test.jqueryui.checkBoxRadio;

import org.testng.annotations.Test;

import com.jqueryui.MainTest.MainTest;

public class TestCheckRadioButton extends MainTest {

	@Test
	public void TestCheckRadioButtonFunctionality() 
	{
		objCheckBoxRadio.TestRadio_Default("Paris");
		objCheckBoxRadio.TestCheckBoxALL_Default();
		
	}
}
