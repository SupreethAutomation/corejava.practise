package com.test.jqueryui.droppable;

import org.testng.annotations.Test;

import com.jqueryui.MainTest.MainTest;

public class TestDragAndDrop_Default extends MainTest
{
	@Test
	public void testDragAndDrop_Default()
	{
		objDragAndDrop_Default.TestDragAndDrop_Default();
	}
	
	
}
 