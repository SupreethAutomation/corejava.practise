package com.test.jqueryui.datepicker;

import org.testng.annotations.Test;

import com.jqueryui.MainTest.MainTest;

public class TestDataPicker extends MainTest
{
	@Test
	public void testDataPicker()
	{
		objDatePicker.TestDefaultFunctionality();
		objDatePicker.TestFormatDateFunctionality();
		
	}
}
