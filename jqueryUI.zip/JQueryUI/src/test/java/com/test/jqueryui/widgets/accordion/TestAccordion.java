package com.test.jqueryui.widgets.accordion;

import org.testng.annotations.Test;

import com.jqueryui.MainTest.MainTest;

public class TestAccordion extends MainTest {

	@Test
	public void TestAccordion_Default() 
	{
		objAccordion.TestAccordion_Default();
		objAccordion.TestExpandCollapseSections();
	//	objAccordion.TestNoAutoHeight();
	}
}
