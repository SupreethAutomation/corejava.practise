package com.test.jqueryui.widgets.autocomplete;

import org.testng.annotations.Test;

import com.jqueryui.MainTest.MainTest;

public class TestAutoComplete extends MainTest {

	@Test
	public void TestAccordion_Default() 
	{
	//	objAutoComplete.TestAutoComplete_Default();
		objAutoComplete.TestAutoComboBox("BASIC");
	}
}
