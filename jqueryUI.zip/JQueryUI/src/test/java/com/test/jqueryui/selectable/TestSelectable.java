package com.test.jqueryui.selectable;

import org.testng.annotations.Test;

import com.jqueryui.MainTest.MainTest;

public class TestSelectable extends MainTest
{
	@Test
	public void testDragAndDrop_Default()
	{ 
		objSelectable.TestSelectSingleItem("1");
		objSelectable.TestSelectSingleItem_Grid("11");
		objSelectable.TestSelectSingleItem_DisplayValue("6");
		objSelectable.TestMultipleSelectByClickandDrag("1");
		objSelectable.TestMultipleSelectByHoldandClick("1","2","3");
		objSelectable.TestMultipleSelectAndUnselect("1","2","3"); 
	}
}
