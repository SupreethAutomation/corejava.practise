package com.jqueryui.controlGroup;

import org.testng.annotations.Test;

import com.jqueryui.MainTest.MainTest;

public class TestControlGroup extends MainTest {

	@Test
	public void TestControlGroupFunctionality() 
	{
		objControlGroup.TestControlGroupToolBar();
	}
}
