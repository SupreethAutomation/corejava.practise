package com.jqueryui.MainTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.jqueryui.button.Button;
import com.jqueryui.checkBoxRadio.CheckBoxRadio;
import com.jqueryui.controlgroup.ControlGroup;
import com.jqueryui.datePicker.DatePicker;
import com.jqueryui.draggable.DraggableInteraction;
import com.jqueryui.draggable.Draggable_RevertPosition;
import com.jqueryui.draggable.Draggable_SortableInteraction;
import com.jqueryui.droppable.DragAndDrop;
import com.jqueryui.resizable.Resizable;
import com.jqueryui.selectable.Selectable;
import com.jqueryui.sortable.Sortable;
import com.jqueryui.widgets.accordion.Accordion;
import com.jqueryui.widgets.autocomplete.AutoComplete;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MainTest 
{
	protected WebDriver objWebDriver;
	protected WebDriverWait objWebDriverWait;
	protected DraggableInteraction objDraggableInteraction;
	protected Draggable_SortableInteraction objDraggable_SortableInteraction;
	protected Draggable_RevertPosition objDraggable_RevertPosition;
	protected DragAndDrop objDragAndDrop_Default;
	protected Resizable objResizable;
	protected Selectable objSelectable;
	protected Sortable objSortable;
	protected Accordion objAccordion;
	protected AutoComplete objAutoComplete;
	protected Button objButton;
	protected CheckBoxRadio objCheckBoxRadio;
	protected ControlGroup objControlGroup;
	protected DatePicker objDatePicker;
	@BeforeMethod
	public void setUp()
	{
		WebDriverManager.chromedriver().setup();
		objWebDriver = new ChromeDriver();
		objWebDriver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		objWebDriver.manage().window().maximize();
		objDraggableInteraction = new DraggableInteraction(objWebDriver);
		objDraggable_SortableInteraction = new Draggable_SortableInteraction(objWebDriver);
		objDraggable_RevertPosition = new Draggable_RevertPosition(objWebDriver);
		objDragAndDrop_Default = new DragAndDrop(objWebDriver);
		objResizable = new Resizable(objWebDriver);
		objSelectable = new Selectable(objWebDriver);
		objSortable = new Sortable(objWebDriver);
		objAccordion = new Accordion(objWebDriver);
		objAutoComplete = new AutoComplete(objWebDriver);
		objButton = new Button(objWebDriver);
		objCheckBoxRadio = new CheckBoxRadio(objWebDriver);
		objControlGroup = new ControlGroup(objWebDriver);
		objDatePicker = new DatePicker(objWebDriver);
	}
	
	@AfterMethod
	public void tearDown()
	{
		objWebDriver.quit();
	}
	
}
