package testHotelAvailability;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.erevmax.restutilities.CommonImpl;
import com.erevmax.restutilities.RestServiceUtility;
import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.specification.RequestSpecification;
import ta_pojo.Availability;
import ta_pojo.HotelAvailabilityRequest;

public class TestAvailability 
{
	RestServiceUtility objRestServiceUtility = null;
	HotelAvailabilityRequest objAvailabilityRequest = null;
	RequestSpecification objRequestSpecification = null;

	@DataProvider(name = "hotelavailability_los1")
	public static Object[][] los1_7Scenarios_SingleProperty() {

		return new Object[][] {
		/*	{"2025-01-01", 8, "2025-01-02",1,new int[] {1},new int[] {}, "en_US", CommonImpl.generateRandomString(), "USD", "Desktop", CommonImpl.generateRandomString(),"US", 1, Arrays.asList((long)999998), Arrays.asList("999998")},
			{"2025-01-01", 8, "2025-01-02",2,new int[] {1,2},new int[] {}, "en_US", CommonImpl.generateRandomString(), "USD", "Desktop", CommonImpl.generateRandomString(),"US", 1, Arrays.asList((long)999998), Arrays.asList("999998")},
			{"2025-01-01", 8, "2025-01-02",1,new int[] {1},new int[] {5}, "en_US", CommonImpl.generateRandomString(), "USD", "Desktop", CommonImpl.generateRandomString(),"US", 1, Arrays.asList((long)999998), Arrays.asList("999998")},
			{"2025-01-01", 8, "2025-01-02",2,new int[] {1,2},new int[] {5}, "en_US", CommonImpl.generateRandomString(), "USD", "Desktop", CommonImpl.generateRandomString(),"US", 1, Arrays.asList((long)999998), Arrays.asList("999998")},
			{"2025-01-01", 8, "2025-01-02",1,new int[] {2},new int[] {5,8}, "en_US", CommonImpl.generateRandomString(), "USD", "Desktop", CommonImpl.generateRandomString(),"US", 1, Arrays.asList((long)999998), Arrays.asList("999998")},
			{"2025-01-01", 8, "2025-01-02",2,new int[] {1,2},new int[] {8,9}, "en_US", CommonImpl.generateRandomString(), "USD", "Desktop", CommonImpl.generateRandomString(),"US", 1, Arrays.asList((long)999998), Arrays.asList("999998")},
			{"2025-01-01", 8, "2025-01-02",2,new int[] {1,1},new int[] {8}, "en_US", CommonImpl.generateRandomString(), "USD", "Desktop", CommonImpl.generateRandomString(),"US", 1, Arrays.asList((long)999998), Arrays.asList("999998")},
			{"2025-01-01", 8, "2025-01-02",2,new int[] {1,1},new int[] {8,8}, "en_US", CommonImpl.generateRandomString(), "USD", "Desktop", CommonImpl.generateRandomString(),"US", 1, Arrays.asList((long)999998), Arrays.asList("999998")},
*/
			{"2025-01-01", 8, "2025-01-02",1,new int[] {1},new int[] {}, "en_US", CommonImpl.generateRandomString(), "USD", "Desktop", CommonImpl.generateRandomString(),"US", 2, Arrays.asList((long)999998,(long)567765), Arrays.asList("999998","567765")},
			{"2025-01-01", 8, "2025-01-02",2,new int[] {1,2},new int[] {}, "en_US", CommonImpl.generateRandomString(), "USD", "Desktop", CommonImpl.generateRandomString(),"US", 2, Arrays.asList((long)999998,(long)567765), Arrays.asList("999998","567765")},
			{"2025-01-01", 8, "2025-01-02",1,new int[] {1},new int[] {5}, "en_US", CommonImpl.generateRandomString(), "USD", "Desktop", CommonImpl.generateRandomString(),"US", 2, Arrays.asList((long)999998,(long)567765), Arrays.asList("999998","567765")},
			{"2025-01-01", 8, "2025-01-02",2,new int[] {1,2},new int[] {5}, "en_US", CommonImpl.generateRandomString(), "USD", "Desktop", CommonImpl.generateRandomString(),"US", 2, Arrays.asList((long)999998,(long)567765), Arrays.asList("999998","567765")},
			{"2025-01-01", 8, "2025-01-02",1,new int[] {2},new int[] {5,8}, "en_US", CommonImpl.generateRandomString(), "USD", "Desktop", CommonImpl.generateRandomString(),"US", 2, Arrays.asList((long)999998,(long)567765), Arrays.asList("999998","567765")},
			{"2025-01-01", 8, "2025-01-02",2,new int[] {1,2},new int[] {8,9}, "en_US", CommonImpl.generateRandomString(), "USD", "Desktop", CommonImpl.generateRandomString(),"US", 2, Arrays.asList((long)999998,(long)567765), Arrays.asList("999998","567765")},
			{"2025-01-01", 8, "2025-01-02",2,new int[] {1,1},new int[] {8}, "en_US", CommonImpl.generateRandomString(), "USD", "Desktop", CommonImpl.generateRandomString(),"US", 2, Arrays.asList((long)999998,(long)567765), Arrays.asList("999998","567765")},
			{"2025-01-01", 8, "2025-01-02",2,new int[] {1,1},new int[] {8,8}, "en_US", CommonImpl.generateRandomString(), "USD", "Desktop", CommonImpl.generateRandomString(),"US",2, Arrays.asList((long)999998,(long)567765), Arrays.asList("999998","567765")}

		};
	}

	@Test(dataProvider = "hotelavailability_los1")
	public void testHotelAvailability(String start_date,int version,String end_date,int rooms,int[] adultCount,int[] childCount,String language,String query_Key,String currency,String deviceType,String availability_id,String userCountry,int num_hotels,List<Long> ta_id,List<String> partner_id)
	{
		Availability objAvailability = null;
		objAvailability = objAvailabilityRequest.createAvailabilityRequest(start_date,version,end_date,rooms,adultCount,childCount,language,query_Key,currency,deviceType,availability_id,userCountry,num_hotels,ta_id,partner_id);

		try {
			objRequestSpecification = RestServiceUtility.createJSonRequest(objAvailabilityRequest.getJsonPayloadAsString(objAvailability));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String jsonResponse = RestServiceUtility.getPostResponse(objRequestSpecification);
					System.out.println("JSON Response: " +jsonResponse);
		Object objectResult=null;
		try {
			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "apiversion"), jsonResponse);
			//				System.out.println("version : " +objectResult.toString());
			Assert.assertEquals("8", objectResult.toString(), "version is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "language"), jsonResponse);	
			//				System.out.println("language : " +objectResult.toString());
			Assert.assertEquals("en_US", objectResult.toString(), "language is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_apiversion"), jsonResponse);	
			//				System.out.println("availability_request_apiversion : " +objectResult.toString());
			Assert.assertEquals("8", objectResult.toString(), "availability_request_apiversion is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_start_date"), jsonResponse);	
			//				System.out.println("availability_request_start_date : " +objectResult.toString());
			Assert.assertEquals(start_date, objectResult.toString(), "availability_request_start_date is not matched");


			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_end_date"), jsonResponse);	
			//				System.out.println("availability_request_end_date : " +objectResult.toString());
			Assert.assertEquals(end_date, objectResult.toString(), "availability_request_end_date is not matched");


			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_party_adults"), jsonResponse);	
			//				System.out.println("availability_request_party_adults : " +objectResult.toString());

			for(int x: adultCount)
			{
				//						System.out.println("adult :" + x);
				Assert.assertEquals(objectResult.toString().contains(String.valueOf(x)),true, "availability_request_party_adults is not matched");
			}
			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_party_children"), jsonResponse);	
			//				System.out.println("availability_request_party_children : " +objectResult.toString());

			for(int x: childCount)
			{
				//		System.out.println("child :" + x);
				Assert.assertEquals(objectResult.toString().contains(String.valueOf(x)),true, "availability_request_party_adults is not matched");
			}

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_language"), jsonResponse);
			//				System.out.println("availability_request_language : " +objectResult.toString());
			Assert.assertEquals("en_US", objectResult.toString(), "availability_request_language is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_currency"), jsonResponse);	
			//				System.out.println("availability_request_currency : " +objectResult.toString());
			Assert.assertEquals("USD", objectResult.toString(), "availability_request_currency is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_user_country"), jsonResponse);
			//				System.out.println("availability_request_user_country : " +objectResult.toString());
			Assert.assertEquals("US", objectResult.toString(), "availability_request_user_country is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_device_type"), jsonResponse);
			//				System.out.println("availability_request_device_type : " +objectResult.toString());
			Assert.assertEquals("Desktop", objectResult.toString(), "availability_request_device_type is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_requested_payload_categories_room_type_details"), jsonResponse);
			//				System.out.println("availability_request_requested_payload_categories_room_type_details : " +objectResult.toString());
			Assert.assertFalse(Boolean.parseBoolean(objectResult.toString()), "availability_request_requested_payload_categories_room_type_details is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_requested_payload_categories_rate_plan_details"), jsonResponse);
			//				System.out.println("availability_request_requested_payload_categories_rate_plan_details : " +objectResult.toString());
			Assert.assertFalse(Boolean.parseBoolean(objectResult.toString()), "availability_request_requested_payload_categories_rate_plan_details is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_requested_payload_categories_room_rate_details"), jsonResponse);
			//				System.out.println("availability_request_requested_payload_categories_room_rate_details : " +objectResult.toString());
			Assert.assertFalse(Boolean.parseBoolean(objectResult.toString()), "availability_request_requested_payload_categories_room_rate_details is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_requested_payload_categories_hotel_details"), jsonResponse);
			//				System.out.println("availability_request_requested_payload_categories_hotel_details : " +objectResult.toString());
			Assert.assertFalse(Boolean.parseBoolean(objectResult.toString()), "availability_request_requested_payload_categories_hotel_details is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_requested_payload_categoriesModifiers_partner_booking_data"), jsonResponse);
			//				System.out.println("availability_request_requested_payload_categoriesModifiers_partner_booking_data : " +objectResult.toString());
			Assert.assertFalse(Boolean.parseBoolean(objectResult.toString()), "availability_request_requested_payload_categoriesModifiers_partner_booking_data is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_requested_payload_categoriesModifiers_real_time_pricing"), jsonResponse);
			//				System.out.println("availability_request_requested_payload_categoriesModifiers_real_time_pricing : " +objectResult.toString());
			Assert.assertFalse(Boolean.parseBoolean(objectResult.toString()), "availability_request_requested_payload_categoriesModifiers_real_time_pricing is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_requested_payload_categoriesModifiers_multiple_room_rates"), jsonResponse);
			//				System.out.println("availability_request_requested_payload_categoriesModifiers_multiple_room_rates : " +objectResult.toString());
			Assert.assertFalse(Boolean.parseBoolean(objectResult.toString()), "availability_request_requested_payload_categoriesModifiers_multiple_room_rates is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_requested_payload_categoriesModifiers_photos"), jsonResponse);
			//				System.out.println("availability_request_requested_payload_categoriesModifiers_photos : " +objectResult.toString());
			Assert.assertFalse(Boolean.parseBoolean(objectResult.toString()), "availability_request_requested_payload_categoriesModifiers_photos is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_requested_payload_categoriesModifiers_text"), jsonResponse);
			//				System.out.println("availability_request_requested_payload_categoriesModifiers_text : " +objectResult.toString());
			Assert.assertFalse(Boolean.parseBoolean(objectResult.toString()), "availability_request_requested_payload_categoriesModifiers_text is not matched");


			for(long x : ta_id)
			{
				objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_hotels_ta_hotel_id"), jsonResponse);
				long y = 0;
				List<Long> objList = new ArrayList<Long>();
				if(objectResult.toString().contains(","))
				{
					objList = Availability.toLong(objectResult.toString());
				}
				else
				{
					objList.clear();
					y = Long.parseLong(objectResult.toString().replace('[',' ').replace(']',' ').trim());
					objList.add(y);
				}
				Assert.assertEquals(objList.contains(x),true ,"TripAdvisor Hotel ID not matched");

			}

			for(String str: partner_id)
			{
				objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_request_hotels_partner_hotel_code"), jsonResponse);
				//	System.out.println("objectResult: "+objectResult.toString());
				Assert.assertEquals(objectResult.toString().contains(str),true,"Partner Hotel Code not matched");
			}

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_response_payload_categories_room_type_details"), jsonResponse);
			//			System.out.println("availability_response_payload_categories_room_type_details : " +objectResult.toString());
			Assert.assertFalse(Boolean.parseBoolean(objectResult.toString()), "availability_response_payload_categories_room_type_details is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_response_payload_categories_rate_plan_details"), jsonResponse);
			//			System.out.println("availability_response_payload_categories_room_type_details : " +objectResult.toString());
			Assert.assertFalse(Boolean.parseBoolean(objectResult.toString()), "availability_response_payload_categories_rate_plan_details is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_response_payload_categories_room_rate_details"), jsonResponse);
			//			System.out.println("availability_response_payload_categories_room_type_details : " +objectResult.toString());
			Assert.assertFalse(Boolean.parseBoolean(objectResult.toString()), "availability_response_payload_categories_room_rate_details is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_response_payload_categories_hotel_details"), jsonResponse);
			//			System.out.println("availability_response_payload_categories_hotel_details : " +objectResult.toString());
			Assert.assertFalse(Boolean.parseBoolean(objectResult.toString()), "availability_response_payload_categories_hotel_details is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_response_payload_categoriesModifiers_partner_booking_data"), jsonResponse);
			//			System.out.println("availability_response_payload_categoriesModifiers_partner_booking_data : " +objectResult.toString());
			Assert.assertFalse(Boolean.parseBoolean(objectResult.toString()), "availability_response_payload_categoriesModifiers_partner_booking_data is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_response_payload_categoriesModifiers_real_time_pricing"), jsonResponse);
			//			System.out.println("availability_response_payload_categoriesModifiers_real_time_pricing : " +objectResult.toString());
			Assert.assertFalse(Boolean.parseBoolean(objectResult.toString()), "availability_response_payload_categoriesModifiers_real_time_pricing is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_response_payload_categoriesModifiers_multiple_room_rates"), jsonResponse);
			//			System.out.println("availability_response_payload_categoriesModifiers_multiple_room_rates : " +objectResult.toString());
			Assert.assertFalse(Boolean.parseBoolean(objectResult.toString()), "availability_response_payload_categoriesModifiers_multiple_room_rates is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_response_payload_categoriesModifiers_photos"), jsonResponse);
			//			System.out.println("availability_response_payload_categoriesModifiers_photos : " +objectResult.toString());
			Assert.assertFalse(Boolean.parseBoolean(objectResult.toString()), "availability_response_payload_categoriesModifiers_photos is not matched");

			objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_response_payload_categoriesModifiers_text"), jsonResponse);
			//			System.out.println("availability_response_payload_categoriesModifiers_text : " +objectResult.toString());
			Assert.assertFalse(Boolean.parseBoolean(objectResult.toString()), "availability_response_payload_categoriesModifiers_text is not matched");


			for(String str : partner_id)
			{
				objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.replaceValue(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_response_hotels_response_type"), str), jsonResponse);
				//				System.out.println("availability_response_hotels_response_type : " +objectResult.toString());
				Assert.assertEquals(objectResult.toString(),"available", "availability_response_hotels_response_type is not matched");

				objectResult = RestServiceUtility.executeJsonPathWithExpression(CommonImpl.replaceValue(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_response_hotels_room_types_persistent_room_type_code"), str), jsonResponse);
								System.out.println("availability_response_hotels_response_type : " +objectResult.toString());
				Assert.assertEquals(objectResult.toString().contains("Room2"),true, "availability_response_hotels_room_types_persistent_room_type_code is not matched");
				Assert.assertEquals(objectResult.toString().contains("DLX"),true, "availability_response_hotels_room_types_persistent_room_type_code is not matched");
			}




		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	



	}

	@BeforeTest
	public void setUpConfig()
	{
		System.out.println("SetUp Config is done");
		objRestServiceUtility =  new RestServiceUtility();
		objAvailabilityRequest = new HotelAvailabilityRequest();
		try {
			try {
				RestServiceUtility.setServiceEndPoint(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\testApplnResource.properties"), "serverName"), CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\testApplnResource.properties"), "STGARIShopServicebuildName_V8"), Integer.parseInt(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\testApplnResource.properties"), "serverPort_search")), CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\testApplnResource.properties"), "resource_hotel_availability"));
			} catch (URISyntaxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@AfterTest
	public void RestConfig()
	{
		System.out.println("TestCases are executed successfully :)");
	}
}
