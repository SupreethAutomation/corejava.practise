package com.erevmax.restutilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class RateTigerDAO 
{
	static Connection objConnection; 
	static Statement objStatement;
	static PreparedStatement objPreparedStatement;
	static ResultSet objResultSet;
	static ResultSetMetaData objResultSetMetaData;
	static Map<String,ArrayList<String>> mapOfSelectQueryResults ;
	static Set<String> objSetColumns;
	static ArrayList<String> objLstColumnValues;
	static ArrayList<ArrayList<String>> arrayOfArrayList;
	static int columnCount;
	static int updateCount;
	static List<String> condnClause;
	public static Connection getConnection(String dbName,String userName,String pwd)
	{
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Connection objCon = null;
		try {
			//	objConnection = DriverManager.getConnection("jdbc:sqlserver://176.74.173.35:1433;instanceName=MSSQLSERVER2014;DatabaseName=RATETIGER;", "rtctws", "rtctws7R4S8He");
			objCon = DriverManager.getConnection(dbName,userName,pwd);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			if(objCon.isValid(10) && !(objCon.isClosed()))
			{
				RateTigerDAO.objConnection = objCon;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return RateTigerDAO.objConnection;
	}

	public static void executeSelectQueryGetResultMap(Connection objConnection, String query)
	{
		mapOfSelectQueryResults = new HashMap<String, ArrayList<String>>();
		try {
			objStatement = objConnection.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			if(objStatement.execute(query))
			{
				objResultSet = objStatement.getResultSet();
			}
			else
			{
				updateCount = objStatement.getUpdateCount();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			objResultSetMetaData = objResultSet.getMetaData();
			columnCount = objResultSetMetaData.getColumnCount();
			objSetColumns = new TreeSet<String>();
			System.out.println("columncount: "+columnCount);
			for(int i = 1; i <=columnCount; i++)
			{
				try {
					objSetColumns.add(objResultSetMetaData.getColumnName(i));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			String str ="";
			arrayOfArrayList = new ArrayList<ArrayList<String>>();
			mapOfSelectQueryResults = new TreeMap<String, ArrayList<String>>();
			objLstColumnValues = new ArrayList<String>();
			while(objResultSet.next())
			{
				objLstColumnValues = new ArrayList<String>();
				for(int i = 1; i <=columnCount; i++)
				{
					objLstColumnValues.add(objResultSet.getString(i));	
				}
				arrayOfArrayList.add(objLstColumnValues);
			}
			
			for(int i = 0; i <= 5; i ++)
			{
				mapOfSelectQueryResults.put(arrayOfArrayList.get(i).get(0), arrayOfArrayList.get(i));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*/*	System.out.println("Set: "+objSetColumns);
		System.out.println("Rowwise values: "+arrayOfArrayList);
		System.out.println("Rowwise values for - Hotel1 : "+arrayOfArrayList.get(0));
		System.out.println("Rowwise values for - Hotel2 : "+arrayOfArrayList.get(1));
		*/
	/*	System.out.println("map of hotelcode to arraylist:" + mapOfSelectQueryResults);
		System.out.println("map of hotelcode to arraylist:" + mapOfSelectQueryResults.get("567765"));
		System.out.println("map of hotelcode to arraylist:" + mapOfSelectQueryResults.get("567560"));
		System.out.println("map of hotelcode to arraylist:" + mapOfSelectQueryResults.get("567769"));
		System.out.println("map of hotelcode to arraylist:" + mapOfSelectQueryResults.get("999998"));
		System.out.println("map of hotelcode to arraylist:" + mapOfSelectQueryResults.get("999994"));
		System.out.println("map of hotelcode to arraylist:" + mapOfSelectQueryResults.get("7000750"));*/
	}


	public static void executeSelectQueryGetResultMap(Connection objConnection, String query, ArrayList<String> condnClause)
	{
		mapOfSelectQueryResults = new HashMap<String, ArrayList<String>>();
		try {
			objPreparedStatement = objConnection.prepareStatement(query);
			
			for(int i = 0; i <= condnClause.size()-1;i++)
			{
				objPreparedStatement.setString(i+1, condnClause.get(i));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			objResultSet = objPreparedStatement.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			objResultSetMetaData = objResultSet.getMetaData();
			columnCount = objResultSetMetaData.getColumnCount();
			objSetColumns = new TreeSet<String>();
			System.out.println("columncount: "+columnCount);
			for(int i = 1; i <=columnCount; i++)
			{
				try {
					objSetColumns.add(objResultSetMetaData.getColumnName(i));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			String str ="";
			arrayOfArrayList = new ArrayList<ArrayList<String>>();
			mapOfSelectQueryResults = new TreeMap<String, ArrayList<String>>();
			objLstColumnValues = new ArrayList<String>();
			while(objResultSet.next())
			{
				objLstColumnValues = new ArrayList<String>();
				for(int i = 1; i <=columnCount; i++)
				{
					objLstColumnValues.add(objResultSet.getString(i));	
				}
				arrayOfArrayList.add(objLstColumnValues);
			}
		
			for(int i = 1; i <= condnClause.size(); i ++)
			{
				mapOfSelectQueryResults.put(arrayOfArrayList.get(i-1).get(0), arrayOfArrayList.get(i-1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Set: "+objSetColumns);
		System.out.println("Rowwise values: "+arrayOfArrayList);
		
		System.out.println("map of hotelcode to arraylist:" + mapOfSelectQueryResults);
		
		for(int i = 0; i <= condnClause.size()-1;i++)
		{
			System.out.println("hoteldetails of ["+condnClause.get(i)+"]" + mapOfSelectQueryResults.get(condnClause.get(i)));
		}
	
	}
	public static int executeUpdateQuery(Connection objConnection, String query, ArrayList<String> condnClause) throws SQLException
	{
		objPreparedStatement = objConnection.prepareStatement(query);
		for(int i = 0; i <= condnClause.size()-1;i++)
		{
			objPreparedStatement.setString(i+1, condnClause.get(i));
		}
		updateCount = objPreparedStatement.executeUpdate();
		return updateCount;
	}
		


	public static void main(String[] args) 
	{
		Map<String, String> objResults = new HashMap<String, String>();
		List<String> objListHotels = new ArrayList<String>();
		/*objListHotels.add("567765");
		objListHotels.add("999998");*/
		objListHotels.add("999994");
		Connection objConrtctws = getConnection("jdbc:sqlserver://176.74.173.35:1433;instanceName=MSSQLSERVER2014;DatabaseName=RATETIGER;", "rtctws", "rtctws7R4S8He");
		//executeSelectQuery(objConrtctws, "select Hotel_Code,Chain_Name from RateTiger..RT_HOTEL_MAST where hotel_code in ('999998','567765')");
		//executeSelectQuery(objConrtctws, "select Hotel_Code,Hotel_Name from RateTiger..RT_HOTEL_MAST where hotel_code in ('999998','567765')");
	//	executeSelectQueryGetResultMap(objConrtctws, "select * from RateTiger..RT_HOTEL_MAST where hotel_code in (?,?)",(ArrayList)objListHotels);
		try {
			updateCount =  executeUpdateQuery(objConrtctws, "update RT_Client_Settings_Preference set requestwithTravelSite='1' where hotel_code in (?)",(ArrayList)objListHotels);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(updateCount +" rows updated..");

	}

}
