package com.erevmax.restutilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Random;

public class CommonImpl 
{
	public static String getPropertyValue(File objFile,String propertyName) throws IOException
	{
		FileInputStream objFileInputStream = new FileInputStream(objFile);
		Properties objProperties = new Properties();
		objProperties.load(objFileInputStream);
		return objProperties.getProperty(propertyName);
	}
	
	public static String generateRandomString()
	{
		String random = "key-";
		Random objRandom = new Random();
		return random + objRandom.nextLong();
	}
	
	public static void main(String[] args) throws IOException 
	{
			System.out.println(generateRandomString());
			System.out.println(replaceValue(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\jsonPath.properties"), "availability_response_hotels_room_rates_TaxCurrency"),"999998"));
	}
	
	public static String replaceValue(String sourceStr,String replaceKey)
	{
		String newStr = null;
		newStr = sourceStr.replaceAll("#", replaceKey);
		return newStr;
	}
	
	
}
