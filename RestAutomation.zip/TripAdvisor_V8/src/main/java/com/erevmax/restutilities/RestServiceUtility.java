package com.erevmax.restutilities;


import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.security.auth.login.Configuration;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.jayway.jsonpath.Criteria;
import com.jayway.jsonpath.Filter;
import com.jayway.jsonpath.JsonPath;

import ta_pojo.Availability;
import ta_pojo.HotelAvailabilityRequest;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.internal.AuthenticationSpecificationImpl;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class RestServiceUtility 
{
	static RequestSpecBuilder objRequestSpecBuilder = null;
	static RequestSpecification objRequestSpecification = null;
	static AuthenticationSpecificationImpl objAuthenticationSpecificationImpl = null;
	static String payloadData = null;

	static LinkedHashMap<String, String> objLinkedHashMapKeyParams = new LinkedHashMap<String, String>();
	static LinkedHashMap<String,Boolean> objSubMap = new LinkedHashMap<String,Boolean>();
	static LinkedHashMap<String, LinkedHashMap<String,Boolean>> objLinkedHashMapRequested_payload_categories = new LinkedHashMap<String, LinkedHashMap<String,Boolean>>();
	static LinkedHashMap<String, LinkedHashMap<String,Boolean>> objLinkedHashMapRequested_payload_category_modifiers = new LinkedHashMap<String, LinkedHashMap<String,Boolean>>();

	public static URI setServiceEndPoint(String baseURI,String basePath,int port,String serviceName) throws MalformedURLException, URISyntaxException
	{
		RestAssured.baseURI = baseURI;
		RestAssured.basePath=basePath+"/"+serviceName;
		RestAssured.port=port;
		URL objUrl = new URL(RestAssured.baseURI+":"+RestAssured.port+RestAssured.basePath);
		return objUrl.toURI();
	}
	public static RequestSpecification createJSonRequest(String payload)
	{
		objRequestSpecification = RestAssured.given()
				.contentType(ContentType.JSON)
				.accept(ContentType.JSON)
				.header("Authorization", "dHJpcGFkdmlzb3I6dHJpcGFkdmlzb3I=").body(payload);
		return objRequestSpecification;
	}

	public static String getPostResponse(RequestSpecification objRequestSpecification)
	{
		Response objResponse = null;
		try {
			objResponse = objRequestSpecification.post();
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return objResponse.asString();
	}

	public static Object executeJsonPathWithExpression(String jsonExpression, String jsonResponseString)
	{
		return JsonPath.read(jsonResponseString, jsonExpression);
	}

	public static void main(String[] args) {
		RestServiceUtility objRestServiceUtility = new RestServiceUtility();
		URI res= null;
		try {
			try {
				res = RestServiceUtility.setServiceEndPoint(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\testApplnResource.properties"), "serverName"), CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\testApplnResource.properties"), "STGARIShopServicebuildName_V8"), Integer.parseInt(CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\testApplnResource.properties"), "serverPort_search")), CommonImpl.getPropertyValue(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\appln\\testApplnResource.properties"), "resource_hotel_availability"));
			} catch (URISyntaxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(res);
		HotelAvailabilityRequest objAvailabilityRequest = new HotelAvailabilityRequest();
		Availability objAvailability = null;
		try {
			objAvailability = objAvailabilityRequest.createAvailabilityRequest("2025-01-01", 8, "2025-01-02",3,new int[] {1,2,3},new int[] {}, "US", "12345", "USD", "Desktop", "12345","US",2, Arrays.asList((long)999998), Arrays.asList("999998"));
			System.out.println("JSON Request: " + objAvailabilityRequest.getJsonPayloadAsString(objAvailability));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			objRequestSpecification = RestServiceUtility.createJSonRequest(objAvailabilityRequest.getJsonPayloadAsString(objAvailability));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String jsonResponse = getPostResponse(objRequestSpecification);
		System.out.println("JSON Response: " +jsonResponse);
		
		Object objectResult = RestServiceUtility.executeJsonPathWithExpression("$.api_version", jsonResponse);
		
		System.out.println("API_VERSION: "+objectResult);
		
		Assert.assertEquals("8", objectResult.toString(), "version is not matched");
	}

}
