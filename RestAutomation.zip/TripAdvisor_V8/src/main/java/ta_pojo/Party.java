package ta_pojo;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class Party 
{
	@SerializedName("adults")
	@Expose(serialize=true)
	private int adults;
	
	@SerializedName("children")
	@Expose(serialize=true)
	private int[] children;
	
	public Party(int adults,int[] children) 
	{
		this.setAdults(adults);
		this.setChildren(children);
	}
	
	public Party(int adults) 
	{
		this.setAdults(adults);
	}
	
	
	public int getAdults() {
		return adults;
	}

	public void setAdults(int adults) {
		this.adults = adults;
	}

	public int[] getChildren() {
		return children;
	}

	public void setChildren(int[] children) {
		this.children = children;
	}
}
