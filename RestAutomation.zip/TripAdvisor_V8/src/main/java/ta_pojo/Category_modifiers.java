package ta_pojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Category_modifiers {

	@SerializedName("partner_booking_data")
	@Expose(serialize=true)
	private boolean partnerBookingData;
	
	@SerializedName("real_time_pricing")
	@Expose(serialize=true)
	private boolean realTimePricing;
	
	@SerializedName("multiple_room_rates")
	@Expose(serialize=true)
	private boolean multipleRoomRates;
	
	@SerializedName("photos")
	@Expose(serialize=true)
	private boolean photos;
	
	@SerializedName("text")
	@Expose(serialize=true)
	private boolean text;

	public boolean isPartnerBookingData() {
		return partnerBookingData;
	}

	public void setPartnerBookingData(boolean partnerBookingData) {
		this.partnerBookingData = partnerBookingData;
	}

	public boolean isRealTimePricing() {
		return realTimePricing;
	}

	public void setRealTimePricing(boolean realTimePricing) {
		this.realTimePricing = realTimePricing;
	}

	public boolean isMultipleRoomRates() {
		return multipleRoomRates;
	}

	public void setMultipleRoomRates(boolean multipleRoomRates) {
		this.multipleRoomRates = multipleRoomRates;
	}

	public boolean isPhotos() {
		return photos;
	}

	public void setPhotos(boolean photos) {
		this.photos = photos;
	}

	public boolean isText() {
		return text;
	}

	public void setText(boolean text) {
		this.text = text;
	}
	
	
}
