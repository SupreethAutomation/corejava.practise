package ta_pojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Hotels 
{
	@SerializedName("ta_hotel_id")
	@Expose(serialize=true)
	private Object ta_hotel_id;
	
	@SerializedName("partner_hotel_code")
	@Expose(serialize=true)
	private String partner_hotel_code;
	
	public Object getTa_hotel_id() {
		return ta_hotel_id;
	}
	public void setTa_hotel_id(Object partner_id) {
		this.ta_hotel_id = partner_id;
	}
	public String getPartner_hotel_code() {
		return partner_hotel_code;
	}
	public void setPartner_hotel_code(String partner_hotel_code) {
		this.partner_hotel_code = partner_hotel_code;
	}
	
}
