package ta_pojo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.gson.Gson;

public class HotelAvailabilityRequest 
{
	String jsonString;
	//public Availability createAvailabilityRequest(String start_date,int version,String end_date,int rooms,int[] adultCount,int[] childCount,String language,String query_Key,String currency,String deviceType,String availability_id,String userCountry,long ta_id,String partner_id)
	public Availability createAvailabilityRequest(String start_date,int version,String end_date,int rooms,int[] adultCount,int[] childCount,String language,String query_Key,String currency,String deviceType,String availability_id,String userCountry,int num_hotels,List<Long> ta_id,List<String> partner_id)
	{
		Availability objAvailability_999998 = new Availability();
		objAvailability_999998.setApi_version(version);
		objAvailability_999998.setStartDate(start_date);
		objAvailability_999998.setEndDate(end_date);
		//	Party objParty = new Party(adultCount,childCount);
		//	objParty.setAdults(adultCount);
		//	Party objParty2 = new Party(adultCount,childCount);
		//	objParty2.setAdults(3);
		/*	ArrayList<Integer> objChildren = new ArrayList<Integer>();
		for(int x : childCount)
		{
		objChildren.add(x);
		}
		objParty.setChildren(objChildren);*/
		Party objParty = null;
		List<Party> objListParty = new ArrayList<Party>();

		for(int x=0; x<=rooms-1; x++)
		{
			objParty = new Party(adultCount[x]);	
			objParty = new Party(adultCount[x],childCount);
			objListParty.add(objParty);
		}
		//	objListParty.add(objParty2);
		objAvailability_999998.setParty(objListParty);
		objAvailability_999998.setLanguage(language);
		objAvailability_999998.setCurrency(currency);
		objAvailability_999998.setUserCountry(userCountry);
		objAvailability_999998.setDeviceType(deviceType);
		objAvailability_999998.setQueryKey(query_Key);
		objAvailability_999998.setAvailabilityId(availability_id);
		Requested_Payload objRequested_Payload = new Requested_Payload();
		Categories objCategories = new Categories();
		Category_modifiers objCategory_modifiers = new Category_modifiers();
		objCategories.setRoomTypeDetails(false);
		objCategories.setRatePlanDetails(false);
		objCategories.setRoomRateDetails(false);
		objCategories.setHotelDetails(false);
		objCategory_modifiers.setPartnerBookingData(false);
		objCategory_modifiers.setRealTimePricing(false);
		objCategory_modifiers.setMultipleRoomRates(false);
		objCategory_modifiers.setPhotos(false);
		objCategory_modifiers.setText(false);
		objRequested_Payload.setCategories(objCategories);
		objRequested_Payload.setCategory_modifiers(objCategory_modifiers);
		objAvailability_999998.setRequestedPayload(objRequested_Payload);
		List<Hotels> objLstHotels = new ArrayList<Hotels>();
		Hotels objHotels =null;
		for(int x = 0,y=0;x<=num_hotels-1 && y<=ta_id.size()-1;x++,y++)
		{
			objHotels = new Hotels();
			objHotels.setPartner_hotel_code(partner_id.get(x));
			objHotels.setTa_hotel_id(Long.valueOf(ta_id.get(y)));
			objLstHotels.add((Hotels) objHotels);
		}


		objAvailability_999998.setHotels(objLstHotels);
		return objAvailability_999998;
	}

	public String getJsonPayloadAsString(Availability objAvailability) throws JsonProcessingException
	{
		Gson objGson = new Gson();
		return jsonString = objGson.toJson(objAvailability);
	}

	public static void main(String[] args) 
	{
		HotelAvailabilityRequest objAvailabilityRequest = new HotelAvailabilityRequest();
		try {
			Availability objAvailability = objAvailabilityRequest.createAvailabilityRequest("2025-01-01", 8, "2025-01-02",3,new int[] {1,2,3},new int[] {}, "US", "12345", "USD", "Desktop", "12345","US",2, Arrays.asList((long)999998,(long)567765), Arrays.asList("999998","567765"));
			System.out.println("JSON Request:" + objAvailabilityRequest.getJsonPayloadAsString(objAvailability));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
