package ta_pojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class Categories {
	@SerializedName("room_type_details")
	@Expose(serialize=true)
	private boolean roomTypeDetails;

	@SerializedName("rate_plan_details")
	@Expose(serialize=true)
	private boolean ratePlanDetails;

	@SerializedName("room_rate_details")
	@Expose(serialize=true)
	private boolean roomRateDetails;

	@SerializedName("hotel_details")
	@Expose(serialize=true)
	private boolean hotelDetails;

	public boolean isRoomTypeDetails() {
		return roomTypeDetails;
	}

	public boolean isRatePlanDetails() {
		return ratePlanDetails;
	}

	public boolean isRoomRateDetails() {
		return roomRateDetails;
	}

	public boolean isHotelDetails() {
		return hotelDetails;
	}

	public void setRoomTypeDetails(boolean roomTypeDetails) {
		this.roomTypeDetails = roomTypeDetails;
	}

	public void setRatePlanDetails(boolean ratePlanDetails) {
		this.ratePlanDetails = ratePlanDetails;
	}

	public void setRoomRateDetails(boolean roomRateDetails) {
		this.roomRateDetails = roomRateDetails;
	}

	public void setHotelDetails(boolean hotelDetails) {
		this.hotelDetails = hotelDetails;
	}
}
