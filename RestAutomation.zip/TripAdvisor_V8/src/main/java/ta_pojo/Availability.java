package ta_pojo;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Availability 
{
	@SerializedName("api_version")
	@Expose(serialize=true)
	private int api_version;
	
	@SerializedName("start_date")
	@Expose(serialize=true)
	private String startDate;
	
	@SerializedName("end_date")
	@Expose(serialize=true)
	private String endDate;
	
	@SerializedName("party")
	@Expose(serialize=true)
	private List<Party> party = null;
	
	@SerializedName("language")
	@Expose(serialize=true)
	private String language;
	
	@SerializedName("query_key")
	@Expose(serialize=true)
	private String queryKey;
	
	@SerializedName("currency")
	@Expose(serialize=true)
	private String currency;
	
	@SerializedName("user_country")
	@Expose(serialize=true)
	private String userCountry;
	
	@SerializedName("device_type")
	@Expose(serialize=true)
	private String deviceType;
	
	@SerializedName("availability_id")
	@Expose(serialize=true)
	private String availabilityId;
	
	@SerializedName("requested_payload")
	@Expose(serialize=true)
	private Requested_Payload requestedPayload;
	
	@SerializedName("hotels")
	@Expose(serialize=true)
	private List<Hotels> Hotels = null;

	public int getApi_version() {
		return api_version;
	}

	public void setApi_version(int api_version) {
		this.api_version = api_version;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public List<Party> getParty() {
		return party;
	}

	public void setParty(List<Party> objListParty) {
		this.party = objListParty;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getQueryKey() {
		return queryKey;
	}

	public void setQueryKey(String queryKey) {
		this.queryKey = queryKey;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getUserCountry() {
		return userCountry;
	}

	public void setUserCountry(String userCountry) {
		this.userCountry = userCountry;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getAvailabilityId() {
		return availabilityId;
	}

	public void setAvailabilityId(String availabilityId) {
		this.availabilityId = availabilityId;
	}

	public Requested_Payload getRequestedPayload() {
		return requestedPayload;
	}

	public void setRequestedPayload(Requested_Payload requestedPayload) {
		this.requestedPayload = requestedPayload;
	}

	public List<Hotels> getHotels() {
		return Hotels;
	}

	public void setHotels(List<Hotels> objLstHotels) {
		this.Hotels = objLstHotels;
	}
	
	public static List<Long> toLong(String objStr)
	{
		List<Long> objList = new ArrayList<Long>();
		String str = "";
		String[] arrStr = null;
		str = objStr.toString().replace('[',' ').replace(']',' ').trim();
		arrStr =str.split(",");
		for(String str1 : arrStr)
		{
			objList.add(Long.parseLong(str1));
		}			
		return objList;
	}
	
	public static List<String> toString(String objStr)
	{
		List<String> objList = new ArrayList<String>();
		String str = "";
		String[] arrStr = null;
		str = objStr.toString().trim();
		arrStr =str.split(",");
		for(String str1 : arrStr)
		{
			objList.add(str1.replace('"', ' ').trim());
		}			
		return objList;
	}

	
	public static void main(String[] args) {
		
	}
	
}
