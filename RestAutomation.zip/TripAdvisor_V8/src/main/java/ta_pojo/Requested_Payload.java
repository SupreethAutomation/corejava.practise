package ta_pojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Requested_Payload 
{
	@SerializedName("categories")
	@Expose(serialize=true)
	private Categories categories;
	@SerializedName("category_modifiers")
	@Expose(serialize=true)
	private Category_modifiers category_modifiers;
	public Categories getCategories() {
		return categories;
	}
	public void setCategories(Categories categories) {
		this.categories = categories;
	}
	public Category_modifiers getCategory_modifiers() {
		return category_modifiers;
	}
	public void setCategory_modifiers(Category_modifiers category_modifiers) {
		this.category_modifiers = category_modifiers;
	}
	
}
